extern PHP_GTK_EXPORT_CE(gladexml_ce);
extern PHP_GTK_EXPORT_CE(glade_ce);
