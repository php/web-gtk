#include "php_gtk.h"

#if HAVE_PHP_GTK
#include <libsexy/sexy.h>
#include <libsexy/sexy-enum-types.h>
#include "ext/gtk+/php_gtk+.h"
#include "php_gtk_api.h"


PHP_GTK_EXPORT_CE(sexyiconentry_ce);
PHP_GTK_EXPORT_CE(sexyspellentry_ce);
PHP_GTK_EXPORT_CE(sexytooltip_ce);
PHP_GTK_EXPORT_CE(sexytreeview_ce);
PHP_GTK_EXPORT_CE(sexyurllabel_ce);
PHP_GTK_EXPORT_CE(sexy_ce);

static PHP_METHOD(Sexy, tooltip_new_with_label)
{
	char *text;
	zend_bool free_text = FALSE;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &text, &free_text))
		return;

    php_retval = sexy_tooltip_new_with_label(text);
	if (free_text) g_free(text);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexy_sexy_tooltip_new_with_label, 0)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static function_entry sexy_methods[] = {
	PHP_ME(Sexy, tooltip_new_with_label, arginfo_sexy_sexy_sexy_tooltip_new_with_label, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(SexyIconEntry, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyIconEntry);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyIconEntry);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(SexyIconEntry, set_icon)
{
	SexyIconEntryPosition position;
	zval *php_position = NULL, *icon;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VO", &php_position, &icon, gtkimage_ce))
		return;

	if (php_position && phpg_gvalue_get_enum(SEXY_TYPE_ICON_ENTRY_POSITION, php_position, (gint *)&position) == FAILURE) {
		return;
	}

    sexy_icon_entry_set_icon(SEXY_ICON_ENTRY(PHPG_GOBJECT(this_ptr)), position, GTK_IMAGE(PHPG_GOBJECT(icon)));

}


static PHP_METHOD(SexyIconEntry, set_icon_highlight)
{
	SexyIconEntryPosition position;
	zval *php_position = NULL;
	zend_bool highlight;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vb", &php_position, &highlight))
		return;

	if (php_position && phpg_gvalue_get_enum(SEXY_TYPE_ICON_ENTRY_POSITION, php_position, (gint *)&position) == FAILURE) {
		return;
	}

    sexy_icon_entry_set_icon_highlight(SEXY_ICON_ENTRY(PHPG_GOBJECT(this_ptr)), position, (gboolean)highlight);

}


static PHP_METHOD(SexyIconEntry, get_icon)
{
	SexyIconEntryPosition position;
	zval *php_position = NULL;
	GtkImage* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_position))
		return;

	if (php_position && phpg_gvalue_get_enum(SEXY_TYPE_ICON_ENTRY_POSITION, php_position, (gint *)&position) == FAILURE) {
		return;
	}

    php_retval = sexy_icon_entry_get_icon(SEXY_ICON_ENTRY(PHPG_GOBJECT(this_ptr)), position);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(SexyIconEntry, get_icon_highlight)
{
	SexyIconEntryPosition position;
	zval *php_position = NULL;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_position))
		return;

	if (php_position && phpg_gvalue_get_enum(SEXY_TYPE_ICON_ENTRY_POSITION, php_position, (gint *)&position) == FAILURE) {
		return;
	}

    php_retval = sexy_icon_entry_get_icon_highlight(SEXY_ICON_ENTRY(PHPG_GOBJECT(this_ptr)), position);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(SexyIconEntry, add_clear_button)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    sexy_icon_entry_add_clear_button(SEXY_ICON_ENTRY(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyiconentry_set_icon, 0)
    ZEND_ARG_OBJ_INFO(0, position, SexyIconEntryPosition, 1)
    ZEND_ARG_OBJ_INFO(0, icon, GtkImage, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyiconentry_set_icon_highlight, 0)
    ZEND_ARG_OBJ_INFO(0, position, SexyIconEntryPosition, 1)
    ZEND_ARG_INFO(0, highlight)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyiconentry_get_icon, 0)
    ZEND_ARG_OBJ_INFO(0, position, SexyIconEntryPosition, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyiconentry_get_icon_highlight, 0)
    ZEND_ARG_OBJ_INFO(0, position, SexyIconEntryPosition, 1)
ZEND_END_ARG_INFO();

static function_entry sexyiconentry_methods[] = {
	PHP_ME(SexyIconEntry, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexyIconEntry, add_clear_button,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexyIconEntry, get_icon,             arginfo_sexy_sexyiconentry_get_icon, ZEND_ACC_PUBLIC)
	PHP_ME(SexyIconEntry, get_icon_highlight,   arginfo_sexy_sexyiconentry_get_icon_highlight, ZEND_ACC_PUBLIC)
	PHP_ME(SexyIconEntry, set_icon,             arginfo_sexy_sexyiconentry_set_icon, ZEND_ACC_PUBLIC)
	PHP_ME(SexyIconEntry, set_icon_highlight,   arginfo_sexy_sexyiconentry_set_icon_highlight, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(SexySpellEntry, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexySpellEntry);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexySpellEntry);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(SexySpellEntry, get_language_name)
{
	char *lang;
	zend_bool free_lang = FALSE, free_result;
	gchar *php_retval, *cp_ret;
	gsize cp_len;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &lang, &free_lang))
		return;

    php_retval = sexy_spell_entry_get_language_name(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)), lang);
	if (free_lang) g_free(lang);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(SexySpellEntry, language_is_active)
{
	char *lang;
	zend_bool free_lang = FALSE;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &lang, &free_lang))
		return;

    php_retval = sexy_spell_entry_language_is_active(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)), lang);
	if (free_lang) g_free(lang);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(SexySpellEntry, activate_language)
{
	char *lang;
	zend_bool free_lang = FALSE;
	GError *error = NULL;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &lang, &free_lang))
		return;

    php_retval = sexy_spell_entry_activate_language(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)), lang, &error);
	if (free_lang) g_free(lang);
    if (phpg_handle_gerror(&error TSRMLS_CC)) {
        return;
    }
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(SexySpellEntry, deactivate_language)
{
	char *lang;
	zend_bool free_lang = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &lang, &free_lang))
		return;

    sexy_spell_entry_deactivate_language(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)), lang);
	if (free_lang) g_free(lang);

}


static PHP_METHOD(SexySpellEntry, is_checked)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = sexy_spell_entry_is_checked(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(SexySpellEntry, set_checked)
{
	zend_bool checked;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &checked))
		return;

    sexy_spell_entry_set_checked(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)), (gboolean)checked);

}


static PHP_METHOD(SexySpellEntry, activate_default_languages)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    sexy_spell_entry_activate_default_languages(SEXY_SPELL_ENTRY(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyspellentry_get_language_name, 0)
    ZEND_ARG_INFO(0, lang)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyspellentry_language_is_active, 0)
    ZEND_ARG_INFO(0, lang)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyspellentry_activate_language, 0)
    ZEND_ARG_INFO(0, lang)
    ZEND_ARG_INFO(0, error)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyspellentry_deactivate_language, 0)
    ZEND_ARG_INFO(0, lang)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyspellentry_set_checked, 0)
    ZEND_ARG_INFO(0, checked)
ZEND_END_ARG_INFO();

static function_entry sexyspellentry_methods[] = {
	PHP_ME(SexySpellEntry, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, activate_default_languages, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, activate_language,    arginfo_sexy_sexyspellentry_activate_language, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, deactivate_language,  arginfo_sexy_sexyspellentry_deactivate_language, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, get_language_name,    arginfo_sexy_sexyspellentry_get_language_name, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, is_checked,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, language_is_active,   arginfo_sexy_sexyspellentry_language_is_active, ZEND_ACC_PUBLIC)
	PHP_ME(SexySpellEntry, set_checked,          arginfo_sexy_sexyspellentry_set_checked, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(SexyTooltip, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyTooltip);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyTooltip);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(SexyTooltip, position_to_widget)
{
	zval *widget;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &widget, gtkwidget_ce))
		return;

    sexy_tooltip_position_to_widget(SEXY_TOOLTIP(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)));

}


static PHP_METHOD(SexyTooltip, position_to_rect)
{
	GdkRectangle rect = { 0, 0, 0, 0 };
	zval *php_rect, *screen;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VO", &php_rect, &screen, gdkscreen_ce))
		return;

    if (phpg_rectangle_from_zval(php_rect, (GdkRectangle*)&rect TSRMLS_CC) == FAILURE) {
        php_error(E_WARNING, "%s::%s() expects rect argument to be either a 4-element array or a GdkRectangle object", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }
    sexy_tooltip_position_to_rect(SEXY_TOOLTIP(PHPG_GOBJECT(this_ptr)), &rect, GDK_SCREEN(PHPG_GOBJECT(screen)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexytooltip_position_to_widget, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexytooltip_position_to_rect, 0)
    ZEND_ARG_OBJ_INFO(0, rect, GdkRectangle, 1)
    ZEND_ARG_OBJ_INFO(0, screen, GdkScreen, 1)
ZEND_END_ARG_INFO();

static function_entry sexytooltip_methods[] = {
	PHP_ME(SexyTooltip, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexyTooltip, position_to_rect,     arginfo_sexy_sexytooltip_position_to_rect, ZEND_ACC_PUBLIC)
	PHP_ME(SexyTooltip, position_to_widget,   arginfo_sexy_sexytooltip_position_to_widget, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(SexyTreeView, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyTreeView);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyTreeView);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(SexyTreeView, set_tooltip_label_column)
{
	long column;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &column))
		return;

    sexy_tree_view_set_tooltip_label_column(SEXY_TREE_VIEW(PHPG_GOBJECT(this_ptr)), (guint)column);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexytreeview_set_tooltip_label_column, 0)
    ZEND_ARG_INFO(0, column)
ZEND_END_ARG_INFO();

static function_entry sexytreeview_methods[] = {
	PHP_ME(SexyTreeView, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexyTreeView, set_tooltip_label_column, arginfo_sexy_sexytreeview_set_tooltip_label_column, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(SexyUrlLabel, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyUrlLabel);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(SexyUrlLabel);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(SexyUrlLabel, set_markup)
{
	char *markup;
	zend_bool free_markup = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &markup, &free_markup))
		return;

    sexy_url_label_set_markup(SEXY_URL_LABEL(PHPG_GOBJECT(this_ptr)), markup);
	if (free_markup) g_free(markup);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_sexy_sexyurllabel_set_markup, 0)
    ZEND_ARG_INFO(0, markup)
ZEND_END_ARG_INFO();

static function_entry sexyurllabel_methods[] = {
	PHP_ME(SexyUrlLabel, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(SexyUrlLabel, set_markup,           arginfo_sexy_sexyurllabel_set_markup, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

void phpg_sexy_register_classes(void)
{
	TSRMLS_FETCH();

	sexy_ce = phpg_register_class("Sexy", sexy_methods, NULL, 0, NULL, NULL, 0 TSRMLS_CC);

	sexyiconentry_ce = phpg_register_class("SexyIconEntry", sexyiconentry_methods, gtkentry_ce, 0, NULL, NULL, SEXY_TYPE_ICON_ENTRY TSRMLS_CC);

	sexyspellentry_ce = phpg_register_class("SexySpellEntry", sexyspellentry_methods, gtkentry_ce, 0, NULL, NULL, SEXY_TYPE_SPELL_ENTRY TSRMLS_CC);

	sexytooltip_ce = phpg_register_class("SexyTooltip", sexytooltip_methods, gtkwindow_ce, 0, NULL, NULL, SEXY_TYPE_TOOLTIP TSRMLS_CC);

	sexytreeview_ce = phpg_register_class("SexyTreeView", sexytreeview_methods, gtktreeview_ce, 0, NULL, NULL, SEXY_TYPE_TREE_VIEW TSRMLS_CC);

	sexyurllabel_ce = phpg_register_class("SexyUrlLabel", sexyurllabel_methods, gtklabel_ce, 0, NULL, NULL, SEXY_TYPE_URL_LABEL TSRMLS_CC);
}

void phpg_sexy_register_constants(const char *strip_prefix)
{
    TSRMLS_FETCH();
	phpg_register_enum(SEXY_TYPE_ICON_ENTRY_POSITION, strip_prefix, sexy_ce);
	phpg_register_enum(SEXY_TYPE_SPELL_ERROR, strip_prefix, sexy_ce);


    /* register gtype constants for all classes */

	phpg_register_int_constant(sexyiconentry_ce, "gtype", sizeof("gtype")-1, SEXY_TYPE_ICON_ENTRY);
	phpg_register_int_constant(sexyspellentry_ce, "gtype", sizeof("gtype")-1, SEXY_TYPE_SPELL_ENTRY);
	phpg_register_int_constant(sexytooltip_ce, "gtype", sizeof("gtype")-1, SEXY_TYPE_TOOLTIP);
	phpg_register_int_constant(sexytreeview_ce, "gtype", sizeof("gtype")-1, SEXY_TYPE_TREE_VIEW);
	phpg_register_int_constant(sexyurllabel_ce, "gtype", sizeof("gtype")-1, SEXY_TYPE_URL_LABEL);

}

#endif /* HAVE_PHP_GTK */
