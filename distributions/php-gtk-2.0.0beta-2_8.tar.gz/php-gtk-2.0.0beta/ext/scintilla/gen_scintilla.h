PHP_GTK_API extern PHP_GTK_EXPORT_CE(scintilla_ce);
