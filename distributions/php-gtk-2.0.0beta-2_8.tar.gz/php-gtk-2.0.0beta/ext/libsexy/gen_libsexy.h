extern PHP_GTK_EXPORT_CE(sexyiconentry_ce);
extern PHP_GTK_EXPORT_CE(sexyspellentry_ce);
extern PHP_GTK_EXPORT_CE(sexytooltip_ce);
extern PHP_GTK_EXPORT_CE(sexytreeview_ce);
extern PHP_GTK_EXPORT_CE(sexyurllabel_ce);
extern PHP_GTK_EXPORT_CE(sexy_ce);
