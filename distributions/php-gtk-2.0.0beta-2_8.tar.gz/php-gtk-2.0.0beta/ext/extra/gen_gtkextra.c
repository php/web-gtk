#include "php_gtk.h"

#if HAVE_PHP_GTK
#include <gtkextra/gtkextra.h>
#include <gtkextra/gtkextratypebuiltins.h>
#include <gtkextra/gtkplotcandle.h>
#include "ext/gtk+/php_gtk+.h"
#include "php_gtk_api.h"

#define GTK_ICON_FILE_SEL GTK_ICON_FILESEL
#define GTK_TYPE_ICON_FILE_SEL (gtk_icon_file_selection_get_type())
#define GTK_TYPE_COMBO_BUTTON (gtk_combo_button_get_type())
#define GTK_TYPE_COLOR_COMBO (gtk_color_combo_get_type())
#define GTK_TYPE_BORDER_COMBO (gtk_border_combo_get_type())
#define GTK_TYPE_FONT_COMBO (gtk_font_combo_get_type())
#define GTK_TYPE_PLOT3_D (gtk_plot3d_get_type())
#define GTK_TYPE_TOGGLE_COMBO (gtk_toggle_combo_get_type())

#define GTK_TYPE_PSFONT (gtk_psfont_get_type ())
static GType
gtk_psfont_get_type (void)
{
  static GType our_type = 0;
  
  if (our_type == 0)
    our_type = g_pointer_type_register_static ("GtkPSFont");

  return our_type;
}

#define GTK_TYPE_PLOT_MARKER (gtk_plot_marker_get_type ())
GtkPlotMarker*
gtk_plot_marker_copy (const GtkPlotMarker *marker)
{
    /* FIXME: am I correct? */
    GtkPlotMarker *copy;
    g_return_val_if_fail (marker != NULL, NULL);
    copy = g_new (GtkPlotMarker, 1);
    *copy = *marker;
    if (marker->data)
	g_object_ref (G_OBJECT (marker->data));
    return copy;
}

void
gtk_plot_marker_free (GtkPlotMarker *marker)
{
    /* FIXME: am I correct? */
    g_return_if_fail (marker != NULL);
    if (marker->data)
	g_object_unref (G_OBJECT (marker->data));
    g_free (marker);
}

static GType
gtk_plot_marker_get_type (void)
{
  static GType our_type = 0;
  if (our_type == 0)
    our_type = g_boxed_type_register_static ("GtkPlotMarker",
					     (GBoxedCopyFunc) gtk_plot_marker_copy,
					     (GBoxedFreeFunc) gtk_plot_marker_free);
  return our_type;
}

GtkPlotText*
gtk_plot_text_copy (const GtkPlotText *text)
{
    /* FIXME: am I correct? */
    GtkPlotText *copy;
    g_return_val_if_fail (text != NULL, NULL);
    copy = g_new (GtkPlotText, 1);
    *copy = *text;
    if(copy->font)
	copy->font = g_strdup(text->font);
    if(copy->text)
	copy->text = g_strdup(text->text);
    return copy;
}

void
gtk_plot_text_free (GtkPlotText *text)
{
    /* FIXME: am I correct? */
    g_return_if_fail (text != NULL);
    if (text->font)
	g_free(text->font);
    if (text->text)
	g_free(text->text);
    g_free (text);
}

#define GTK_TYPE_PLOT_TEXT (gtk_plot_text_get_type ())
static GType
gtk_plot_text_get_type (void)
{
  static GType our_type = 0;

#if 0 //HACK 
  if (our_type == 0)
    our_type = g_pointer_type_register_static ("GtkPlotText");
#else //Should be something similiar to this
  if (our_type == 0)
    our_type = g_boxed_type_register_static ("GtkPlotText",
					     (GBoxedCopyFunc) gtk_plot_text_copy,
					     (GBoxedFreeFunc) gtk_plot_text_free);
#endif
  return our_type;
}

#define GTK_TYPE_PLOT_LINE (gtk_plot_line_get_type ())
static GType
gtk_plot_line_get_type (void)
{
  static GType our_type = 0;

#if 1 //HACK 
  if (our_type == 0)
    our_type = g_pointer_type_register_static ("GtkPlotLine");
#else //Should be something similiar to this
  if (our_type == 0)
    our_type = g_boxed_type_register_static ("GtkPlotLine",
					     (GBoxedCopyFunc) gtk_plot_line_ref,
					     (GBoxedFreeFunc) gtk_plot_line_unref);
#endif
  return our_type;
}

#define GTK_TYPE_PLOT_DT_NODE (gtk_plot_dt_node_get_type ())
static GType
gtk_plot_dt_node_get_type (void)
{
  static GType our_type = 0;
  
  if (our_type == 0)
    our_type = g_pointer_type_register_static ("GtkPlotDTnode");

  return our_type;
}

static GtkSheetRange*
gtk_sheet_range_new ( gint row0, gint col0, gint rowi, gint coli)
{
    GtkSheetRange *p = g_new (GtkSheetRange, 1);
    if (p) {
	p->row0 = row0;
	p->col0 = col0;
	p->rowi = rowi;
	p->coli = coli;
    }
    return p;
}

static void
gtk_plot_draw_text_PY (GtkPlot *plot, GtkPlotText *text)
{
    gtk_plot_draw_text(plot, *text); 
}

static void
gtk_plot_draw_line_PY (GtkPlot *plot, GtkPlotLine *line, gdouble x1, gdouble y1, gdouble x2, gdouble y2)
{
    gtk_plot_draw_line(plot, *line, x1, y1, x2, y2);
}

static void
gtk_plot_set_line_attributes_PY (GtkPlot *plot, GtkPlotLine *line)
{
    gtk_plot_set_line_attributes (plot, *line);
}

static gboolean
gtk_plot_dt_add_node_PY (GtkPlotDT *data, GtkPlotDTnode *node)
{
    return gtk_plot_dt_add_node(data, *node);
}

/* This one is probably an "error" in h2def.py */
#define GTK_PLOT3_D GTK_PLOT3D


PHP_GTK_EXPORT_CE(gtkcharselection_ce);
PHP_GTK_EXPORT_CE(gtkcheckitem_ce);
PHP_GTK_EXPORT_CE(gtkcombobutton_ce);
PHP_GTK_EXPORT_CE(gtkcolorcombo_ce);
PHP_GTK_EXPORT_CE(gtkbordercombo_ce);
PHP_GTK_EXPORT_CE(gtkdirtree_ce);
PHP_GTK_EXPORT_CE(gtkfontcombo_ce);
PHP_GTK_EXPORT_CE(gtkiconfilesel_ce);
PHP_GTK_EXPORT_CE(gtkiconlist_ce);
PHP_GTK_EXPORT_CE(gtkfilelist_ce);
PHP_GTK_EXPORT_CE(gtkitementry_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvas_ce);
PHP_GTK_EXPORT_CE(gtkplot_ce);
PHP_GTK_EXPORT_CE(gtkplotarray_ce);
PHP_GTK_EXPORT_CE(gtkplotarraylist_ce);
PHP_GTK_EXPORT_CE(gtkplotaxis_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvaschild_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvasellipse_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvasline_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvaspixmap_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvasplot_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvasrectangle_ce);
PHP_GTK_EXPORT_CE(gtkplotcanvastext_ce);
PHP_GTK_EXPORT_CE(gtkplot3d_ce);
PHP_GTK_EXPORT_CE(gtkplotdt_ce);
PHP_GTK_EXPORT_CE(gtkplotdata_ce);
PHP_GTK_EXPORT_CE(gtkplotcandle_ce);
PHP_GTK_EXPORT_CE(gtkplotbubble_ce);
PHP_GTK_EXPORT_CE(gtkplotbox_ce);
PHP_GTK_EXPORT_CE(gtkplotbar_ce);
PHP_GTK_EXPORT_CE(gtkplotflux_ce);
PHP_GTK_EXPORT_CE(gtkplotpc_ce);
PHP_GTK_EXPORT_CE(gtkplotgdk_ce);
PHP_GTK_EXPORT_CE(gtkplotps_ce);
PHP_GTK_EXPORT_CE(gtkplotpixmap_ce);
PHP_GTK_EXPORT_CE(gtkplotpolar_ce);
PHP_GTK_EXPORT_CE(gtkplotsurface_ce);
PHP_GTK_EXPORT_CE(gtkplotcsurface_ce);
PHP_GTK_EXPORT_CE(gtksheet_ce);
PHP_GTK_EXPORT_CE(gtktogglecombo_ce);
PHP_GTK_EXPORT_CE(gtkiconlistitem_ce);
PHP_GTK_EXPORT_CE(gtksheetrange_ce);
PHP_GTK_EXPORT_CE(gtkplotdtnode_ce);
PHP_GTK_EXPORT_CE(gtkextra_ce);

static PHP_METHOD(GtkExtra, _item_new_with_label)
{
	char *label;
	zend_bool free_label = FALSE;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &label, &free_label))
		return;

    php_retval = gtk_check_item_new_with_label(label);
	if (free_label) g_free(label);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, _combo_new_with_values)
{
	long nrows, ncols;
	GdkColor *colors = NULL;
	zval *php_colors;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiO", &nrows, &ncols, &php_colors, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_colors, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        colors = (GdkColor *) PHPG_GBOXED(php_colors);
    } else {
        php_error(E_WARNING, "%s::%s() expects colors argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_color_combo_new_with_values((gint)nrows, (gint)ncols, colors);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, check_version)
{
	long required_major, required_minor, required_micro;
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iii", &required_major, &required_minor, &required_micro))
		return;

    php_retval = gtkextra_check_version((guint)required_major, (guint)required_minor, (guint)required_micro);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkExtra, d_new_with_size)
{
	zval *drawable;
	double width, height;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &drawable, gdkdrawable_ce, &width, &height))
		return;

    php_retval = gtk_plot3d_new_with_size(GDK_DRAWABLE(PHPG_GOBJECT(drawable)), width, height);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, new_with_size)
{
	zval *drawable;
	double width, height;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &drawable, gdkdrawable_ce, &width, &height))
		return;

    php_retval = gtk_plot_new_with_size(GDK_DRAWABLE(PHPG_GOBJECT(drawable)), width, height);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, polar_new_with_size)
{
	GdkDrawable *drawable = NULL;
	zval *php_drawable = NULL;
	double width, height;
	GtkWidget* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|Ndd", &php_drawable, gdkdrawable_ce, &width, &height))
		return;
    if (php_drawable) {
        if (Z_TYPE_P(php_drawable) == IS_NULL)
            drawable = NULL;
        else
            drawable = GDK_DRAWABLE(PHPG_GOBJECT(php_drawable));
    }

    php_retval = gtk_plot_polar_new_with_size(drawable, width, height);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, ps_new_with_size)
{
	char *psname;
	zend_bool free_psname = FALSE;
	long orientation, epsflag, units;
	double width, height, scalex, scaley;
	GtkObject* php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiidddd", &psname, &free_psname, &orientation, &epsflag, &units, &width, &height, &scalex, &scaley))
		return;

    php_retval = gtk_plot_ps_new_with_size(psname, (gint)orientation, (gint)epsflag, (gint)units, width, height, scalex, scaley);
	if (free_psname) g_free(psname);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkExtra, psfont_init)
{
	long php_retval;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_psfont_init();
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkExtra, t_unref)
{

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_psfont_unref();

}


static PHP_METHOD(GtkExtra, psfont_add_font)
{
	char *fontname, *psname, *family, *pango_string;
	zend_bool free_fontname = FALSE, free_psname = FALSE, free_family = FALSE, free_pango_string = FALSE, italic, bold;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uuuubb", &fontname, &free_fontname, &psname, &free_psname, &family, &free_family, &pango_string, &free_pango_string, &italic, &bold))
		return;

    gtk_psfont_add_font(fontname, psname, family, pango_string, (gboolean)italic, (gboolean)bold);
	if (free_fontname) g_free(fontname);
	if (free_psname) g_free(psname);
	if (free_family) g_free(family);
	if (free_pango_string) g_free(pango_string);

}


static PHP_METHOD(GtkExtra, psfont_add_i18n_font)
{
	char *fontname, *psname, *family, *i18n_latinfamily, *pango_string;
	zend_bool free_fontname = FALSE, free_psname = FALSE, free_family = FALSE, free_i18n_latinfamily = FALSE, free_pango_string = FALSE, italic, bold, vertical;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uuuuubbb", &fontname, &free_fontname, &psname, &free_psname, &family, &free_family, &i18n_latinfamily, &free_i18n_latinfamily, &pango_string, &free_pango_string, &italic, &bold, &vertical))
		return;

    gtk_psfont_add_i18n_font(fontname, psname, family, i18n_latinfamily, pango_string, (gboolean)italic, (gboolean)bold, (gboolean)vertical);
	if (free_fontname) g_free(fontname);
	if (free_psname) g_free(psname);
	if (free_family) g_free(family);
	if (free_i18n_latinfamily) g_free(i18n_latinfamily);
	if (free_pango_string) g_free(pango_string);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_gtk_check_item_new_with_label, 0)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_gtk_color_combo_new_with_values, 0)
    ZEND_ARG_INFO(0, nrows)
    ZEND_ARG_INFO(0, ncols)
    ZEND_ARG_OBJ_INFO(0, colors, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_check_version, 0)
    ZEND_ARG_INFO(0, required_major)
    ZEND_ARG_INFO(0, required_minor)
    ZEND_ARG_INFO(0, required_micro)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_gtk_plot3d_new_with_size, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_gtk_plot_new_with_size, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtkextra_gtkextra_gtk_plot_polar_new_with_size, 0, 0, 2)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_gtk_plot_ps_new_with_size, 0)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, orientation)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_INFO(0, units)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, scalex)
    ZEND_ARG_INFO(0, scaley)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_psfont_add_font, 0)
    ZEND_ARG_INFO(0, fontname)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, family)
    ZEND_ARG_INFO(0, pango_string)
    ZEND_ARG_INFO(0, italic)
    ZEND_ARG_INFO(0, bold)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtkextra_gtkextra_psfont_add_i18n_font, 0)
    ZEND_ARG_INFO(0, fontname)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, family)
    ZEND_ARG_INFO(0, i18n_latinfamily)
    ZEND_ARG_INFO(0, pango_string)
    ZEND_ARG_INFO(0, italic)
    ZEND_ARG_INFO(0, bold)
    ZEND_ARG_INFO(0, vertical)
ZEND_END_ARG_INFO();

static function_entry gtkextra_methods[] = {
	PHP_ME(GtkExtra, _combo_new_with_values, arginfo_gtkextra_gtkextra_gtk_color_combo_new_with_values, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, _item_new_with_label, arginfo_gtkextra_gtkextra_gtk_check_item_new_with_label, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, check_version,        arginfo_gtkextra_gtkextra_check_version, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, d_new_with_size, arginfo_gtkextra_gtkextra_gtk_plot3d_new_with_size, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, new_with_size, arginfo_gtkextra_gtkextra_gtk_plot_new_with_size, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, polar_new_with_size, arginfo_gtkextra_gtkextra_gtk_plot_polar_new_with_size, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, ps_new_with_size, arginfo_gtkextra_gtkextra_gtk_plot_ps_new_with_size, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, psfont_add_font,      arginfo_gtkextra_gtkextra_psfont_add_font, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, psfont_add_i18n_font, arginfo_gtkextra_gtkextra_psfont_add_i18n_font, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, psfont_init,          NULL, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkExtra, t_unref,     NULL, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkCharSelection, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkCharSelection);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkCharSelection);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkCharSelection, font_combo)
{
	GtkFontCombo* php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->font_combo;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkCharSelection, table)
{
	GtkTable* php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->table;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkCharSelection, selection)
{
	long php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->selection;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkCharSelection, ok_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->ok_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkCharSelection, cancel_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->cancel_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkCharSelection, action_area)
{
	GtkWidget* php_retval;

    php_retval = GTK_CHAR_SELECTION(((phpg_gobject_t *)object)->obj)->action_area;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkcharselection_prop_info[] = {
	{ "font_combo", PHPG_PROP_READ_FN(GtkCharSelection, font_combo), NULL },
	{ "table", PHPG_PROP_READ_FN(GtkCharSelection, table), NULL },
	{ "selection", PHPG_PROP_READ_FN(GtkCharSelection, selection), NULL },
	{ "ok_button", PHPG_PROP_READ_FN(GtkCharSelection, ok_button), NULL },
	{ "cancel_button", PHPG_PROP_READ_FN(GtkCharSelection, cancel_button), NULL },
	{ "action_area", PHPG_PROP_READ_FN(GtkCharSelection, action_area), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkCharSelection, set_selection)
{
	long selection;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &selection))
		return;

    gtk_char_selection_set_selection(GTK_CHAR_SELECTION(PHPG_GOBJECT(this_ptr)), (gint)selection);

}


static PHP_METHOD(GtkCharSelection, get_selection)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_char_selection_get_selection(GTK_CHAR_SELECTION(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkcharselection_set_selection, 0)
    ZEND_ARG_INFO(0, selection)
ZEND_END_ARG_INFO();

static function_entry gtkcharselection_methods[] = {
	PHP_ME(GtkCharSelection, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkCharSelection, get_selection,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkCharSelection, set_selection,        arginfo_gtk_gtkcharselection_set_selection, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkCheckItem, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkCheckItem);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkCheckItem);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkCheckItem, construct_with_label)
{
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &label, &free_label))
		return;

    gtk_check_item_construct_with_label(GTK_CHECK_ITEM(PHPG_GOBJECT(this_ptr)), label);
	if (free_label) g_free(label);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkcheckitem_construct_with_label, 0)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static function_entry gtkcheckitem_methods[] = {
	PHP_ME(GtkCheckItem, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkCheckItem, construct_with_label, arginfo_gtk_gtkcheckitem_construct_with_label, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

PHPG_PROP_READER(GtkComboButton, button)
{
	GtkWidget* php_retval;

    php_retval = GTK_COMBO_BUTTON(((phpg_gobject_t *)object)->obj)->button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkComboButton, arrow)
{
	GtkWidget* php_retval;

    php_retval = GTK_COMBO_BUTTON(((phpg_gobject_t *)object)->obj)->arrow;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkComboButton, popup)
{
	GtkWidget* php_retval;

    php_retval = GTK_COMBO_BUTTON(((phpg_gobject_t *)object)->obj)->popup;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkComboButton, popwin)
{
	GtkWidget* php_retval;

    php_retval = GTK_COMBO_BUTTON(((phpg_gobject_t *)object)->obj)->popwin;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkComboButton, frame)
{
	GtkWidget* php_retval;

    php_retval = GTK_COMBO_BUTTON(((phpg_gobject_t *)object)->obj)->frame;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkcombobutton_prop_info[] = {
	{ "button", PHPG_PROP_READ_FN(GtkComboButton, button), NULL },
	{ "arrow", PHPG_PROP_READ_FN(GtkComboButton, arrow), NULL },
	{ "popup", PHPG_PROP_READ_FN(GtkComboButton, popup), NULL },
	{ "popwin", PHPG_PROP_READ_FN(GtkComboButton, popwin), NULL },
	{ "frame", PHPG_PROP_READ_FN(GtkComboButton, frame), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkColorCombo, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkColorCombo);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkColorCombo);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkColorCombo, construct)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_color_combo_construct(GTK_COLOR_COMBO(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkColorCombo, construct_with_values)
{
	long nrows, ncols;
	GdkColor *colors = NULL;
	zval *php_colors;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiO", &nrows, &ncols, &php_colors, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_colors, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        colors = (GdkColor *) PHPG_GBOXED(php_colors);
    } else {
        php_error(E_WARNING, "%s::%s() expects colors argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_color_combo_construct_with_values(GTK_COLOR_COMBO(PHPG_GOBJECT(this_ptr)), (gint)nrows, (gint)ncols, colors);

}


static PHP_METHOD(GtkColorCombo, get_color_at)
{
	long row, col;
	GdkColor php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    php_retval = gtk_color_combo_get_color_at(GTK_COLOR_COMBO(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);
	phpg_gboxed_new(&return_value, GDK_TYPE_COLOR, &php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkColorCombo, get_selection)
{
	GdkColor php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_color_combo_get_selection(GTK_COLOR_COMBO(PHPG_GOBJECT(this_ptr)));
	phpg_gboxed_new(&return_value, GDK_TYPE_COLOR, &php_retval, TRUE, TRUE TSRMLS_CC);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkcolorcombo_construct_with_values, 0)
    ZEND_ARG_INFO(0, nrows)
    ZEND_ARG_INFO(0, ncols)
    ZEND_ARG_OBJ_INFO(0, colors, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkcolorcombo_get_color_at, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static function_entry gtkcolorcombo_methods[] = {
	PHP_ME(GtkColorCombo, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkColorCombo, construct,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkColorCombo, construct_with_values, arginfo_gtk_gtkcolorcombo_construct_with_values, ZEND_ACC_PUBLIC)
	PHP_ME(GtkColorCombo, get_color_at,         arginfo_gtk_gtkcolorcombo_get_color_at, ZEND_ACC_PUBLIC)
	PHP_ME(GtkColorCombo, get_selection,        NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkBorderCombo, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkBorderCombo);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkBorderCombo);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkBorderCombo, nrows)
{
	long php_retval;

    php_retval = GTK_BORDER_COMBO(((phpg_gobject_t *)object)->obj)->nrows;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkBorderCombo, ncols)
{
	long php_retval;

    php_retval = GTK_BORDER_COMBO(((phpg_gobject_t *)object)->obj)->ncols;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkBorderCombo, row)
{
	long php_retval;

    php_retval = GTK_BORDER_COMBO(((phpg_gobject_t *)object)->obj)->row;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkBorderCombo, column)
{
	long php_retval;

    php_retval = GTK_BORDER_COMBO(((phpg_gobject_t *)object)->obj)->column;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkBorderCombo, table)
{
	GtkWidget* php_retval;

    php_retval = GTK_BORDER_COMBO(((phpg_gobject_t *)object)->obj)->table;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkbordercombo_prop_info[] = {
	{ "nrows", PHPG_PROP_READ_FN(GtkBorderCombo, nrows), NULL },
	{ "ncols", PHPG_PROP_READ_FN(GtkBorderCombo, ncols), NULL },
	{ "row", PHPG_PROP_READ_FN(GtkBorderCombo, row), NULL },
	{ "column", PHPG_PROP_READ_FN(GtkBorderCombo, column), NULL },
	{ "table", PHPG_PROP_READ_FN(GtkBorderCombo, table), NULL },
	{ NULL, NULL, NULL },
};


static function_entry gtkbordercombo_methods[] = {
	PHP_ME(GtkBorderCombo, __construct,          NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkDirTree, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkDirTree);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkDirTree);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkDirTree, local_hostname)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->local_hostname;
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, show_hidden)
{
	gboolean php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->show_hidden;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, my_pc)
{
	GdkPixmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->my_pc;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, folder)
{
	GdkPixmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->folder;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, ofolder)
{
	GdkPixmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->ofolder;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, dennied)
{
	GdkPixmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->dennied;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, my_pc_mask)
{
	GdkBitmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->my_pc_mask;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, folder_mask)
{
	GdkBitmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->folder_mask;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, ofolder_mask)
{
	GdkBitmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->ofolder_mask;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkDirTree, dennied_mask)
{
	GdkBitmap* php_retval;

    php_retval = GTK_DIR_TREE(((phpg_gobject_t *)object)->obj)->dennied_mask;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkdirtree_prop_info[] = {
	{ "local_hostname", PHPG_PROP_READ_FN(GtkDirTree, local_hostname), NULL },
	{ "show_hidden", PHPG_PROP_READ_FN(GtkDirTree, show_hidden), NULL },
	{ "my_pc", PHPG_PROP_READ_FN(GtkDirTree, my_pc), NULL },
	{ "folder", PHPG_PROP_READ_FN(GtkDirTree, folder), NULL },
	{ "ofolder", PHPG_PROP_READ_FN(GtkDirTree, ofolder), NULL },
	{ "dennied", PHPG_PROP_READ_FN(GtkDirTree, dennied), NULL },
	{ "my_pc_mask", PHPG_PROP_READ_FN(GtkDirTree, my_pc_mask), NULL },
	{ "folder_mask", PHPG_PROP_READ_FN(GtkDirTree, folder_mask), NULL },
	{ "ofolder_mask", PHPG_PROP_READ_FN(GtkDirTree, ofolder_mask), NULL },
	{ "dennied_mask", PHPG_PROP_READ_FN(GtkDirTree, dennied_mask), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkDirTree, open_dir)
{
	char *path;
	zend_bool free_path = FALSE;
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &path, &free_path))
		return;

    php_retval = gtk_dir_tree_open_dir(GTK_DIR_TREE(PHPG_GOBJECT(this_ptr)), path);
	if (free_path) g_free(path);
	RETVAL_LONG(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkdirtree_open_dir, 0)
    ZEND_ARG_INFO(0, path)
ZEND_END_ARG_INFO();

static function_entry gtkdirtree_methods[] = {
	PHP_ME(GtkDirTree, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkDirTree, open_dir,             arginfo_gtk_gtkdirtree_open_dir, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkFontCombo, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkFontCombo);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkFontCombo);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkFontCombo, name_combo)
{
	GtkWidget* php_retval;

    php_retval = GTK_FONT_COMBO(((phpg_gobject_t *)object)->obj)->name_combo;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkFontCombo, size_combo)
{
	GtkWidget* php_retval;

    php_retval = GTK_FONT_COMBO(((phpg_gobject_t *)object)->obj)->size_combo;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkFontCombo, bold_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_FONT_COMBO(((phpg_gobject_t *)object)->obj)->bold_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkFontCombo, italic_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_FONT_COMBO(((phpg_gobject_t *)object)->obj)->italic_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkfontcombo_prop_info[] = {
	{ "name_combo", PHPG_PROP_READ_FN(GtkFontCombo, name_combo), NULL },
	{ "size_combo", PHPG_PROP_READ_FN(GtkFontCombo, size_combo), NULL },
	{ "bold_button", PHPG_PROP_READ_FN(GtkFontCombo, bold_button), NULL },
	{ "italic_button", PHPG_PROP_READ_FN(GtkFontCombo, italic_button), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkFontCombo, select)
{
	char *family;
	zend_bool free_family = FALSE, bold, italic;
	long height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ubbi", &family, &free_family, &bold, &italic, &height))
		return;

    gtk_font_combo_select(GTK_FONT_COMBO(PHPG_GOBJECT(this_ptr)), family, (gboolean)bold, (gboolean)italic, (gint)height);
	if (free_family) g_free(family);

}


static PHP_METHOD(GtkFontCombo, select_nth)
{
	long n, height;
	zend_bool bold, italic;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ibbi", &n, &bold, &italic, &height))
		return;

    gtk_font_combo_select_nth(GTK_FONT_COMBO(PHPG_GOBJECT(this_ptr)), (gint)n, (gboolean)bold, (gboolean)italic, (gint)height);

}


static PHP_METHOD(GtkFontCombo, get_font_height)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_font_combo_get_font_height(GTK_FONT_COMBO(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkFontCombo, get_font_description)
{
	PangoFontDescription *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_font_combo_get_font_description(GTK_FONT_COMBO(PHPG_GOBJECT(this_ptr)));
	phpg_gboxed_new(&return_value, PANGO_TYPE_FONT_DESCRIPTION, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkFontCombo, get_gdkfont)
{
	GdkFont *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_font_combo_get_gdkfont(GTK_FONT_COMBO(PHPG_GOBJECT(this_ptr)));
	phpg_gboxed_new(&return_value, GDK_TYPE_FONT, php_retval, TRUE, TRUE TSRMLS_CC);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfontcombo_select, 0)
    ZEND_ARG_INFO(0, family)
    ZEND_ARG_INFO(0, bold)
    ZEND_ARG_INFO(0, italic)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfontcombo_select_nth, 0)
    ZEND_ARG_INFO(0, n)
    ZEND_ARG_INFO(0, bold)
    ZEND_ARG_INFO(0, italic)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static function_entry gtkfontcombo_methods[] = {
	PHP_ME(GtkFontCombo, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFontCombo, get_font_description, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFontCombo, get_font_height,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFontCombo, get_gdkfont,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFontCombo, select,               arginfo_gtk_gtkfontcombo_select, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFontCombo, select_nth,           arginfo_gtk_gtkfontcombo_select_nth, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

PHPG_PROP_READER(GtkIconFileSel, path_label)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->path_label;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, dir_tree)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->dir_tree;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, file_list)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->file_list;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, history_combo)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->history_combo;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, up_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->up_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, refresh_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->refresh_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, home_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->home_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, file_entry)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->file_entry;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, filter_entry)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->filter_entry;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, ok_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->ok_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, cancel_button)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->cancel_button;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconFileSel, action_area)
{
	GtkWidget* php_retval;

    php_retval = GTK_ICON_FILE_SEL(((phpg_gobject_t *)object)->obj)->action_area;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkiconfilesel_prop_info[] = {
	{ "path_label", PHPG_PROP_READ_FN(GtkIconFileSel, path_label), NULL },
	{ "dir_tree", PHPG_PROP_READ_FN(GtkIconFileSel, dir_tree), NULL },
	{ "file_list", PHPG_PROP_READ_FN(GtkIconFileSel, file_list), NULL },
	{ "history_combo", PHPG_PROP_READ_FN(GtkIconFileSel, history_combo), NULL },
	{ "up_button", PHPG_PROP_READ_FN(GtkIconFileSel, up_button), NULL },
	{ "refresh_button", PHPG_PROP_READ_FN(GtkIconFileSel, refresh_button), NULL },
	{ "home_button", PHPG_PROP_READ_FN(GtkIconFileSel, home_button), NULL },
	{ "file_entry", PHPG_PROP_READ_FN(GtkIconFileSel, file_entry), NULL },
	{ "filter_entry", PHPG_PROP_READ_FN(GtkIconFileSel, filter_entry), NULL },
	{ "ok_button", PHPG_PROP_READ_FN(GtkIconFileSel, ok_button), NULL },
	{ "cancel_button", PHPG_PROP_READ_FN(GtkIconFileSel, cancel_button), NULL },
	{ "action_area", PHPG_PROP_READ_FN(GtkIconFileSel, action_area), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkIconList, __construct)
{
	long icon_width;
	GtkIconListMode mode;
	zval *php_mode = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iV", &icon_width, &php_mode)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkIconList);
	}

	if (php_mode && phpg_gvalue_get_enum(GTK_TYPE_ICON_LIST_MODE, php_mode, (gint *)&mode) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkIconList);
	}

	wrapped_obj = (GObject *) gtk_icon_list_new((guint)icon_width, mode);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkIconList);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkIconList, num_icons)
{
	long php_retval;

    php_retval = GTK_ICON_LIST(((phpg_gobject_t *)object)->obj)->num_icons;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


static prop_info_t gtkiconlist_prop_info[] = {
	{ "num_icons", PHPG_PROP_READ_FN(GtkIconList, num_icons), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkIconList, construct)
{
	long icon_width;
	GtkIconListMode mode;
	zval *php_mode = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iV", &icon_width, &php_mode))
		return;

	if (php_mode && phpg_gvalue_get_enum(GTK_TYPE_ICON_LIST_MODE, php_mode, (gint *)&mode) == FAILURE) {
		return;
	}

    gtk_icon_list_construct(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)icon_width, mode);

}


static PHP_METHOD(GtkIconList, set_mode)
{
	GtkIconListMode mode;
	zval *php_mode = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_mode))
		return;

	if (php_mode && phpg_gvalue_get_enum(GTK_TYPE_ICON_LIST_MODE, php_mode, (gint *)&mode) == FAILURE) {
		return;
	}

    gtk_icon_list_set_mode(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), mode);

}


static PHP_METHOD(GtkIconList, get_mode)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_mode(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, set_editable)
{
	zend_bool editable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &editable))
		return;

    gtk_icon_list_set_editable(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (gboolean)editable);

}


static PHP_METHOD(GtkIconList, is_editable)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_is_editable(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkIconList, set_row_spacing)
{
	long spacing;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &spacing))
		return;

    gtk_icon_list_set_row_spacing(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)spacing);

}


static PHP_METHOD(GtkIconList, get_row_spacing)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_row_spacing(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, set_col_spacing)
{
	long spacing;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &spacing))
		return;

    gtk_icon_list_set_col_spacing(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)spacing);

}


static PHP_METHOD(GtkIconList, get_col_spacing)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_col_spacing(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, set_text_space)
{
	long space;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &space))
		return;

    gtk_icon_list_set_text_space(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)space);

}


static PHP_METHOD(GtkIconList, get_text_space)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_text_space(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, set_icon_border)
{
	long space;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &space))
		return;

    gtk_icon_list_set_icon_border(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)space);

}


static PHP_METHOD(GtkIconList, get_icon_border)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_icon_border(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, set_icon_width)
{
	long space;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &space))
		return;

    gtk_icon_list_set_icon_width(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)space);

}


static PHP_METHOD(GtkIconList, get_icon_width)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_icon_width(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, freeze)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_icon_list_freeze(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkIconList, thaw)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_icon_list_thaw(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkIconList, set_background)
{
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_set_background(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), color);

}


static PHP_METHOD(GtkIconList, get_nth)
{
	long n;
	GtkIconListItem *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &n))
		return;

    php_retval = gtk_icon_list_get_nth(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)n);
	phpg_gboxed_new(&return_value, GTK_TYPE_ICON_LIST_ITEM, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkIconList, get_index)
{
	GtkIconListItem *item = NULL;
	zval *php_item;
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_item, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_item, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        item = (GtkIconListItem *) PHPG_GBOXED(php_item);
    } else {
        php_error(E_WARNING, "%s::%s() expects item argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_icon_list_get_index(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), item);
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkIconList, remove)
{
	GtkIconListItem *item = NULL;
	zval *php_item;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_item, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_item, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        item = (GtkIconListItem *) PHPG_GBOXED(php_item);
    } else {
        php_error(E_WARNING, "%s::%s() expects item argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_remove(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), item);

}


static PHP_METHOD(GtkIconList, set_active_icon)
{
	GtkIconListItem *icon = NULL;
	zval *php_icon;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_icon, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_icon, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        icon = (GtkIconListItem *) PHPG_GBOXED(php_icon);
    } else {
        php_error(E_WARNING, "%s::%s() expects icon argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_set_active_icon(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), icon);

}


static PHP_METHOD(GtkIconList, remove_nth)
{
	long n;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &n))
		return;

    gtk_icon_list_remove_nth(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (guint)n);

}


static PHP_METHOD(GtkIconList, update)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_icon_list_update(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkIconList, clear)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_icon_list_clear(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkIconList, get_icon_at)
{
	long x, y;
	GtkIconListItem *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &x, &y))
		return;

    php_retval = gtk_icon_list_get_icon_at(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (gint)x, (gint)y);
	phpg_gboxed_new(&return_value, GTK_TYPE_ICON_LIST_ITEM, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkIconList, get_active_icon)
{
	GtkIconListItem *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_active_icon(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));
	phpg_gboxed_new(&return_value, GTK_TYPE_ICON_LIST_ITEM, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkIconList, set_label)
{
	GtkIconListItem *item = NULL;
	zval *php_item;
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Ou", &php_item, gboxed_ce, &label, &free_label))
		return;

    if (phpg_gboxed_check(php_item, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        item = (GtkIconListItem *) PHPG_GBOXED(php_item);
    } else {
        php_error(E_WARNING, "%s::%s() expects item argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_set_label(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), item, label);
	if (free_label) g_free(label);

}


static PHP_METHOD(GtkIconList, set_selection_mode)
{
	long mode;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &mode))
		return;

    gtk_icon_list_set_selection_mode(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), (gint)mode);

}


static PHP_METHOD(GtkIconList, select_icon)
{
	GtkIconListItem *item = NULL;
	zval *php_item;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_item, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_item, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        item = (GtkIconListItem *) PHPG_GBOXED(php_item);
    } else {
        php_error(E_WARNING, "%s::%s() expects item argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_select_icon(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), item);

}


static PHP_METHOD(GtkIconList, unselect_icon)
{
	GtkIconListItem *item = NULL;
	zval *php_item;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_item, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_item, GTK_TYPE_ICON_LIST_ITEM, FALSE TSRMLS_CC)) {
        item = (GtkIconListItem *) PHPG_GBOXED(php_item);
    } else {
        php_error(E_WARNING, "%s::%s() expects item argument to be a valid GtkIconListItem object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_icon_list_unselect_icon(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)), item);

}


static PHP_METHOD(GtkIconList, unselect_all)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_icon_list_unselect_all(GTK_ICON_LIST(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_gtk_icon_list_new, 0)
    ZEND_ARG_INFO(0, icon_width)
    ZEND_ARG_OBJ_INFO(0, mode, GtkIconListMode, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_construct, 0)
    ZEND_ARG_INFO(0, icon_width)
    ZEND_ARG_OBJ_INFO(0, mode, GtkIconListMode, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_mode, 0)
    ZEND_ARG_OBJ_INFO(0, mode, GtkIconListMode, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_editable, 0)
    ZEND_ARG_INFO(0, editable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_row_spacing, 0)
    ZEND_ARG_INFO(0, spacing)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_col_spacing, 0)
    ZEND_ARG_INFO(0, spacing)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_text_space, 0)
    ZEND_ARG_INFO(0, space)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_icon_border, 0)
    ZEND_ARG_INFO(0, space)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_icon_width, 0)
    ZEND_ARG_INFO(0, space)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_background, 0)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_get_nth, 0)
    ZEND_ARG_INFO(0, n)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_get_index, 0)
    ZEND_ARG_OBJ_INFO(0, item, GtkIconListItem, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_remove, 0)
    ZEND_ARG_OBJ_INFO(0, item, GtkIconListItem, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_active_icon, 0)
    ZEND_ARG_OBJ_INFO(0, icon, GtkIconListItem, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_remove_nth, 0)
    ZEND_ARG_INFO(0, n)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_get_icon_at, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_label, 0)
    ZEND_ARG_OBJ_INFO(0, item, GtkIconListItem, 1)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_set_selection_mode, 0)
    ZEND_ARG_INFO(0, mode)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_select_icon, 0)
    ZEND_ARG_OBJ_INFO(0, item, GtkIconListItem, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlist_unselect_icon, 0)
    ZEND_ARG_OBJ_INFO(0, item, GtkIconListItem, 1)
ZEND_END_ARG_INFO();

static function_entry gtkiconlist_methods[] = {
	PHP_ME(GtkIconList, __construct,          arginfo_gtk_gtkiconlist_gtk_icon_list_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, clear,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, construct,            arginfo_gtk_gtkiconlist_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, freeze,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_active_icon,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_col_spacing,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_icon_at,          arginfo_gtk_gtkiconlist_get_icon_at, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_icon_border,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_icon_width,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_index,            arginfo_gtk_gtkiconlist_get_index, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_mode,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_nth,              arginfo_gtk_gtkiconlist_get_nth, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_row_spacing,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, get_text_space,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, is_editable,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, remove,               arginfo_gtk_gtkiconlist_remove, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, remove_nth,           arginfo_gtk_gtkiconlist_remove_nth, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, select_icon,          arginfo_gtk_gtkiconlist_select_icon, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_active_icon,      arginfo_gtk_gtkiconlist_set_active_icon, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_background,       arginfo_gtk_gtkiconlist_set_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_col_spacing,      arginfo_gtk_gtkiconlist_set_col_spacing, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_editable,         arginfo_gtk_gtkiconlist_set_editable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_icon_border,      arginfo_gtk_gtkiconlist_set_icon_border, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_icon_width,       arginfo_gtk_gtkiconlist_set_icon_width, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_label,            arginfo_gtk_gtkiconlist_set_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_mode,             arginfo_gtk_gtkiconlist_set_mode, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_row_spacing,      arginfo_gtk_gtkiconlist_set_row_spacing, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_selection_mode,   arginfo_gtk_gtkiconlist_set_selection_mode, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, set_text_space,       arginfo_gtk_gtkiconlist_set_text_space, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, thaw,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, unselect_all,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, unselect_icon,        arginfo_gtk_gtkiconlist_unselect_icon, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconList, update,               NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkFileList, __construct)
{
	long icon_width, mode;
	char *path = NULL;
	zend_bool free_path = FALSE;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii|u", &icon_width, &mode, &path, &free_path)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkFileList);
	}

	wrapped_obj = (GObject *) gtk_file_list_new((guint)icon_width, (gint)mode, path);
	if (free_path) g_free(path);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkFileList);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkFileList, construct)
{
	long icon_width, mode;
	char *path;
	zend_bool free_path = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &icon_width, &mode, &path, &free_path))
		return;

    gtk_file_list_construct(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)), (guint)icon_width, (gint)mode, path);
	if (free_path) g_free(path);

}


static PHP_METHOD(GtkFileList, set_filter)
{
	char *filter;
	zend_bool free_filter = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &filter, &free_filter))
		return;

    gtk_file_list_set_filter(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)), filter);
	if (free_filter) g_free(filter);

}


static PHP_METHOD(GtkFileList, open_dir)
{
	char *path;
	zend_bool free_path = FALSE;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &path, &free_path))
		return;

    php_retval = gtk_file_list_open_dir(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)), path);
	if (free_path) g_free(path);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkFileList, get_path)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_file_list_get_path(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkFileList, get_filename)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_file_list_get_filename(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkFileList, get_filetype)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_file_list_get_filetype(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkFileList, add_type_with_pixmap)
{
	zval *pixmap, *mask;
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &pixmap, gdkpixmap_ce, &mask, gdkpixmap_ce))
		return;

    php_retval = gtk_file_list_add_type_with_pixmap(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)), GDK_PIXMAP(PHPG_GOBJECT(pixmap)), GDK_PIXMAP(PHPG_GOBJECT(mask)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkFileList, add_type_filter)
{
	long type;
	char *filter;
	zend_bool free_filter = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iu", &type, &filter, &free_filter))
		return;

    gtk_file_list_add_type_filter(GTK_FILE_LIST(PHPG_GOBJECT(this_ptr)), (gint)type, filter);
	if (free_filter) g_free(filter);

}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkfilelist_gtk_file_list_new, 0, 0, 2)
    ZEND_ARG_INFO(0, icon_width)
    ZEND_ARG_INFO(0, mode)
    ZEND_ARG_INFO(0, path)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfilelist_construct, 0)
    ZEND_ARG_INFO(0, icon_width)
    ZEND_ARG_INFO(0, mode)
    ZEND_ARG_INFO(0, path)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfilelist_set_filter, 0)
    ZEND_ARG_INFO(0, filter)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfilelist_open_dir, 0)
    ZEND_ARG_INFO(0, path)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfilelist_add_type_with_pixmap, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkfilelist_add_type_filter, 0)
    ZEND_ARG_INFO(0, type)
    ZEND_ARG_INFO(0, filter)
ZEND_END_ARG_INFO();

static function_entry gtkfilelist_methods[] = {
	PHP_ME(GtkFileList, __construct,          arginfo_gtk_gtkfilelist_gtk_file_list_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, add_type_filter,      arginfo_gtk_gtkfilelist_add_type_filter, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, add_type_with_pixmap, arginfo_gtk_gtkfilelist_add_type_with_pixmap, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, construct,            arginfo_gtk_gtkfilelist_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, get_filename,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, get_filetype,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, get_path,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, open_dir,             arginfo_gtk_gtkfilelist_open_dir, ZEND_ACC_PUBLIC)
	PHP_ME(GtkFileList, set_filter,           arginfo_gtk_gtkfilelist_set_filter, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkItemEntry, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkItemEntry);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkItemEntry);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkItemEntry, new_with_max_length)
{
	long max;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &max)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkItemEntry);
	}

	wrapped_obj = (GObject *) gtk_item_entry_new_with_max_length((gint)max);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkItemEntry);
	}
    phpg_gobject_new(&return_value, wrapped_obj TSRMLS_CC);
    g_object_unref(wrapped_obj); /* phpg_gobject_new() increments reference count */
}


static PHP_METHOD(GtkItemEntry, set_text)
{
	char *text;
	zend_bool free_text = FALSE;
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uV", &text, &free_text, &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_item_entry_set_text(GTK_ITEM_ENTRY(PHPG_GOBJECT(this_ptr)), text, justification);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkItemEntry, set_justification)
{
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_item_entry_set_justification(GTK_ITEM_ENTRY(PHPG_GOBJECT(this_ptr)), justification);

}


static PHP_METHOD(GtkItemEntry, set_cursor_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_item_entry_set_cursor_visible(GTK_ITEM_ENTRY(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkItemEntry, get_cursor_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_item_entry_get_cursor_visible(GTK_ITEM_ENTRY(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkitementry_gtk_item_entry_new_with_max_length, 0)
    ZEND_ARG_INFO(0, max)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkitementry_set_text, 0)
    ZEND_ARG_INFO(0, text)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkitementry_set_justification, 0)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkitementry_set_cursor_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static function_entry gtkitementry_methods[] = {
	PHP_ME(GtkItemEntry, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkItemEntry, new_with_max_length,  arginfo_gtk_gtkitementry_gtk_item_entry_new_with_max_length, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkItemEntry, get_cursor_visible,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkItemEntry, set_cursor_visible,   arginfo_gtk_gtkitementry_set_cursor_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkItemEntry, set_justification,    arginfo_gtk_gtkitementry_set_justification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkItemEntry, set_text,             arginfo_gtk_gtkitementry_set_text, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvas, __construct)
{
	long width, height;
	double magnification = 1.0;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii|d", &width, &height, &magnification)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvas);
	}

	wrapped_obj = (GObject *) gtk_plot_canvas_new((gint)width, (gint)height, magnification);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvas);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkPlotCanvas, flags)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS(((phpg_gobject_t *)object)->obj)->flags;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvas, pixmap)
{
	GdkPixmap* php_retval;

    php_retval = GTK_PLOT_CANVAS(((phpg_gobject_t *)object)->obj)->pixmap;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkplotcanvas_prop_info[] = {
	{ "flags", PHPG_PROP_READ_FN(GtkPlotCanvas, flags), NULL },
	{ "pixmap", PHPG_PROP_READ_FN(GtkPlotCanvas, pixmap), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkPlotCanvas, construct)
{
	long width, height;
	double magnification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iid", &width, &height, &magnification))
		return;

    gtk_plot_canvas_construct(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), (gint)width, (gint)height, magnification);

}


static PHP_METHOD(GtkPlotCanvas, set_pc)
{
	zval *pc;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &pc, gtkplotpc_ce))
		return;

    gtk_plot_canvas_set_pc(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_PC(PHPG_GOBJECT(pc)));

}


static PHP_METHOD(GtkPlotCanvas, paint)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_paint(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, refresh)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_refresh(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, freeze)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_freeze(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, thaw)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_thaw(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, grid_set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_canvas_grid_set_visible(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotCanvas, grid_set_step)
{
	double step;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &step))
		return;

    gtk_plot_canvas_grid_set_step(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), step);

}


static PHP_METHOD(GtkPlotCanvas, grid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	long width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ViO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_canvas_grid_set_attributes(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), style, (gint)width, color);

}


static PHP_METHOD(GtkPlotCanvas, cancel_action)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_cancel_action(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, unselect)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_canvas_unselect(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotCanvas, get_active_item)
{
	GtkPlotCanvasChild* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_canvas_get_active_item(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCanvas, set_size)
{
	long width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &width, &height))
		return;

    gtk_plot_canvas_set_size(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), (gint)width, (gint)height);

}


static PHP_METHOD(GtkPlotCanvas, set_magnification)
{
	double magnification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &magnification))
		return;

    gtk_plot_canvas_set_magnification(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), magnification);

}


static PHP_METHOD(GtkPlotCanvas, set_transparent)
{
	zend_bool transparent;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &transparent))
		return;

    gtk_plot_canvas_set_transparent(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), (gboolean)transparent);

}


static PHP_METHOD(GtkPlotCanvas, transparent)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_canvas_transparent(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotCanvas, set_background)
{
	GdkColor *background = NULL;
	zval *php_background;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_background, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_canvas_set_background(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), background);

}


static PHP_METHOD(GtkPlotCanvas, put_child)
{
	zval *child;
	double x1, y1, x2, y2;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odddd", &child, gtkplotcanvaschild_ce, &x1, &y1, &x2, &y2))
		return;

    gtk_plot_canvas_put_child(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(child)), x1, y1, x2, y2);

}


static PHP_METHOD(GtkPlotCanvas, remove_child)
{
	zval *child;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &child, gtkplotcanvaschild_ce))
		return;

    gtk_plot_canvas_remove_child(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(child)));

}


static PHP_METHOD(GtkPlotCanvas, child_move)
{
	zval *child;
	double x1, y1;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &child, gtkplotcanvaschild_ce, &x1, &y1))
		return;

    gtk_plot_canvas_child_move(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(child)), x1, y1);

}


static PHP_METHOD(GtkPlotCanvas, child_move_resize)
{
	zval *child;
	double x1, y1, x2, y2;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odddd", &child, gtkplotcanvaschild_ce, &x1, &y1, &x2, &y2))
		return;

    gtk_plot_canvas_child_move_resize(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(child)), x1, y1, x2, y2);

}


static PHP_METHOD(GtkPlotCanvas, export_ps)
{
	char *file_name;
	zend_bool free_file_name = FALSE, epsflag = FALSE;
	GtkPlotPageOrientation orient = GTK_PLOT_PORTRAIT;
	zval *php_orient = NULL, *php_page_size = NULL;
	GtkPlotPageSize page_size = GTK_PLOT_LETTER;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u|VbV", &file_name, &free_file_name, &php_orient, &epsflag, &php_page_size))
		return;

	if (php_orient && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PAGE_ORIENTATION, php_orient, (gint *)&orient) == FAILURE) {
		return;
	}

	if (php_page_size && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PAGE_SIZE, php_page_size, (gint *)&page_size) == FAILURE) {
		return;
	}

    php_retval = gtk_plot_canvas_export_ps(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), file_name, orient, (gboolean)epsflag, page_size);
	if (free_file_name) g_free(file_name);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotCanvas, export_ps_with_size)
{
	char *file_name;
	zend_bool free_file_name = FALSE, epsflag = GTK_PLOT_PORTRAIT;
	GtkPlotPageOrientation orient = GTK_PLOT_PORTRAIT;
	zval *php_orient = NULL, *php_units = NULL;
	GtkPlotUnits units = GTK_PLOT_PSPOINTS;
	long width = GTK_PLOT_LETTER_W, height = GTK_PLOT_LETTER_H;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u|VbVii", &file_name, &free_file_name, &php_orient, &epsflag, &php_units, &width, &height))
		return;

	if (php_orient && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PAGE_ORIENTATION, php_orient, (gint *)&orient) == FAILURE) {
		return;
	}

	if (php_units && phpg_gvalue_get_enum(GTK_TYPE_PLOT_UNITS, php_units, (gint *)&units) == FAILURE) {
		return;
	}

    php_retval = gtk_plot_canvas_export_ps_with_size(GTK_PLOT_CANVAS(PHPG_GOBJECT(this_ptr)), file_name, orient, (gboolean)epsflag, units, (gint)width, (gint)height);
	if (free_file_name) g_free(file_name);
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotcanvas_gtk_plot_canvas_new, 0, 0, 2)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, magnification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_construct, 0)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, magnification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_set_pc, 0)
    ZEND_ARG_OBJ_INFO(0, pc, GtkPlotPC, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_grid_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_grid_set_step, 0)
    ZEND_ARG_INFO(0, step)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_grid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_set_size, 0)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_set_magnification, 0)
    ZEND_ARG_INFO(0, magnification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_set_transparent, 0)
    ZEND_ARG_INFO(0, transparent)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_set_background, 0)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_put_child, 0)
    ZEND_ARG_OBJ_INFO(0, child, GtkPlotCanvasChild, 1)
    ZEND_ARG_INFO(0, x1)
    ZEND_ARG_INFO(0, y1)
    ZEND_ARG_INFO(0, x2)
    ZEND_ARG_INFO(0, y2)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_remove_child, 0)
    ZEND_ARG_OBJ_INFO(0, child, GtkPlotCanvasChild, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_child_move, 0)
    ZEND_ARG_OBJ_INFO(0, child, GtkPlotCanvasChild, 1)
    ZEND_ARG_INFO(0, x1)
    ZEND_ARG_INFO(0, y1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvas_child_move_resize, 0)
    ZEND_ARG_OBJ_INFO(0, child, GtkPlotCanvasChild, 1)
    ZEND_ARG_INFO(0, x1)
    ZEND_ARG_INFO(0, y1)
    ZEND_ARG_INFO(0, x2)
    ZEND_ARG_INFO(0, y2)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotcanvas_export_ps, 0, 0, 1)
    ZEND_ARG_INFO(0, file_name)
    ZEND_ARG_OBJ_INFO(0, orient, GtkPlotPageOrientation, 1)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_OBJ_INFO(0, page_size, GtkPlotPageSize, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotcanvas_export_ps_with_size, 0, 0, 1)
    ZEND_ARG_INFO(0, file_name)
    ZEND_ARG_OBJ_INFO(0, orient, GtkPlotPageOrientation, 1)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_OBJ_INFO(0, units, GtkPlotUnits, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvas_methods[] = {
	PHP_ME(GtkPlotCanvas, __construct,          arginfo_gtk_gtkplotcanvas_gtk_plot_canvas_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, cancel_action,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, child_move,           arginfo_gtk_gtkplotcanvas_child_move, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, child_move_resize,    arginfo_gtk_gtkplotcanvas_child_move_resize, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, construct,            arginfo_gtk_gtkplotcanvas_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, export_ps,            arginfo_gtk_gtkplotcanvas_export_ps, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, export_ps_with_size,  arginfo_gtk_gtkplotcanvas_export_ps_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, freeze,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, get_active_item,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, grid_set_attributes,  arginfo_gtk_gtkplotcanvas_grid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, grid_set_step,        arginfo_gtk_gtkplotcanvas_grid_set_step, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, grid_set_visible,     arginfo_gtk_gtkplotcanvas_grid_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, paint,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, put_child,            arginfo_gtk_gtkplotcanvas_put_child, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, refresh,              NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, remove_child,         arginfo_gtk_gtkplotcanvas_remove_child, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, set_background,       arginfo_gtk_gtkplotcanvas_set_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, set_magnification,    arginfo_gtk_gtkplotcanvas_set_magnification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, set_pc,               arginfo_gtk_gtkplotcanvas_set_pc, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, set_size,             arginfo_gtk_gtkplotcanvas_set_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, set_transparent,      arginfo_gtk_gtkplotcanvas_set_transparent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, thaw,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, transparent,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvas, unselect,             NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlot, __construct)
{
	GdkDrawable *drawable = NULL;
	zval *php_drawable = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|O", &php_drawable, gdkdrawable_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlot);
	}
    if (php_drawable)
        drawable = GDK_DRAWABLE(PHPG_GOBJECT(php_drawable));

	wrapped_obj = (GObject *) gtk_plot_new(drawable);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlot);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlot, construct)
{
	zval *drawable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce))
		return;

    gtk_plot_construct(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

}


static PHP_METHOD(GtkPlot, construct_with_size)
{
	zval *drawable;
	double width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &drawable, gdkdrawable_ce, &width, &height))
		return;

    gtk_plot_construct_with_size(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)), width, height);

}


static PHP_METHOD(GtkPlot, set_drawable)
{
	zval *drawable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce))
		return;

    gtk_plot_set_drawable(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

}


static PHP_METHOD(GtkPlot, get_drawable)
{
	GdkDrawable* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_get_drawable(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlot, set_pc)
{
	zval *pc;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &pc, gtkplotpc_ce))
		return;

    gtk_plot_set_pc(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GTK_PLOT_PC(PHPG_GOBJECT(pc)));

}


static PHP_METHOD(GtkPlot, set_background_pixmap)
{
	zval *pixmap;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &pixmap, gdkpixmap_ce))
		return;

    gtk_plot_set_background_pixmap(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GDK_PIXMAP(PHPG_GOBJECT(pixmap)));

}


static PHP_METHOD(GtkPlot, set_transparent)
{
	zend_bool transparent;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &transparent))
		return;

    gtk_plot_set_transparent(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)transparent);

}


static PHP_METHOD(GtkPlot, is_transparent)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_is_transparent(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, set_background)
{
	GdkColor *background = NULL;
	zval *php_background;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_background, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_set_background(GTK_PLOT(PHPG_GOBJECT(this_ptr)), background);

}


static PHP_METHOD(GtkPlot, paint)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_paint(GTK_PLOT(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot, refresh)
{
	GdkRectangle area_arg = { 0, 0, 0, 0 }, *area;
	zval *php_area = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|V", &php_area))
		return;

    if (Z_TYPE_P(php_area) == IS_NULL) {
        area = NULL;
    } else if (phpg_rectangle_from_zval(php_area, (GdkRectangle*)&area_arg TSRMLS_CC) == SUCCESS) {
        area = &area_arg;
    } else {
        php_error(E_WARNING, "%s::%s() expects area argument to be a 4-element array, a GdkRectangle object, or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }
    gtk_plot_refresh(GTK_PLOT(PHPG_GOBJECT(this_ptr)), area);

}


static PHP_METHOD(GtkPlot, move)
{
	double x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &x, &y))
		return;

    gtk_plot_move(GTK_PLOT(PHPG_GOBJECT(this_ptr)), x, y);

}


static PHP_METHOD(GtkPlot, resize)
{
	double width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &width, &height))
		return;

    gtk_plot_resize(GTK_PLOT(PHPG_GOBJECT(this_ptr)), width, height);

}


static PHP_METHOD(GtkPlot, set_magnification)
{
	double magnification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &magnification))
		return;

    gtk_plot_set_magnification(GTK_PLOT(PHPG_GOBJECT(this_ptr)), magnification);

}


static PHP_METHOD(GtkPlot, move_resize)
{
	double x, y, width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dddd", &x, &y, &width, &height))
		return;

    gtk_plot_move_resize(GTK_PLOT(PHPG_GOBJECT(this_ptr)), x, y, width, height);

}


static PHP_METHOD(GtkPlot, clip_data)
{
	zend_bool clip;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &clip))
		return;

    gtk_plot_clip_data(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)clip);

}


static PHP_METHOD(GtkPlot, set_xrange)
{
	double xmin, xmax;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &xmin, &xmax))
		return;

    gtk_plot_set_xrange(GTK_PLOT(PHPG_GOBJECT(this_ptr)), xmin, xmax);

}


static PHP_METHOD(GtkPlot, set_yrange)
{
	double ymin, ymax;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &ymin, &ymax))
		return;

    gtk_plot_set_yrange(GTK_PLOT(PHPG_GOBJECT(this_ptr)), ymin, ymax);

}


static PHP_METHOD(GtkPlot, set_range)
{
	double xmin, xmax, ymin, ymax;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dddd", &xmin, &xmax, &ymin, &ymax))
		return;

    gtk_plot_set_range(GTK_PLOT(PHPG_GOBJECT(this_ptr)), xmin, xmax, ymin, ymax);

}


static PHP_METHOD(GtkPlot, autoscale)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_autoscale(GTK_PLOT(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot, set_xscale)
{
	GtkPlotScale scale_type;
	zval *php_scale_type = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_scale_type))
		return;

	if (php_scale_type && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale_type, (gint *)&scale_type) == FAILURE) {
		return;
	}

    gtk_plot_set_xscale(GTK_PLOT(PHPG_GOBJECT(this_ptr)), scale_type);

}


static PHP_METHOD(GtkPlot, set_yscale)
{
	GtkPlotScale scale_type;
	zval *php_scale_type = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_scale_type))
		return;

	if (php_scale_type && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale_type, (gint *)&scale_type) == FAILURE) {
		return;
	}

    gtk_plot_set_yscale(GTK_PLOT(PHPG_GOBJECT(this_ptr)), scale_type);

}


static PHP_METHOD(GtkPlot, get_xscale)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_get_xscale(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlot, get_yscale)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_get_yscale(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlot, reflect_x)
{
	zend_bool reflect;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &reflect))
		return;

    gtk_plot_reflect_x(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)reflect);

}


static PHP_METHOD(GtkPlot, reflect_y)
{
	zend_bool reflect;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &reflect))
		return;

    gtk_plot_reflect_y(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)reflect);

}


static PHP_METHOD(GtkPlot, is_x_reflected)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_is_x_reflected(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, is_y_reflected)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_is_y_reflected(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, set_ticks)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	double major_step;
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vdi", &php_orientation, &major_step, &nminor))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_set_ticks(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orientation, major_step, (gint)nminor);

}


static PHP_METHOD(GtkPlot, set_major_ticks)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	double major_step;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vd", &php_orientation, &major_step))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_set_major_ticks(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orientation, major_step);

}


static PHP_METHOD(GtkPlot, set_minor_ticks)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_orientation, &nminor))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_set_minor_ticks(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orientation, (gint)nminor);

}


static PHP_METHOD(GtkPlot, set_ticks_limits)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	double begin, end;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vdd", &php_orientation, &begin, &end))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_set_ticks_limits(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orientation, begin, end);

}


static PHP_METHOD(GtkPlot, unset_ticks_limits)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_unset_ticks_limits(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orientation);

}


static PHP_METHOD(GtkPlot, set_break)
{
	GtkPlotOrientation orient;
	zval *php_orient = NULL, *php_scale_after = NULL;
	double min, max, step_after, pos;
	long nminor_after;
	GtkPlotScale scale_after;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdddiVd", &php_orient, &min, &max, &step_after, &nminor_after, &php_scale_after, &pos))
		return;

	if (php_orient && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orient, (gint *)&orient) == FAILURE) {
		return;
	}

	if (php_scale_after && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale_after, (gint *)&scale_after) == FAILURE) {
		return;
	}

    gtk_plot_set_break(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orient, min, max, step_after, (gint)nminor_after, scale_after, pos);

}


static PHP_METHOD(GtkPlot, remove_break)
{
	GtkPlotOrientation orient;
	zval *php_orient = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orient))
		return;

	if (php_orient && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orient, (gint *)&orient) == FAILURE) {
		return;
	}

    gtk_plot_remove_break(GTK_PLOT(PHPG_GOBJECT(this_ptr)), orient);

}


static PHP_METHOD(GtkPlot, get_axis)
{
	GtkPlotAxisPos axis;
	zval *php_axis = NULL;
	GtkPlotAxis* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_axis))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_AXIS_POS, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    php_retval = gtk_plot_get_axis(GTK_PLOT(PHPG_GOBJECT(this_ptr)), axis);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlot, x0_set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_x0_set_visible(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlot, x0_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_x0_visible(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, y0_set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_y0_set_visible(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlot, y0_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_y0_visible(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, grids_set_on_top)
{
	zend_bool on_top;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &on_top))
		return;

    gtk_plot_grids_set_on_top(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)on_top);

}


static PHP_METHOD(GtkPlot, grids_on_top)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_grids_on_top(GTK_PLOT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot, grids_set_visible)
{
	zend_bool vmajor, vminor, hmajor, hminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "bbbb", &vmajor, &vminor, &hmajor, &hminor))
		return;

    gtk_plot_grids_set_visible(GTK_PLOT(PHPG_GOBJECT(this_ptr)), (gboolean)vmajor, (gboolean)vminor, (gboolean)hmajor, (gboolean)hminor);

}


static PHP_METHOD(GtkPlot, y0line_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_y0line_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, x0line_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_x0line_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, major_vgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_major_vgrid_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, minor_vgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_minor_vgrid_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, major_hgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_major_hgrid_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, minor_hgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_minor_hgrid_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot, show_legends)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_show_legends(GTK_PLOT(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot, hide_legends)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_hide_legends(GTK_PLOT(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot, set_legends_border)
{
	GtkPlotBorderStyle border;
	zval *php_border = NULL;
	long shadow_width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_border, &shadow_width))
		return;

	if (php_border && phpg_gvalue_get_enum(GTK_TYPE_PLOT_BORDER_STYLE, php_border, (gint *)&border) == FAILURE) {
		return;
	}

    gtk_plot_set_legends_border(GTK_PLOT(PHPG_GOBJECT(this_ptr)), border, (gint)shadow_width);

}


static PHP_METHOD(GtkPlot, legends_move)
{
	double x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &x, &y))
		return;

    gtk_plot_legends_move(GTK_PLOT(PHPG_GOBJECT(this_ptr)), x, y);

}


static PHP_METHOD(GtkPlot, legends_set_attributes)
{
	char *font = NULL;
	zend_bool free_font = FALSE;
	long height = NULL;
	GdkColor *foreground = NULL, *background = NULL;
	zval *php_foreground = NULL, *php_background = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|uiNN", &font, &free_font, &height, &php_foreground, gboxed_ce, &php_background, gboxed_ce))
		return;

    if (php_foreground) {
        if (Z_TYPE_P(php_foreground) == IS_NULL) {
            foreground = NULL;
        } else {
            if (phpg_gboxed_check(php_foreground, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
                foreground = (GdkColor *) PHPG_GBOXED(php_foreground);
            } else {
                php_error(E_WARNING, "%s::%s() expects foreground argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
                return;
            }
        }
    }

    if (php_background) {
        if (Z_TYPE_P(php_background) == IS_NULL) {
            background = NULL;
        } else {
            if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
                background = (GdkColor *) PHPG_GBOXED(php_background);
            } else {
                php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
                return;
            }
        }
    }

    gtk_plot_legends_set_attributes(GTK_PLOT(PHPG_GOBJECT(this_ptr)), font, (gint)height, foreground, background);
	if (free_font) g_free(font);

}


static PHP_METHOD(GtkPlot, add_data)
{
	zval *data;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &data, gtkplotdata_ce))
		return;

    gtk_plot_add_data(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GTK_PLOT_DATA(PHPG_GOBJECT(data)));

}


static PHP_METHOD(GtkPlot, remove_data)
{
	zval *data;
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &data, gtkplotdata_ce))
		return;

    php_retval = gtk_plot_remove_data(GTK_PLOT(PHPG_GOBJECT(this_ptr)), GTK_PLOT_DATA(PHPG_GOBJECT(data)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlot, export_ps_with_size)
{
	char *file_name;
	zend_bool free_file_name = FALSE, epsflag = FALSE;
	GtkPlotPageOrientation orient = GTK_PLOT_PORTRAIT;
	zval *php_orient = NULL, *php_units = NULL;
	GtkPlotUnits units = GTK_PLOT_PSPOINTS;
	long width = GTK_PLOT_LETTER_W, height = GTK_PLOT_LETTER_H;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u|VbVii", &file_name, &free_file_name, &php_orient, &epsflag, &php_units, &width, &height))
		return;

	if (php_orient && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PAGE_ORIENTATION, php_orient, (gint *)&orient) == FAILURE) {
		return;
	}

	if (php_units && phpg_gvalue_get_enum(GTK_TYPE_PLOT_UNITS, php_units, (gint *)&units) == FAILURE) {
		return;
	}

    php_retval = gtk_plot_export_ps_with_size(GTK_PLOT(PHPG_GOBJECT(this_ptr)), file_name, orient, (gboolean)epsflag, units, (gint)width, (gint)height);
	if (free_file_name) g_free(file_name);
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplot_gtk_plot_new, 0, 0, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_construct, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_construct_with_size, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_drawable, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_pc, 0)
    ZEND_ARG_OBJ_INFO(0, pc, GtkPlotPC, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_background_pixmap, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_transparent, 0)
    ZEND_ARG_INFO(0, transparent)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_background, 0)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplot_refresh, 0, 0, 0)
    ZEND_ARG_OBJ_INFO(0, area, GdkRectangle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_move, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_resize, 0)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_magnification, 0)
    ZEND_ARG_INFO(0, magnification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_move_resize, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_clip_data, 0)
    ZEND_ARG_INFO(0, clip)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_xrange, 0)
    ZEND_ARG_INFO(0, xmin)
    ZEND_ARG_INFO(0, xmax)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_yrange, 0)
    ZEND_ARG_INFO(0, ymin)
    ZEND_ARG_INFO(0, ymax)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_range, 0)
    ZEND_ARG_INFO(0, xmin)
    ZEND_ARG_INFO(0, xmax)
    ZEND_ARG_INFO(0, ymin)
    ZEND_ARG_INFO(0, ymax)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_xscale, 0)
    ZEND_ARG_OBJ_INFO(0, scale_type, GtkPlotScale, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_yscale, 0)
    ZEND_ARG_OBJ_INFO(0, scale_type, GtkPlotScale, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_reflect_x, 0)
    ZEND_ARG_INFO(0, reflect)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_reflect_y, 0)
    ZEND_ARG_INFO(0, reflect)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, major_step)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_major_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, major_step)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_minor_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_ticks_limits, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, begin)
    ZEND_ARG_INFO(0, end)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_unset_ticks_limits, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_break, 0)
    ZEND_ARG_OBJ_INFO(0, orient, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
    ZEND_ARG_INFO(0, step_after)
    ZEND_ARG_INFO(0, nminor_after)
    ZEND_ARG_OBJ_INFO(0, scale_after, GtkPlotScale, 1)
    ZEND_ARG_INFO(0, pos)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_remove_break, 0)
    ZEND_ARG_OBJ_INFO(0, orient, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_get_axis, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotAxisPos, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_x0_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_y0_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_grids_set_on_top, 0)
    ZEND_ARG_INFO(0, on_top)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_grids_set_visible, 0)
    ZEND_ARG_INFO(0, vmajor)
    ZEND_ARG_INFO(0, vminor)
    ZEND_ARG_INFO(0, hmajor)
    ZEND_ARG_INFO(0, hminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_y0line_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_x0line_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_major_vgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_minor_vgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_major_hgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_minor_hgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_set_legends_border, 0)
    ZEND_ARG_OBJ_INFO(0, border, GtkPlotBorderStyle, 1)
    ZEND_ARG_INFO(0, shadow_width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_legends_move, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplot_legends_set_attributes, 0, 0, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_OBJ_INFO(0, foreground, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_add_data, 0)
    ZEND_ARG_OBJ_INFO(0, data, GtkPlotData, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot_remove_data, 0)
    ZEND_ARG_OBJ_INFO(0, data, GtkPlotData, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplot_export_ps_with_size, 0, 0, 1)
    ZEND_ARG_INFO(0, file_name)
    ZEND_ARG_OBJ_INFO(0, orient, GtkPlotPageOrientation, 1)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_OBJ_INFO(0, units, GtkPlotUnits, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static function_entry gtkplot_methods[] = {
	PHP_ME(GtkPlot, __construct,          arginfo_gtk_gtkplot_gtk_plot_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, add_data,             arginfo_gtk_gtkplot_add_data, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, autoscale,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, clip_data,            arginfo_gtk_gtkplot_clip_data, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, construct,            arginfo_gtk_gtkplot_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, construct_with_size,  arginfo_gtk_gtkplot_construct_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, export_ps_with_size,  arginfo_gtk_gtkplot_export_ps_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, get_axis,             arginfo_gtk_gtkplot_get_axis, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, get_drawable,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, get_xscale,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, get_yscale,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, grids_on_top,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, grids_set_on_top,     arginfo_gtk_gtkplot_grids_set_on_top, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, grids_set_visible,    arginfo_gtk_gtkplot_grids_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, hide_legends,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, is_transparent,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, is_x_reflected,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, is_y_reflected,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, legends_move,         arginfo_gtk_gtkplot_legends_move, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, legends_set_attributes, arginfo_gtk_gtkplot_legends_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, major_hgrid_set_attributes, arginfo_gtk_gtkplot_major_hgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, major_vgrid_set_attributes, arginfo_gtk_gtkplot_major_vgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, minor_hgrid_set_attributes, arginfo_gtk_gtkplot_minor_hgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, minor_vgrid_set_attributes, arginfo_gtk_gtkplot_minor_vgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, move,                 arginfo_gtk_gtkplot_move, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, move_resize,          arginfo_gtk_gtkplot_move_resize, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, paint,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, reflect_x,            arginfo_gtk_gtkplot_reflect_x, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, reflect_y,            arginfo_gtk_gtkplot_reflect_y, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, refresh,              arginfo_gtk_gtkplot_refresh, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, remove_break,         arginfo_gtk_gtkplot_remove_break, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, remove_data,          arginfo_gtk_gtkplot_remove_data, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, resize,               arginfo_gtk_gtkplot_resize, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_background,       arginfo_gtk_gtkplot_set_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_background_pixmap, arginfo_gtk_gtkplot_set_background_pixmap, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_break,            arginfo_gtk_gtkplot_set_break, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_drawable,         arginfo_gtk_gtkplot_set_drawable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_legends_border,   arginfo_gtk_gtkplot_set_legends_border, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_magnification,    arginfo_gtk_gtkplot_set_magnification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_major_ticks,      arginfo_gtk_gtkplot_set_major_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_minor_ticks,      arginfo_gtk_gtkplot_set_minor_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_pc,               arginfo_gtk_gtkplot_set_pc, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_range,            arginfo_gtk_gtkplot_set_range, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_ticks,            arginfo_gtk_gtkplot_set_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_ticks_limits,     arginfo_gtk_gtkplot_set_ticks_limits, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_transparent,      arginfo_gtk_gtkplot_set_transparent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_xrange,           arginfo_gtk_gtkplot_set_xrange, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_xscale,           arginfo_gtk_gtkplot_set_xscale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_yrange,           arginfo_gtk_gtkplot_set_yrange, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, set_yscale,           arginfo_gtk_gtkplot_set_yscale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, show_legends,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, unset_ticks_limits,   arginfo_gtk_gtkplot_unset_ticks_limits, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, x0_set_visible,       arginfo_gtk_gtkplot_x0_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, x0_visible,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, x0line_set_attributes, arginfo_gtk_gtkplot_x0line_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, y0_set_visible,       arginfo_gtk_gtkplot_y0_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, y0_visible,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot, y0line_set_attributes, arginfo_gtk_gtkplot_y0line_set_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotArray, set_label)
{
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &label, &free_label))
		return;

    gtk_plot_array_set_label(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)), label);
	if (free_label) g_free(label);

}


static PHP_METHOD(GtkPlotArray, set_description)
{
	char *desc;
	zend_bool free_desc = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &desc, &free_desc))
		return;

    gtk_plot_array_set_description(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)), desc);
	if (free_desc) g_free(desc);

}


static PHP_METHOD(GtkPlotArray, set_scale)
{
	double scale;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &scale))
		return;

    gtk_plot_array_set_scale(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)), scale);

}


static PHP_METHOD(GtkPlotArray, set_required)
{
	zend_bool required;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &required))
		return;

    gtk_plot_array_set_required(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)), (gboolean)required);

}


static PHP_METHOD(GtkPlotArray, set_independent)
{
	zend_bool independent;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &independent))
		return;

    gtk_plot_array_set_independent(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)), (gboolean)independent);

}


static PHP_METHOD(GtkPlotArray, get_data_type)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_data_type(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotArray, get_name)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_name(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkPlotArray, get_label)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_label(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkPlotArray, get_description)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_description(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkPlotArray, required)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_required(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotArray, independent)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_independent(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotArray, get_scale)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_scale(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotArray, get_size)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_array_get_size(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotArray, free)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_array_free(GTK_PLOT_ARRAY(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarray_set_label, 0)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarray_set_description, 0)
    ZEND_ARG_INFO(0, desc)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarray_set_scale, 0)
    ZEND_ARG_INFO(0, scale)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarray_set_required, 0)
    ZEND_ARG_INFO(0, required)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarray_set_independent, 0)
    ZEND_ARG_INFO(0, independent)
ZEND_END_ARG_INFO();

static function_entry gtkplotarray_methods[] = {
#if ZEND_EXTENSION_API_NO > 220051025
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL, 0)
#else
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL)
#endif
	PHP_ME(GtkPlotArray, free,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_data_type,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_description,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_label,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_name,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_scale,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, get_size,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, independent,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, required,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, set_description,      arginfo_gtk_gtkplotarray_set_description, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, set_independent,      arginfo_gtk_gtkplotarray_set_independent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, set_label,            arginfo_gtk_gtkplotarray_set_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, set_required,         arginfo_gtk_gtkplotarray_set_required, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArray, set_scale,            arginfo_gtk_gtkplotarray_set_scale, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotArrayList, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotArrayList);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotArrayList);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotArrayList, add)
{
	zval *array;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &array, gtkplotarray_ce))
		return;

    gtk_plot_array_list_add(GTK_PLOT_ARRAY_LIST(PHPG_GOBJECT(this_ptr)), GTK_PLOT_ARRAY(PHPG_GOBJECT(array)));

}


static PHP_METHOD(GtkPlotArrayList, remove)
{
	zval *array;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &array, gtkplotarray_ce))
		return;

    gtk_plot_array_list_remove(GTK_PLOT_ARRAY_LIST(PHPG_GOBJECT(this_ptr)), GTK_PLOT_ARRAY(PHPG_GOBJECT(array)));

}


static PHP_METHOD(GtkPlotArrayList, get)
{
	char *name;
	zend_bool free_name = FALSE;
	GtkPlotArray* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &name, &free_name))
		return;

    php_retval = gtk_plot_array_list_get(GTK_PLOT_ARRAY_LIST(PHPG_GOBJECT(this_ptr)), name);
	if (free_name) g_free(name);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlotArrayList, clear)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_array_list_clear(GTK_PLOT_ARRAY_LIST(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarraylist_add, 0)
    ZEND_ARG_OBJ_INFO(0, array, GtkPlotArray, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarraylist_remove, 0)
    ZEND_ARG_OBJ_INFO(0, array, GtkPlotArray, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotarraylist_get, 0)
    ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO();

static function_entry gtkplotarraylist_methods[] = {
	PHP_ME(GtkPlotArrayList, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArrayList, add,                  arginfo_gtk_gtkplotarraylist_add, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArrayList, clear,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArrayList, get,                  arginfo_gtk_gtkplotarraylist_get, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotArrayList, remove,               arginfo_gtk_gtkplotarraylist_remove, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotAxis, __construct)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotAxis);
	}

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotAxis);
	}

	wrapped_obj = (GObject *) gtk_plot_axis_new(orientation);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotAxis);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkPlotAxis, is_visible)
{
	gboolean php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->is_visible;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, title_visible)
{
	gboolean php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->title_visible;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, orientation)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->orientation;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, major_mask)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->major_mask;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, minor_mask)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->minor_mask;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, ticks_length)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->ticks_length;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, ticks_width)
{
	double php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->ticks_width;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, custom_labels)
{
	gboolean php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->custom_labels;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, labels_offset)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->labels_offset;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, labels_prefix)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->labels_prefix;
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, labels_suffix)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->labels_suffix;
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, show_major_grid)
{
	gboolean php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->show_major_grid;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, show_minor_grid)
{
	gboolean php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->show_minor_grid;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, label_precision)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->label_precision;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, label_style)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->label_style;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, label_mask)
{
	long php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->label_mask;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotAxis, tick_labels)
{
	GtkPlotArray* php_retval;

    php_retval = GTK_PLOT_AXIS(((phpg_gobject_t *)object)->obj)->tick_labels;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkplotaxis_prop_info[] = {
	{ "is_visible", PHPG_PROP_READ_FN(GtkPlotAxis, is_visible), NULL },
	{ "title_visible", PHPG_PROP_READ_FN(GtkPlotAxis, title_visible), NULL },
	{ "orientation", PHPG_PROP_READ_FN(GtkPlotAxis, orientation), NULL },
	{ "major_mask", PHPG_PROP_READ_FN(GtkPlotAxis, major_mask), NULL },
	{ "minor_mask", PHPG_PROP_READ_FN(GtkPlotAxis, minor_mask), NULL },
	{ "ticks_length", PHPG_PROP_READ_FN(GtkPlotAxis, ticks_length), NULL },
	{ "ticks_width", PHPG_PROP_READ_FN(GtkPlotAxis, ticks_width), NULL },
	{ "custom_labels", PHPG_PROP_READ_FN(GtkPlotAxis, custom_labels), NULL },
	{ "labels_offset", PHPG_PROP_READ_FN(GtkPlotAxis, labels_offset), NULL },
	{ "labels_prefix", PHPG_PROP_READ_FN(GtkPlotAxis, labels_prefix), NULL },
	{ "labels_suffix", PHPG_PROP_READ_FN(GtkPlotAxis, labels_suffix), NULL },
	{ "show_major_grid", PHPG_PROP_READ_FN(GtkPlotAxis, show_major_grid), NULL },
	{ "show_minor_grid", PHPG_PROP_READ_FN(GtkPlotAxis, show_minor_grid), NULL },
	{ "label_precision", PHPG_PROP_READ_FN(GtkPlotAxis, label_precision), NULL },
	{ "label_style", PHPG_PROP_READ_FN(GtkPlotAxis, label_style), NULL },
	{ "label_mask", PHPG_PROP_READ_FN(GtkPlotAxis, label_mask), NULL },
	{ "tick_labels", PHPG_PROP_READ_FN(GtkPlotAxis, tick_labels), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkPlotAxis, construct)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_axis_construct(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), orientation);

}


static PHP_METHOD(GtkPlotAxis, set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_axis_set_visible(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotAxis, visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_axis_visible(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotAxis, set_title)
{
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &title, &free_title))
		return;

    gtk_plot_axis_set_title(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkPlotAxis, show_title)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_axis_show_title(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotAxis, hide_title)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_axis_hide_title(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotAxis, move_title)
{
	long angle;
	double x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "idd", &angle, &x, &y))
		return;

    gtk_plot_axis_move_title(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)angle, x, y);

}


static PHP_METHOD(GtkPlotAxis, justify_title)
{
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_plot_axis_justify_title(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), justification);

}


static PHP_METHOD(GtkPlotAxis, set_attributes)
{
	double width;
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dO", &width, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_axis_set_attributes(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (float)width, color);

}


static PHP_METHOD(GtkPlotAxis, set_ticks)
{
	double major_step;
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "di", &major_step, &nminor))
		return;

    gtk_plot_axis_set_ticks(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), major_step, (gint)nminor);

}


static PHP_METHOD(GtkPlotAxis, set_major_ticks)
{
	double major_step;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &major_step))
		return;

    gtk_plot_axis_set_major_ticks(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), major_step);

}


static PHP_METHOD(GtkPlotAxis, set_minor_ticks)
{
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &nminor))
		return;

    gtk_plot_axis_set_minor_ticks(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)nminor);

}


static PHP_METHOD(GtkPlotAxis, set_ticks_length)
{
	long length;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &length))
		return;

    gtk_plot_axis_set_ticks_length(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)length);

}


static PHP_METHOD(GtkPlotAxis, set_ticks_width)
{
	double width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &width))
		return;

    gtk_plot_axis_set_ticks_width(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (float)width);

}


static PHP_METHOD(GtkPlotAxis, show_ticks)
{
	long major_mask, minor_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &major_mask, &minor_mask))
		return;

    gtk_plot_axis_show_ticks(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)major_mask, (gint)minor_mask);

}


static PHP_METHOD(GtkPlotAxis, set_ticks_limits)
{
	double begin, end;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &begin, &end))
		return;

    gtk_plot_axis_set_ticks_limits(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), begin, end);

}


static PHP_METHOD(GtkPlotAxis, unset_ticks_limits)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_axis_unset_ticks_limits(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotAxis, set_tick_labels)
{
	zval *array;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &array, gtkplotarray_ce))
		return;

    gtk_plot_axis_set_tick_labels(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), GTK_PLOT_ARRAY(PHPG_GOBJECT(array)));

}


static PHP_METHOD(GtkPlotAxis, set_break)
{
	double min, max, step_after, pos;
	long nminor_after;
	GtkPlotScale scale_after;
	zval *php_scale_after = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dddiVd", &min, &max, &step_after, &nminor_after, &php_scale_after, &pos))
		return;

	if (php_scale_after && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale_after, (gint *)&scale_after) == FAILURE) {
		return;
	}

    gtk_plot_axis_set_break(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), min, max, step_after, (gint)nminor_after, scale_after, pos);

}


static PHP_METHOD(GtkPlotAxis, remove_break)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_axis_remove_break(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotAxis, show_labels)
{
	long labels_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &labels_mask))
		return;

    gtk_plot_axis_show_labels(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)labels_mask);

}


static PHP_METHOD(GtkPlotAxis, title_set_attributes)
{
	char *font;
	zend_bool free_font = FALSE, transparent;
	long height, angle;
	GdkColor *foreground = NULL, *background = NULL;
	zval *php_foreground, *php_background, *php_justification = NULL;
	GtkJustification justification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiOObV", &font, &free_font, &height, &angle, &php_foreground, gboxed_ce, &php_background, gboxed_ce, &transparent, &php_justification))
		return;

    if (phpg_gboxed_check(php_foreground, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        foreground = (GdkColor *) PHPG_GBOXED(php_foreground);
    } else {
        php_error(E_WARNING, "%s::%s() expects foreground argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_plot_axis_title_set_attributes(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), font, (gint)height, (gint)angle, foreground, background, (gboolean)transparent, justification);
	if (free_font) g_free(font);

}


static PHP_METHOD(GtkPlotAxis, set_labels_attributes)
{
	char *font;
	zend_bool free_font = FALSE, transparent;
	long height, angle;
	GdkColor *foreground = NULL, *background = NULL;
	zval *php_foreground, *php_background, *php_justification = NULL;
	GtkJustification justification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiOObV", &font, &free_font, &height, &angle, &php_foreground, gboxed_ce, &php_background, gboxed_ce, &transparent, &php_justification))
		return;

    if (phpg_gboxed_check(php_foreground, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        foreground = (GdkColor *) PHPG_GBOXED(php_foreground);
    } else {
        php_error(E_WARNING, "%s::%s() expects foreground argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_plot_axis_set_labels_attributes(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), font, (gint)height, (gint)angle, foreground, background, (gboolean)transparent, justification);
	if (free_font) g_free(font);

}


static PHP_METHOD(GtkPlotAxis, set_labels_style)
{
	GtkPlotLabelStyle style;
	zval *php_style = NULL;
	long precision;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_style, &precision))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LABEL_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    gtk_plot_axis_set_labels_style(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), style, (gint)precision);

}


static PHP_METHOD(GtkPlotAxis, set_labels_offset)
{
	long offset;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &offset))
		return;

    gtk_plot_axis_set_labels_offset(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gint)offset);

}


static PHP_METHOD(GtkPlotAxis, get_labels_offset)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_axis_get_labels_offset(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotAxis, use_custom_tick_labels)
{
	zend_bool use;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &use))
		return;

    gtk_plot_axis_use_custom_tick_labels(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), (gboolean)use);

}


static PHP_METHOD(GtkPlotAxis, set_labels_suffix)
{
	char *text;
	zend_bool free_text = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &text, &free_text))
		return;

    gtk_plot_axis_set_labels_suffix(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), text);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkPlotAxis, set_labels_prefix)
{
	char *text;
	zend_bool free_text = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &text, &free_text))
		return;

    gtk_plot_axis_set_labels_prefix(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), text);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkPlotAxis, get_labels_suffix)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_axis_get_labels_suffix(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkPlotAxis, get_labels_prefix)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_axis_get_labels_prefix(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkPlotAxis, ticks_recalc)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_axis_ticks_recalc(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotAxis, ticks_transform)
{
	double y, php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &y))
		return;

    php_retval = gtk_plot_axis_ticks_transform(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), y);
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotAxis, ticks_inverse)
{
	double x, php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &x))
		return;

    php_retval = gtk_plot_axis_ticks_inverse(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), x);
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotAxis, parse_label)
{
	double val;
	long precision, style;
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "diiu", &val, &precision, &style, &label, &free_label))
		return;

    gtk_plot_axis_parse_label(GTK_PLOT_AXIS(PHPG_GOBJECT(this_ptr)), val, (gint)precision, (gint)style, label);
	if (free_label) g_free(label);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_gtk_plot_axis_new, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_construct, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_title, 0)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_move_title, 0)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_justify_title, 0)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_attributes, 0)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_ticks, 0)
    ZEND_ARG_INFO(0, major_step)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_major_ticks, 0)
    ZEND_ARG_INFO(0, major_step)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_minor_ticks, 0)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_ticks_length, 0)
    ZEND_ARG_INFO(0, length)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_ticks_width, 0)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_show_ticks, 0)
    ZEND_ARG_INFO(0, major_mask)
    ZEND_ARG_INFO(0, minor_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_ticks_limits, 0)
    ZEND_ARG_INFO(0, begin)
    ZEND_ARG_INFO(0, end)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_tick_labels, 0)
    ZEND_ARG_OBJ_INFO(0, array, GtkPlotArray, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_break, 0)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
    ZEND_ARG_INFO(0, step_after)
    ZEND_ARG_INFO(0, nminor_after)
    ZEND_ARG_OBJ_INFO(0, scale_after, GtkPlotScale, 1)
    ZEND_ARG_INFO(0, pos)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_show_labels, 0)
    ZEND_ARG_INFO(0, labels_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_title_set_attributes, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, foreground, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
    ZEND_ARG_INFO(0, transparent)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_labels_attributes, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, foreground, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
    ZEND_ARG_INFO(0, transparent)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_labels_style, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLabelStyle, 1)
    ZEND_ARG_INFO(0, precision)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_labels_offset, 0)
    ZEND_ARG_INFO(0, offset)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_use_custom_tick_labels, 0)
    ZEND_ARG_INFO(0, use)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_labels_suffix, 0)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_set_labels_prefix, 0)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_ticks_transform, 0)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_ticks_inverse, 0)
    ZEND_ARG_INFO(0, x)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotaxis_parse_label, 0)
    ZEND_ARG_INFO(0, val)
    ZEND_ARG_INFO(0, precision)
    ZEND_ARG_INFO(0, style)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static function_entry gtkplotaxis_methods[] = {
	PHP_ME(GtkPlotAxis, __construct,          arginfo_gtk_gtkplotaxis_gtk_plot_axis_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, construct,            arginfo_gtk_gtkplotaxis_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, get_labels_offset,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, get_labels_prefix,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, get_labels_suffix,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, hide_title,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, justify_title,        arginfo_gtk_gtkplotaxis_justify_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, move_title,           arginfo_gtk_gtkplotaxis_move_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, parse_label,          arginfo_gtk_gtkplotaxis_parse_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, remove_break,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_attributes,       arginfo_gtk_gtkplotaxis_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_break,            arginfo_gtk_gtkplotaxis_set_break, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_labels_attributes, arginfo_gtk_gtkplotaxis_set_labels_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_labels_offset,    arginfo_gtk_gtkplotaxis_set_labels_offset, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_labels_prefix,    arginfo_gtk_gtkplotaxis_set_labels_prefix, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_labels_style,     arginfo_gtk_gtkplotaxis_set_labels_style, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_labels_suffix,    arginfo_gtk_gtkplotaxis_set_labels_suffix, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_major_ticks,      arginfo_gtk_gtkplotaxis_set_major_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_minor_ticks,      arginfo_gtk_gtkplotaxis_set_minor_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_tick_labels,      arginfo_gtk_gtkplotaxis_set_tick_labels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_ticks,            arginfo_gtk_gtkplotaxis_set_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_ticks_length,     arginfo_gtk_gtkplotaxis_set_ticks_length, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_ticks_limits,     arginfo_gtk_gtkplotaxis_set_ticks_limits, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_ticks_width,      arginfo_gtk_gtkplotaxis_set_ticks_width, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_title,            arginfo_gtk_gtkplotaxis_set_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, set_visible,          arginfo_gtk_gtkplotaxis_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, show_labels,          arginfo_gtk_gtkplotaxis_show_labels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, show_ticks,           arginfo_gtk_gtkplotaxis_show_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, show_title,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, ticks_inverse,        arginfo_gtk_gtkplotaxis_ticks_inverse, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, ticks_recalc,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, ticks_transform,      arginfo_gtk_gtkplotaxis_ticks_transform, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, title_set_attributes, arginfo_gtk_gtkplotaxis_title_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, unset_ticks_limits,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, use_custom_tick_labels, arginfo_gtk_gtkplotaxis_use_custom_tick_labels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotAxis, visible,              NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

PHPG_PROP_READER(GtkPlotCanvasChild, rx1)
{
	double php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->rx1;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, rx2)
{
	double php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->rx2;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, ry1)
{
	double php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->ry1;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, ry2)
{
	double php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->ry2;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, min_width)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->min_width;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, min_height)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->min_height;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, allocation)
{
	GdkRectangle php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->allocation;
	phpg_gboxed_new(&return_value, GDK_TYPE_RECTANGLE, &php_retval, TRUE, TRUE TSRMLS_CC);

    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, state)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->state;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, flags)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->flags;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, selection)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->selection;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasChild, mode)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_CHILD(((phpg_gobject_t *)object)->obj)->mode;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


static prop_info_t gtkplotcanvaschild_prop_info[] = {
	{ "rx1", PHPG_PROP_READ_FN(GtkPlotCanvasChild, rx1), NULL },
	{ "rx2", PHPG_PROP_READ_FN(GtkPlotCanvasChild, rx2), NULL },
	{ "ry1", PHPG_PROP_READ_FN(GtkPlotCanvasChild, ry1), NULL },
	{ "ry2", PHPG_PROP_READ_FN(GtkPlotCanvasChild, ry2), NULL },
	{ "min_width", PHPG_PROP_READ_FN(GtkPlotCanvasChild, min_width), NULL },
	{ "min_height", PHPG_PROP_READ_FN(GtkPlotCanvasChild, min_height), NULL },
	{ "allocation", PHPG_PROP_READ_FN(GtkPlotCanvasChild, allocation), NULL },
	{ "state", PHPG_PROP_READ_FN(GtkPlotCanvasChild, state), NULL },
	{ "flags", PHPG_PROP_READ_FN(GtkPlotCanvasChild, flags), NULL },
	{ "selection", PHPG_PROP_READ_FN(GtkPlotCanvasChild, selection), NULL },
	{ "mode", PHPG_PROP_READ_FN(GtkPlotCanvasChild, mode), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkPlotCanvasChild, set_selection)
{
	GtkPlotCanvasSelection selection;
	zval *php_selection = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_selection))
		return;

	if (php_selection && phpg_gvalue_get_enum(GTK_TYPE_PLOT_CANVAS_SELECTION, php_selection, (gint *)&selection) == FAILURE) {
		return;
	}

    gtk_plot_canvas_child_set_selection(GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(this_ptr)), selection);

}


static PHP_METHOD(GtkPlotCanvasChild, set_selection_mode)
{
	GtkPlotCanvasSelectionMode mode;
	zval *php_mode = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_mode))
		return;

	if (php_mode && phpg_gvalue_get_enum(GTK_TYPE_PLOT_CANVAS_SELECTION_MODE, php_mode, (gint *)&mode) == FAILURE) {
		return;
	}

    gtk_plot_canvas_child_set_selection_mode(GTK_PLOT_CANVAS_CHILD(PHPG_GOBJECT(this_ptr)), mode);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvaschild_set_selection, 0)
    ZEND_ARG_OBJ_INFO(0, selection, GtkPlotCanvasSelection, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvaschild_set_selection_mode, 0)
    ZEND_ARG_OBJ_INFO(0, mode, GtkPlotCanvasSelectionMode, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvaschild_methods[] = {
	PHP_ME(GtkPlotCanvasChild, set_selection,        arginfo_gtk_gtkplotcanvaschild_set_selection, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasChild, set_selection_mode,   arginfo_gtk_gtkplotcanvaschild_set_selection_mode, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasEllipse, __construct)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_fg, *php_bg;
	double width;
	GdkColor *fg = NULL, *bg = NULL;
	zend_bool fill;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdNNb", &php_style, &width, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &fill)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasEllipse);
	}

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasEllipse);
	}

    if (Z_TYPE_P(php_fg) != IS_NULL) {
        if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            fg = (GdkColor *) PHPG_GBOXED(php_fg);
        } else {
            php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasEllipse);
        }
    }

    if (Z_TYPE_P(php_bg) != IS_NULL) {
        if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            bg = (GdkColor *) PHPG_GBOXED(php_bg);
        } else {
            php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasEllipse);
        }
    }

	wrapped_obj = (GObject *) gtk_plot_canvas_ellipse_new(style, (float)width, fg, bg, (gboolean)fill);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasEllipse);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCanvasEllipse, set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_fg, *php_bg;
	double width;
	GdkColor *fg = NULL, *bg = NULL;
	zend_bool fill;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdNNb", &php_style, &width, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &fill))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (Z_TYPE_P(php_fg) != IS_NULL) {
        if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            fg = (GdkColor *) PHPG_GBOXED(php_fg);
        } else {
            php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    if (Z_TYPE_P(php_bg) != IS_NULL) {
        if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            bg = (GdkColor *) PHPG_GBOXED(php_bg);
        } else {
            php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    gtk_plot_canvas_ellipse_set_attributes(GTK_PLOT_CANVAS_ELLIPSE(PHPG_GOBJECT(this_ptr)), style, width, fg, bg, (gboolean)fill);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasellipse_gtk_plot_canvas_ellipse_new, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_INFO(0, fill)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasellipse_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_INFO(0, fill)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvasellipse_methods[] = {
	PHP_ME(GtkPlotCanvasEllipse, __construct,          arginfo_gtk_gtkplotcanvasellipse_gtk_plot_canvas_ellipse_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasEllipse, set_attributes,       arginfo_gtk_gtkplotcanvasellipse_set_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasLine, __construct)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color, *php_arrow_mask = NULL;
	double width;
	GdkColor *color = NULL;
	GtkPlotCanvasArrow arrow_mask;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdNV", &php_style, &width, &php_color, gboxed_ce, &php_arrow_mask)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasLine);
	}

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasLine);
	}

    if (Z_TYPE_P(php_color) != IS_NULL) {
        if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            color = (GdkColor *) PHPG_GBOXED(php_color);
        } else {
            php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasLine);
        }
    }

	if (php_arrow_mask && phpg_gvalue_get_flags(GTK_TYPE_PLOT_CANVAS_ARROW, php_arrow_mask, (gint *)&arrow_mask) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasLine);
	}

	wrapped_obj = (GObject *) gtk_plot_canvas_line_new(style, (float)width, color, arrow_mask);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasLine);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCanvasLine, set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdN", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (Z_TYPE_P(php_color) != IS_NULL) {
        if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            color = (GdkColor *) PHPG_GBOXED(php_color);
        } else {
            php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    gtk_plot_canvas_line_set_attributes(GTK_PLOT_CANVAS_LINE(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlotCanvasLine, set_arrow)
{
	GtkPlotSymbolStyle style;
	zval *php_style = NULL, *php_mask = NULL;
	double width, length;
	GtkPlotCanvasArrow mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VddV", &php_style, &width, &length, &php_mask))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SYMBOL_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

	if (php_mask && phpg_gvalue_get_flags(GTK_TYPE_PLOT_CANVAS_ARROW, php_mask, (gint *)&mask) == FAILURE) {
		return;
	}

    gtk_plot_canvas_line_set_arrow(GTK_PLOT_CANVAS_LINE(PHPG_GOBJECT(this_ptr)), style, (float)width, (float)length, mask);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasline_gtk_plot_canvas_line_new, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, arrow_mask, GtkPlotCanvasArrow, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasline_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasline_set_arrow, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotSymbolStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, length)
    ZEND_ARG_OBJ_INFO(0, mask, GtkPlotCanvasArrow, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvasline_methods[] = {
	PHP_ME(GtkPlotCanvasLine, __construct,          arginfo_gtk_gtkplotcanvasline_gtk_plot_canvas_line_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasLine, set_arrow,            arginfo_gtk_gtkplotcanvasline_set_arrow, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasLine, set_attributes,       arginfo_gtk_gtkplotcanvasline_set_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasPixmap, __construct)
{
	GdkPixmap *pixmap = NULL, *mask = NULL;
	zval *php_pixmap, *php_mask;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "NN", &php_pixmap, gdkpixmap_ce, &php_mask, gdkpixmap_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasPixmap);
	}
    if (Z_TYPE_P(php_pixmap) != IS_NULL)
        pixmap = GDK_PIXMAP(PHPG_GOBJECT(php_pixmap));
    if (Z_TYPE_P(php_mask) != IS_NULL)
        mask = GDK_PIXMAP(PHPG_GOBJECT(php_mask));

	wrapped_obj = (GObject *) gtk_plot_canvas_pixmap_new(pixmap, mask);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasPixmap);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvaspixmap_gtk_plot_canvas_pixmap_new, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvaspixmap_methods[] = {
	PHP_ME(GtkPlotCanvasPixmap, __construct,          arginfo_gtk_gtkplotcanvaspixmap_gtk_plot_canvas_pixmap_new, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasPlot, __construct)
{
	zval *plot;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &plot, gtkplot_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasPlot);
	}

	wrapped_obj = (GObject *) gtk_plot_canvas_plot_new(GTK_PLOT(PHPG_GOBJECT(plot)));

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasPlot);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


PHPG_PROP_READER(GtkPlotCanvasPlot, pos)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_PLOT(((phpg_gobject_t *)object)->obj)->pos;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasPlot, datapoint)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_PLOT(((phpg_gobject_t *)object)->obj)->datapoint;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotCanvasPlot, flags)
{
	long php_retval;

    php_retval = GTK_PLOT_CANVAS_PLOT(((phpg_gobject_t *)object)->obj)->flags;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


static prop_info_t gtkplotcanvasplot_prop_info[] = {
	{ "pos", PHPG_PROP_READ_FN(GtkPlotCanvasPlot, pos), NULL },
	{ "datapoint", PHPG_PROP_READ_FN(GtkPlotCanvasPlot, datapoint), NULL },
	{ "flags", PHPG_PROP_READ_FN(GtkPlotCanvasPlot, flags), NULL },
	{ NULL, NULL, NULL },
};


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasplot_gtk_plot_canvas_plot_new, 0)
    ZEND_ARG_OBJ_INFO(0, plot, GtkPlot, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvasplot_methods[] = {
	PHP_ME(GtkPlotCanvasPlot, __construct,          arginfo_gtk_gtkplotcanvasplot_gtk_plot_canvas_plot_new, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasRectangle, __construct)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_fg, *php_bg, *php_border = NULL;
	double width;
	GdkColor *fg = NULL, *bg = NULL;
	GtkPlotBorderStyle border;
	zend_bool fill;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdOOVb", &php_style, &width, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &php_border, &fill)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
	}

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
	}

    if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        fg = (GdkColor *) PHPG_GBOXED(php_fg);
    } else {
        php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
    }

    if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        bg = (GdkColor *) PHPG_GBOXED(php_bg);
    } else {
        php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
    }

	if (php_border && phpg_gvalue_get_enum(GTK_TYPE_PLOT_BORDER_STYLE, php_border, (gint *)&border) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
	}

	wrapped_obj = (GObject *) gtk_plot_canvas_rectangle_new(style, (float)width, fg, bg, border, (gboolean)fill);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasRectangle);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCanvasRectangle, set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_fg, *php_bg, *php_border = NULL;
	double width;
	GdkColor *fg = NULL, *bg = NULL;
	GtkPlotBorderStyle border;
	zend_bool fill;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdNNVb", &php_style, &width, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &php_border, &fill))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (Z_TYPE_P(php_fg) != IS_NULL) {
        if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            fg = (GdkColor *) PHPG_GBOXED(php_fg);
        } else {
            php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    if (Z_TYPE_P(php_bg) != IS_NULL) {
        if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            bg = (GdkColor *) PHPG_GBOXED(php_bg);
        } else {
            php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

	if (php_border && phpg_gvalue_get_enum(GTK_TYPE_PLOT_BORDER_STYLE, php_border, (gint *)&border) == FAILURE) {
		return;
	}

    gtk_plot_canvas_rectangle_set_attributes(GTK_PLOT_CANVAS_RECTANGLE(PHPG_GOBJECT(this_ptr)), style, (float)width, fg, bg, border, (gboolean)fill);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasrectangle_gtk_plot_canvas_rectangle_new, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, border, GtkPlotBorderStyle, 1)
    ZEND_ARG_INFO(0, fill)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvasrectangle_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, border, GtkPlotBorderStyle, 1)
    ZEND_ARG_INFO(0, fill)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvasrectangle_methods[] = {
	PHP_ME(GtkPlotCanvasRectangle, __construct,          arginfo_gtk_gtkplotcanvasrectangle_gtk_plot_canvas_rectangle_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasRectangle, set_attributes,       arginfo_gtk_gtkplotcanvasrectangle_set_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCanvasText, __construct)
{
	char *font, *text;
	zend_bool free_font = FALSE, transparent, free_text = FALSE;
	long height, angle;
	GdkColor *fg = NULL, *bg = NULL;
	zval *php_fg, *php_bg, *php_justification = NULL;
	GtkJustification justification;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiNNbVu", &font, &free_font, &height, &angle, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &transparent, &php_justification, &text, &free_text)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasText);
	}

    if (Z_TYPE_P(php_fg) != IS_NULL) {
        if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            fg = (GdkColor *) PHPG_GBOXED(php_fg);
        } else {
            php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasText);
        }
    }

    if (Z_TYPE_P(php_bg) != IS_NULL) {
        if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            bg = (GdkColor *) PHPG_GBOXED(php_bg);
        } else {
            php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasText);
        }
    }

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasText);
	}

	wrapped_obj = (GObject *) gtk_plot_canvas_text_new(font, (gint)height, (gint)angle, fg, bg, (gboolean)transparent, justification, text);
	if (free_font) g_free(font);
	if (free_text) g_free(text);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCanvasText);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCanvasText, set_attributes)
{
	char *font, *real_text;
	zend_bool free_font = FALSE, transparent, free_real_text = FALSE;
	long height, angle;
	GdkColor *fg = NULL, *bg = NULL;
	zval *php_fg, *php_bg, *php_justification = NULL;
	GtkJustification justification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiNNbVu", &font, &free_font, &height, &angle, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &transparent, &php_justification, &real_text, &free_real_text))
		return;

    if (Z_TYPE_P(php_fg) != IS_NULL) {
        if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            fg = (GdkColor *) PHPG_GBOXED(php_fg);
        } else {
            php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    if (Z_TYPE_P(php_bg) != IS_NULL) {
        if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
            bg = (GdkColor *) PHPG_GBOXED(php_bg);
        } else {
            php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_plot_canvas_text_set_attributes(GTK_PLOT_CANVAS_TEXT(PHPG_GOBJECT(this_ptr)), font, (gint)height, (gint)angle, fg, bg, (gboolean)transparent, justification, real_text);
	if (free_font) g_free(font);
	if (free_real_text) g_free(real_text);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvastext_gtk_plot_canvas_text_new, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_INFO(0, transparent)
    ZEND_ARG_INFO(0, justification)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcanvastext_set_attributes, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_INFO(0, transparent)
    ZEND_ARG_INFO(0, justification)
    ZEND_ARG_INFO(0, real_text)
ZEND_END_ARG_INFO();

static function_entry gtkplotcanvastext_methods[] = {
	PHP_ME(GtkPlotCanvasText, __construct,          arginfo_gtk_gtkplotcanvastext_gtk_plot_canvas_text_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCanvasText, set_attributes,       arginfo_gtk_gtkplotcanvastext_set_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlot3D, __construct)
{
	zval *drawable;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlot3D);
	}

	wrapped_obj = (GObject *) gtk_plot3d_new(GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlot3D);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlot3D, construct)
{
	zval *drawable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce))
		return;

    gtk_plot3d_construct(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

}


static PHP_METHOD(GtkPlot3D, construct_with_size)
{
	zval *drawable;
	double width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &drawable, gdkdrawable_ce, &width, &height))
		return;

    gtk_plot3d_construct_with_size(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)), width, height);

}


static PHP_METHOD(GtkPlot3D, autoscale)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot3d_autoscale(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot3D, rotate)
{
	double angle_x, angle_y, angle_z;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ddd", &angle_x, &angle_y, &angle_z))
		return;

    gtk_plot3d_rotate(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), angle_x, angle_y, angle_z);

}


static PHP_METHOD(GtkPlot3D, reset_angles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot3d_reset_angles(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlot3D, rotate_x)
{
	double angle;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &angle))
		return;

    gtk_plot3d_rotate_x(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), angle);

}


static PHP_METHOD(GtkPlot3D, rotate_y)
{
	double angle;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &angle))
		return;

    gtk_plot3d_rotate_y(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), angle);

}


static PHP_METHOD(GtkPlot3D, rotate_z)
{
	double angle;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &angle))
		return;

    gtk_plot3d_rotate_z(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), angle);

}


static PHP_METHOD(GtkPlot3D, set_xrange)
{
	double min, max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &min, &max))
		return;

    gtk_plot3d_set_xrange(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlot3D, set_yrange)
{
	double min, max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &min, &max))
		return;

    gtk_plot3d_set_yrange(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlot3D, set_zrange)
{
	double min, max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &min, &max))
		return;

    gtk_plot3d_set_zrange(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlot3D, set_xfactor)
{
	double xfactor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &xfactor))
		return;

    gtk_plot3d_set_xfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), xfactor);

}


static PHP_METHOD(GtkPlot3D, set_yfactor)
{
	double yfactor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &yfactor))
		return;

    gtk_plot3d_set_yfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), yfactor);

}


static PHP_METHOD(GtkPlot3D, set_zfactor)
{
	double zfactor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &zfactor))
		return;

    gtk_plot3d_set_zfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), zfactor);

}


static PHP_METHOD(GtkPlot3D, get_xfactor)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot3d_get_xfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlot3D, get_yfactor)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot3d_get_yfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlot3D, get_zfactor)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot3d_get_zfactor(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlot3D, plane_set_color)
{
	GtkPlotPlane plane;
	zval *php_plane = NULL, *php_color;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VO", &php_plane, &php_color, gboxed_ce))
		return;

	if (php_plane && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PLANE, php_plane, (gint *)&plane) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot3d_plane_set_color(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), plane, color);

}


static PHP_METHOD(GtkPlot3D, plane_set_visible)
{
	GtkPlotPlane plane;
	zval *php_plane = NULL;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vb", &php_plane, &visible))
		return;

	if (php_plane && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PLANE, php_plane, (gint *)&plane) == FAILURE) {
		return;
	}

    gtk_plot3d_plane_set_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), plane, (gboolean)visible);

}


static PHP_METHOD(GtkPlot3D, plane_visible)
{
	GtkPlotPlane plane;
	zval *php_plane = NULL;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_plane))
		return;

	if (php_plane && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PLANE, php_plane, (gint *)&plane) == FAILURE) {
		return;
	}

    php_retval = gtk_plot3d_plane_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), plane);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot3D, corner_set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot3d_corner_set_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlot3D, corner_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot3d_corner_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlot3D, corner_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot3d_corner_set_attributes(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot3D, frame_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot3d_frame_set_attributes(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot3D, get_axis)
{
	GtkPlotOrientation orientation;
	zval *php_orientation = NULL;
	GtkPlotAxis* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    php_retval = gtk_plot3d_get_axis(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), orientation);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlot3D, get_side)
{
	GtkPlotSide side;
	zval *php_side = NULL;
	GtkPlotAxis* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_side))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    php_retval = gtk_plot3d_get_side(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlot3D, show_major_ticks)
{
	GtkPlotSide side;
	zval *php_side = NULL;
	long ticks_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_side, &ticks_mask))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_show_major_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side, (gint)ticks_mask);

}


static PHP_METHOD(GtkPlot3D, show_minor_ticks)
{
	GtkPlotSide side;
	zval *php_side = NULL;
	long ticks_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_side, &ticks_mask))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_show_minor_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side, (gint)ticks_mask);

}


static PHP_METHOD(GtkPlot3D, show_labels)
{
	GtkPlotSide side;
	zval *php_side = NULL;
	long label_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_side, &label_mask))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_show_labels(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side, (gint)label_mask);

}


static PHP_METHOD(GtkPlot3D, show_title)
{
	GtkPlotSide side;
	zval *php_side = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_side))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_show_title(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side);

}


static PHP_METHOD(GtkPlot3D, hide_title)
{
	GtkPlotSide side;
	zval *php_side = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_side))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_hide_title(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side);

}


static PHP_METHOD(GtkPlot3D, set_ticks)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	double major_step;
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vdi", &php_axis, &major_step, &nminor))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    gtk_plot3d_set_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, major_step, (gint)nminor);

}


static PHP_METHOD(GtkPlot3D, set_major_ticks)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	double major_step;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vd", &php_axis, &major_step))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    gtk_plot3d_set_major_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, major_step);

}


static PHP_METHOD(GtkPlot3D, set_minor_ticks)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	long nminor;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_axis, &nminor))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    gtk_plot3d_set_minor_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, (gint)nminor);

}


static PHP_METHOD(GtkPlot3D, set_ticks_length)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	long length;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_axis, &length))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    gtk_plot3d_set_ticks_length(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, (gint)length);

}


static PHP_METHOD(GtkPlot3D, set_ticks_width)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	double width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vd", &php_axis, &width))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    gtk_plot3d_set_ticks_width(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, (float)width);

}


static PHP_METHOD(GtkPlot3D, show_ticks)
{
	GtkPlotSide side;
	zval *php_side = NULL;
	long major_mask, minor_mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vii", &php_side, &major_mask, &minor_mask))
		return;

	if (php_side && phpg_gvalue_get_flags(GTK_TYPE_PLOT_SIDE, php_side, (gint *)&side) == FAILURE) {
		return;
	}

    gtk_plot3d_show_ticks(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), side, (gint)major_mask, (gint)minor_mask);

}


static PHP_METHOD(GtkPlot3D, set_titles_offset)
{
	long offset;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &offset))
		return;

    gtk_plot3d_set_titles_offset(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), (gint)offset);

}


static PHP_METHOD(GtkPlot3D, get_titles_offset)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot3d_get_titles_offset(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlot3D, set_scale)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL, *php_scale = NULL;
	GtkPlotScale scale;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VV", &php_axis, &php_scale))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

	if (php_scale && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale, (gint *)&scale) == FAILURE) {
		return;
	}

    gtk_plot3d_set_scale(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis, scale);

}


static PHP_METHOD(GtkPlot3D, get_scale)
{
	GtkPlotOrientation axis;
	zval *php_axis = NULL;
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_axis))
		return;

	if (php_axis && phpg_gvalue_get_enum(GTK_TYPE_PLOT_ORIENTATION, php_axis, (gint *)&axis) == FAILURE) {
		return;
	}

    php_retval = gtk_plot3d_get_scale(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), axis);
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlot3D, major_grids_set_visible)
{
	zend_bool x, y, z;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "bbb", &x, &y, &z))
		return;

    gtk_plot3d_major_grids_set_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), (gboolean)x, (gboolean)y, (gboolean)z);

}


static PHP_METHOD(GtkPlot3D, minor_grids_set_visible)
{
	zend_bool x, y, z;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "bbb", &x, &y, &z))
		return;

    gtk_plot3d_minor_grids_set_visible(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), (gboolean)x, (gboolean)y, (gboolean)z);

}


static PHP_METHOD(GtkPlot3D, major_zgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot3d_major_zgrid_set_attributes(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlot3D, minor_zgrid_set_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot3d_minor_zgrid_set_attributes(GTK_PLOT3_D(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_gtk_plot3d_new, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_construct, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_construct_with_size, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_rotate, 0)
    ZEND_ARG_INFO(0, angle_x)
    ZEND_ARG_INFO(0, angle_y)
    ZEND_ARG_INFO(0, angle_z)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_rotate_x, 0)
    ZEND_ARG_INFO(0, angle)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_rotate_y, 0)
    ZEND_ARG_INFO(0, angle)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_rotate_z, 0)
    ZEND_ARG_INFO(0, angle)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_xrange, 0)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_yrange, 0)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_zrange, 0)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_xfactor, 0)
    ZEND_ARG_INFO(0, xfactor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_yfactor, 0)
    ZEND_ARG_INFO(0, yfactor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_zfactor, 0)
    ZEND_ARG_INFO(0, zfactor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_plane_set_color, 0)
    ZEND_ARG_OBJ_INFO(0, plane, GtkPlotPlane, 1)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_plane_set_visible, 0)
    ZEND_ARG_OBJ_INFO(0, plane, GtkPlotPlane, 1)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_plane_visible, 0)
    ZEND_ARG_OBJ_INFO(0, plane, GtkPlotPlane, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_corner_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_corner_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_frame_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_get_axis, 0)
    ZEND_ARG_OBJ_INFO(0, orientation, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_get_side, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_show_major_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
    ZEND_ARG_INFO(0, ticks_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_show_minor_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
    ZEND_ARG_INFO(0, ticks_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_show_labels, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
    ZEND_ARG_INFO(0, label_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_show_title, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_hide_title, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, major_step)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_major_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, major_step)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_minor_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, nminor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_ticks_length, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, length)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_ticks_width, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_show_ticks, 0)
    ZEND_ARG_OBJ_INFO(0, side, GtkPlotSide, 1)
    ZEND_ARG_INFO(0, major_mask)
    ZEND_ARG_INFO(0, minor_mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_titles_offset, 0)
    ZEND_ARG_INFO(0, offset)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_set_scale, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
    ZEND_ARG_OBJ_INFO(0, scale, GtkPlotScale, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_get_scale, 0)
    ZEND_ARG_OBJ_INFO(0, axis, GtkPlotOrientation, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_major_grids_set_visible, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, z)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_minor_grids_set_visible, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, z)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_major_zgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplot3d_minor_zgrid_set_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplot3d_methods[] = {
	PHP_ME(GtkPlot3D, __construct,          arginfo_gtk_gtkplot3d_gtk_plot3d_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, autoscale,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, construct,            arginfo_gtk_gtkplot3d_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, construct_with_size,  arginfo_gtk_gtkplot3d_construct_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, corner_set_attributes, arginfo_gtk_gtkplot3d_corner_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, corner_set_visible,   arginfo_gtk_gtkplot3d_corner_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, corner_visible,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, frame_set_attributes, arginfo_gtk_gtkplot3d_frame_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_axis,             arginfo_gtk_gtkplot3d_get_axis, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_scale,            arginfo_gtk_gtkplot3d_get_scale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_side,             arginfo_gtk_gtkplot3d_get_side, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_titles_offset,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_xfactor,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_yfactor,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, get_zfactor,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, hide_title,           arginfo_gtk_gtkplot3d_hide_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, major_grids_set_visible, arginfo_gtk_gtkplot3d_major_grids_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, major_zgrid_set_attributes, arginfo_gtk_gtkplot3d_major_zgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, minor_grids_set_visible, arginfo_gtk_gtkplot3d_minor_grids_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, minor_zgrid_set_attributes, arginfo_gtk_gtkplot3d_minor_zgrid_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, plane_set_color,      arginfo_gtk_gtkplot3d_plane_set_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, plane_set_visible,    arginfo_gtk_gtkplot3d_plane_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, plane_visible,        arginfo_gtk_gtkplot3d_plane_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, reset_angles,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, rotate,               arginfo_gtk_gtkplot3d_rotate, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, rotate_x,             arginfo_gtk_gtkplot3d_rotate_x, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, rotate_y,             arginfo_gtk_gtkplot3d_rotate_y, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, rotate_z,             arginfo_gtk_gtkplot3d_rotate_z, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_major_ticks,      arginfo_gtk_gtkplot3d_set_major_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_minor_ticks,      arginfo_gtk_gtkplot3d_set_minor_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_scale,            arginfo_gtk_gtkplot3d_set_scale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_ticks,            arginfo_gtk_gtkplot3d_set_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_ticks_length,     arginfo_gtk_gtkplot3d_set_ticks_length, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_ticks_width,      arginfo_gtk_gtkplot3d_set_ticks_width, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_titles_offset,    arginfo_gtk_gtkplot3d_set_titles_offset, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_xfactor,          arginfo_gtk_gtkplot3d_set_xfactor, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_xrange,           arginfo_gtk_gtkplot3d_set_xrange, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_yfactor,          arginfo_gtk_gtkplot3d_set_yfactor, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_yrange,           arginfo_gtk_gtkplot3d_set_yrange, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_zfactor,          arginfo_gtk_gtkplot3d_set_zfactor, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, set_zrange,           arginfo_gtk_gtkplot3d_set_zrange, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, show_labels,          arginfo_gtk_gtkplot3d_show_labels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, show_major_ticks,     arginfo_gtk_gtkplot3d_show_major_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, show_minor_ticks,     arginfo_gtk_gtkplot3d_show_minor_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, show_ticks,           arginfo_gtk_gtkplot3d_show_ticks, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlot3D, show_title,           arginfo_gtk_gtkplot3d_show_title, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotDT, set_quadrilateral)
{
	zend_bool set;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &set))
		return;

    gtk_plot_dt_set_quadrilateral(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)), (gboolean)set);

}


static PHP_METHOD(GtkPlotDT, set_subsampling)
{
	zend_bool set;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &set))
		return;

    gtk_plot_dt_set_subsampling(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)), (gboolean)set);

}


static PHP_METHOD(GtkPlotDT, add_node)
{
	GtkPlotDTnode *node = NULL;
	zval *php_node;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_node, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_node, GTK_TYPE_PLOT_DT_NODE, FALSE TSRMLS_CC)) {
        node = (GtkPlotDTnode *) PHPG_GBOXED(php_node);
    } else {
        php_error(E_WARNING, "%s::%s() expects node argument to be a valid GtkPlotDTnode object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_plot_dt_add_node_PY(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)), node);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotDT, get_node)
{
	long idx;
	GtkPlotDTnode *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &idx))
		return;

    php_retval = gtk_plot_dt_get_node(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)), (gint)idx);
	phpg_gboxed_new(&return_value, GTK_TYPE_PLOT_DT_NODE, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkPlotDT, triangulate)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_dt_triangulate(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotDT, clear)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_dt_clear(GTK_PLOT_DT(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdt_set_quadrilateral, 0)
    ZEND_ARG_INFO(0, set)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdt_set_subsampling, 0)
    ZEND_ARG_INFO(0, set)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdt_add_node, 0)
    ZEND_ARG_OBJ_INFO(0, node, GtkPlotDTnode, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdt_get_node, 0)
    ZEND_ARG_INFO(0, idx)
ZEND_END_ARG_INFO();

static function_entry gtkplotdt_methods[] = {
	PHP_ME(GtkPlotDT, add_node,             arginfo_gtk_gtkplotdt_add_node, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotDT, clear,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotDT, get_node,             arginfo_gtk_gtkplotdt_get_node, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotDT, set_quadrilateral,    arginfo_gtk_gtkplotdt_set_quadrilateral, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotDT, set_subsampling,      arginfo_gtk_gtkplotdt_set_subsampling, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotDT, triangulate,          NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotData, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotData);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotData);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotData, clone)
{
	zval *copy;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &copy, gtkplotdata_ce))
		return;

    gtk_plot_data_clone(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), GTK_PLOT_DATA(PHPG_GOBJECT(copy)));

}


static PHP_METHOD(GtkPlotData, paint)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_paint(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, update)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_update(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, draw_points)
{
	long n;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &n))
		return;

    gtk_plot_data_draw_points(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gint)n);

}


static PHP_METHOD(GtkPlotData, draw_symbol)
{
	double x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &x, &y))
		return;

    gtk_plot_data_draw_symbol(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), x, y);

}


static PHP_METHOD(GtkPlotData, set_a_scale)
{
	double a_scale;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &a_scale))
		return;

    gtk_plot_data_set_a_scale(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), a_scale);

}


static PHP_METHOD(GtkPlotData, get_a_scale)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_get_a_scale(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotData, show_labels)
{
	zend_bool show_labels;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show_labels))
		return;

    gtk_plot_data_show_labels(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gboolean)show_labels);

}


static PHP_METHOD(GtkPlotData, labels_set_attributes)
{
	char *font;
	zend_bool free_font = FALSE;
	long height, angle;
	GdkColor *foreground = NULL, *background = NULL;
	zval *php_foreground, *php_background;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiOO", &font, &free_font, &height, &angle, &php_foreground, gboxed_ce, &php_background, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_foreground, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        foreground = (GdkColor *) PHPG_GBOXED(php_foreground);
    } else {
        php_error(E_WARNING, "%s::%s() expects foreground argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_labels_set_attributes(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), font, (gint)height, (gint)angle, foreground, background);
	if (free_font) g_free(font);

}


static PHP_METHOD(GtkPlotData, set_numpoints)
{
	long num_points;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &num_points))
		return;

    gtk_plot_data_set_numpoints(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gint)num_points);

}


static PHP_METHOD(GtkPlotData, get_numpoints)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_get_numpoints(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotData, set_symbol)
{
	GtkPlotSymbolType type;
	zval *php_type = NULL, *php_style = NULL, *php_color, *php_border_color;
	GtkPlotSymbolStyle style;
	long size;
	double line_width;
	GdkColor *color = NULL, *border_color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VVidOO", &php_type, &php_style, &size, &line_width, &php_color, gboxed_ce, &php_border_color, gboxed_ce))
		return;

	if (php_type && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SYMBOL_TYPE, php_type, (gint *)&type) == FAILURE) {
		return;
	}

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SYMBOL_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_border_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        border_color = (GdkColor *) PHPG_GBOXED(php_border_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects border_color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_symbol(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), type, style, (gint)size, (float)line_width, color, border_color);

}


static PHP_METHOD(GtkPlotData, set_connector)
{
	GtkPlotConnector connector;
	zval *php_connector = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_connector))
		return;

	if (php_connector && phpg_gvalue_get_enum(GTK_TYPE_PLOT_CONNECTOR, php_connector, (gint *)&connector) == FAILURE) {
		return;
	}

    gtk_plot_data_set_connector(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), connector);

}


static PHP_METHOD(GtkPlotData, get_connector)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_get_connector(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotData, set_line_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_cap_style = NULL, *php_join_style = NULL, *php_color;
	GdkCapStyle cap_style;
	GdkJoinStyle join_style;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VVVdO", &php_style, &php_cap_style, &php_join_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

	if (php_cap_style && phpg_gvalue_get_enum(GDK_TYPE_CAP_STYLE, php_cap_style, (gint *)&cap_style) == FAILURE) {
		return;
	}

	if (php_join_style && phpg_gvalue_get_enum(GDK_TYPE_JOIN_STYLE, php_join_style, (gint *)&join_style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_line_attributes(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), style, cap_style, join_style, (float)width, color);

}


static PHP_METHOD(GtkPlotData, set_x_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_cap_style = NULL, *php_join_style = NULL, *php_color;
	GdkCapStyle cap_style;
	GdkJoinStyle join_style;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VVVdO", &php_style, &php_cap_style, &php_join_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

	if (php_cap_style && phpg_gvalue_get_enum(GDK_TYPE_CAP_STYLE, php_cap_style, (gint *)&cap_style) == FAILURE) {
		return;
	}

	if (php_join_style && phpg_gvalue_get_enum(GDK_TYPE_JOIN_STYLE, php_join_style, (gint *)&join_style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_x_attributes(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), style, cap_style, join_style, (float)width, color);

}


static PHP_METHOD(GtkPlotData, set_y_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_cap_style = NULL, *php_join_style = NULL, *php_color;
	GdkCapStyle cap_style;
	GdkJoinStyle join_style;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VVVdO", &php_style, &php_cap_style, &php_join_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

	if (php_cap_style && phpg_gvalue_get_enum(GDK_TYPE_CAP_STYLE, php_cap_style, (gint *)&cap_style) == FAILURE) {
		return;
	}

	if (php_join_style && phpg_gvalue_get_enum(GDK_TYPE_JOIN_STYLE, php_join_style, (gint *)&join_style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_y_attributes(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), style, cap_style, join_style, (float)width, color);

}


static PHP_METHOD(GtkPlotData, set_z_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_cap_style = NULL, *php_join_style = NULL, *php_color;
	GdkCapStyle cap_style;
	GdkJoinStyle join_style;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VVVdO", &php_style, &php_cap_style, &php_join_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

	if (php_cap_style && phpg_gvalue_get_enum(GDK_TYPE_CAP_STYLE, php_cap_style, (gint *)&cap_style) == FAILURE) {
		return;
	}

	if (php_join_style && phpg_gvalue_get_enum(GDK_TYPE_JOIN_STYLE, php_join_style, (gint *)&join_style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_z_attributes(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), style, cap_style, join_style, (float)width, color);

}


static PHP_METHOD(GtkPlotData, show_xerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_show_xerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, show_yerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_show_yerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, show_zerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_show_zerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, hide_xerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_hide_xerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, hide_yerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_hide_yerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, hide_zerrbars)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_hide_zerrbars(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, fill_area)
{
	zend_bool fill;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &fill))
		return;

    gtk_plot_data_fill_area(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gboolean)fill);

}


static PHP_METHOD(GtkPlotData, area_is_filled)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_area_is_filled(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotData, show_legend)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_show_legend(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, hide_legend)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_hide_legend(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, set_legend)
{
	char *legend;
	zend_bool free_legend = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &legend, &free_legend))
		return;

    gtk_plot_data_set_legend(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), legend);
	if (free_legend) g_free(legend);

}


static PHP_METHOD(GtkPlotData, set_legend_precision)
{
	long precision;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &precision))
		return;

    gtk_plot_data_set_legend_precision(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gint)precision);

}


static PHP_METHOD(GtkPlotData, get_legend_precision)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_get_legend_precision(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotData, set_name)
{
	char *name;
	zend_bool free_name = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &name, &free_name))
		return;

    gtk_plot_data_set_name(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), name);
	if (free_name) g_free(name);

}


static PHP_METHOD(GtkPlotData, reset_gradient)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_reset_gradient(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, reset_gradient_colors)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_reset_gradient_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, gradient_use_custom_colors)
{
	zend_bool custom;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &custom))
		return;

    gtk_plot_data_gradient_use_custom_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gboolean)custom);

}


static PHP_METHOD(GtkPlotData, gradient_custom_colors)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_gradient_custom_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotData, set_gradient_mask)
{
	long mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &mask))
		return;

    gtk_plot_data_set_gradient_mask(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gint)mask);

}


static PHP_METHOD(GtkPlotData, get_gradient_mask)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_get_gradient_mask(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotData, gradient_set_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_data_gradient_set_visible(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotData, gradient_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_gradient_visible(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotData, gradient_autoscale_a)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_gradient_autoscale_a(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, gradient_autoscale_da)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_gradient_autoscale_da(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, gradient_autoscale_z)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_gradient_autoscale_z(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, set_gradient_colors)
{
	GdkColor *min = NULL, *max = NULL;
	zval *php_min, *php_max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_min, gboxed_ce, &php_max, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_min, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        min = (GdkColor *) PHPG_GBOXED(php_min);
    } else {
        php_error(E_WARNING, "%s::%s() expects min argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_max, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        max = (GdkColor *) PHPG_GBOXED(php_max);
    } else {
        php_error(E_WARNING, "%s::%s() expects max argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_gradient_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlotData, get_gradient_colors)
{
	GdkColor *min = NULL, *max = NULL;
	zval *php_min, *php_max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_min, gboxed_ce, &php_max, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_min, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        min = (GdkColor *) PHPG_GBOXED(php_min);
    } else {
        php_error(E_WARNING, "%s::%s() expects min argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_max, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        max = (GdkColor *) PHPG_GBOXED(php_max);
    } else {
        php_error(E_WARNING, "%s::%s() expects max argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_get_gradient_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlotData, set_gradient_nth_color)
{
	long level;
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iO", &level, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_gradient_nth_color(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (guint)level, color);

}


static PHP_METHOD(GtkPlotData, get_gradient_nth_color)
{
	long level;
	GdkColor *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &level))
		return;

    php_retval = gtk_plot_data_get_gradient_nth_color(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (guint)level);
	phpg_gboxed_new(&return_value, GDK_TYPE_COLOR, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkPlotData, set_gradient_outer_colors)
{
	GdkColor *min = NULL, *max = NULL;
	zval *php_min, *php_max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_min, gboxed_ce, &php_max, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_min, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        min = (GdkColor *) PHPG_GBOXED(php_min);
    } else {
        php_error(E_WARNING, "%s::%s() expects min argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_max, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        max = (GdkColor *) PHPG_GBOXED(php_max);
    } else {
        php_error(E_WARNING, "%s::%s() expects max argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_set_gradient_outer_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlotData, get_gradient_outer_colors)
{
	GdkColor *min = NULL, *max = NULL;
	zval *php_min, *php_max;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_min, gboxed_ce, &php_max, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_min, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        min = (GdkColor *) PHPG_GBOXED(php_min);
    } else {
        php_error(E_WARNING, "%s::%s() expects min argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_max, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        max = (GdkColor *) PHPG_GBOXED(php_max);
    } else {
        php_error(E_WARNING, "%s::%s() expects max argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_get_gradient_outer_colors(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), min, max);

}


static PHP_METHOD(GtkPlotData, set_gradient)
{
	double min, max;
	long nlevels, nsublevels = 0;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ddi|i", &min, &max, &nlevels, &nsublevels))
		return;

    gtk_plot_data_set_gradient(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), min, max, (gint)nlevels, (gint)nsublevels);

}


static PHP_METHOD(GtkPlotData, get_gradient_level)
{
	double level;
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dO", &level, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_data_get_gradient_level(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), level, color);

}


static PHP_METHOD(GtkPlotData, gradient_set_style)
{
	GtkPlotLabelStyle style;
	zval *php_style = NULL;
	long precision;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Vi", &php_style, &precision))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LABEL_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    gtk_plot_data_gradient_set_style(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), style, (gint)precision);

}


static PHP_METHOD(GtkPlotData, gradient_set_scale)
{
	GtkPlotScale scale;
	zval *php_scale = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_scale))
		return;

	if (php_scale && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SCALE, php_scale, (gint *)&scale) == FAILURE) {
		return;
	}

    gtk_plot_data_gradient_set_scale(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), scale);

}


static PHP_METHOD(GtkPlotData, remove_link)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_remove_link(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, remove_markers)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_data_remove_markers(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotData, show_markers)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_plot_data_show_markers(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkPlotData, markers_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_data_markers_visible(GTK_PLOT_DATA(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_clone, 0)
    ZEND_ARG_OBJ_INFO(0, copy, GtkPlotData, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_draw_points, 0)
    ZEND_ARG_INFO(0, n)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_draw_symbol, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_a_scale, 0)
    ZEND_ARG_INFO(0, a_scale)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_show_labels, 0)
    ZEND_ARG_INFO(0, show_labels)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_labels_set_attributes, 0)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, foreground, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_numpoints, 0)
    ZEND_ARG_INFO(0, num_points)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_symbol, 0)
    ZEND_ARG_OBJ_INFO(0, type, GtkPlotSymbolType, 1)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotSymbolStyle, 1)
    ZEND_ARG_INFO(0, size)
    ZEND_ARG_INFO(0, line_width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, border_color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_connector, 0)
    ZEND_ARG_OBJ_INFO(0, connector, GtkPlotConnector, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_line_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, cap_style)
    ZEND_ARG_INFO(0, join_style)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_x_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, cap_style)
    ZEND_ARG_INFO(0, join_style)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_y_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, cap_style)
    ZEND_ARG_INFO(0, join_style)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_z_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, cap_style)
    ZEND_ARG_INFO(0, join_style)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_fill_area, 0)
    ZEND_ARG_INFO(0, fill)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_legend, 0)
    ZEND_ARG_INFO(0, legend)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_legend_precision, 0)
    ZEND_ARG_INFO(0, precision)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_name, 0)
    ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_gradient_use_custom_colors, 0)
    ZEND_ARG_INFO(0, custom)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_gradient_mask, 0)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_gradient_set_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_gradient_colors, 0)
    ZEND_ARG_OBJ_INFO(0, min, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, max, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_get_gradient_colors, 0)
    ZEND_ARG_OBJ_INFO(0, min, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, max, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_gradient_nth_color, 0)
    ZEND_ARG_INFO(0, level)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_get_gradient_nth_color, 0)
    ZEND_ARG_INFO(0, level)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_set_gradient_outer_colors, 0)
    ZEND_ARG_OBJ_INFO(0, min, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, max, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_get_gradient_outer_colors, 0)
    ZEND_ARG_OBJ_INFO(0, min, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, max, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotdata_set_gradient, 0, 0, 3)
    ZEND_ARG_INFO(0, min)
    ZEND_ARG_INFO(0, max)
    ZEND_ARG_INFO(0, nlevels)
    ZEND_ARG_INFO(0, nsublevels)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_get_gradient_level, 0)
    ZEND_ARG_INFO(0, level)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_gradient_set_style, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLabelStyle, 1)
    ZEND_ARG_INFO(0, precision)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_gradient_set_scale, 0)
    ZEND_ARG_OBJ_INFO(0, scale, GtkPlotScale, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotdata_show_markers, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static function_entry gtkplotdata_methods[] = {
	PHP_ME(GtkPlotData, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, area_is_filled,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, clone,                arginfo_gtk_gtkplotdata_clone, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, draw_points,          arginfo_gtk_gtkplotdata_draw_points, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, draw_symbol,          arginfo_gtk_gtkplotdata_draw_symbol, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, fill_area,            arginfo_gtk_gtkplotdata_fill_area, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_a_scale,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_connector,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_gradient_colors,  arginfo_gtk_gtkplotdata_get_gradient_colors, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_gradient_level,   arginfo_gtk_gtkplotdata_get_gradient_level, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_gradient_mask,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_gradient_nth_color, arginfo_gtk_gtkplotdata_get_gradient_nth_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_gradient_outer_colors, arginfo_gtk_gtkplotdata_get_gradient_outer_colors, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_legend_precision, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, get_numpoints,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_autoscale_a, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_autoscale_da, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_autoscale_z, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_custom_colors, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_set_scale,   arginfo_gtk_gtkplotdata_gradient_set_scale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_set_style,   arginfo_gtk_gtkplotdata_gradient_set_style, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_set_visible, arginfo_gtk_gtkplotdata_gradient_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_use_custom_colors, arginfo_gtk_gtkplotdata_gradient_use_custom_colors, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, gradient_visible,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, hide_legend,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, hide_xerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, hide_yerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, hide_zerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, labels_set_attributes, arginfo_gtk_gtkplotdata_labels_set_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, markers_visible,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, paint,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, remove_link,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, remove_markers,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, reset_gradient,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, reset_gradient_colors, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_a_scale,          arginfo_gtk_gtkplotdata_set_a_scale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_connector,        arginfo_gtk_gtkplotdata_set_connector, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_gradient,         arginfo_gtk_gtkplotdata_set_gradient, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_gradient_colors,  arginfo_gtk_gtkplotdata_set_gradient_colors, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_gradient_mask,    arginfo_gtk_gtkplotdata_set_gradient_mask, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_gradient_nth_color, arginfo_gtk_gtkplotdata_set_gradient_nth_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_gradient_outer_colors, arginfo_gtk_gtkplotdata_set_gradient_outer_colors, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_legend,           arginfo_gtk_gtkplotdata_set_legend, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_legend_precision, arginfo_gtk_gtkplotdata_set_legend_precision, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_line_attributes,  arginfo_gtk_gtkplotdata_set_line_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_name,             arginfo_gtk_gtkplotdata_set_name, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_numpoints,        arginfo_gtk_gtkplotdata_set_numpoints, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_symbol,           arginfo_gtk_gtkplotdata_set_symbol, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_x_attributes,     arginfo_gtk_gtkplotdata_set_x_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_y_attributes,     arginfo_gtk_gtkplotdata_set_y_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, set_z_attributes,     arginfo_gtk_gtkplotdata_set_z_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_labels,          arginfo_gtk_gtkplotdata_show_labels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_legend,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_markers,         arginfo_gtk_gtkplotdata_show_markers, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_xerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_yerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, show_zerrbars,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotData, update,               NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCandle, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCandle);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCandle);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static function_entry gtkplotcandle_methods[] = {
	PHP_ME(GtkPlotCandle, __construct,          NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotBox, __construct)
{
	GtkOrientation orientation;
	zval *php_orientation = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBox);
	}

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBox);
	}

	wrapped_obj = (GObject *) gtk_plot_box_new(orientation);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBox);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotBox, construct)
{
	GtkOrientation orientation;
	zval *php_orientation = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_box_construct(GTK_PLOT_BOX(PHPG_GOBJECT(this_ptr)), orientation);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotbox_gtk_plot_box_new, 0)
    ZEND_ARG_INFO(0, orientation)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotbox_construct, 0)
    ZEND_ARG_INFO(0, orientation)
ZEND_END_ARG_INFO();

static function_entry gtkplotbox_methods[] = {
	PHP_ME(GtkPlotBox, __construct,          arginfo_gtk_gtkplotbox_gtk_plot_box_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotBox, construct,            arginfo_gtk_gtkplotbox_construct, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotBar, __construct)
{
	GtkOrientation orientation;
	zval *php_orientation = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBar);
	}

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBar);
	}

	wrapped_obj = (GObject *) gtk_plot_bar_new(orientation);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotBar);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotBar, construct)
{
	GtkOrientation orientation;
	zval *php_orientation = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_orientation))
		return;

	if (php_orientation && phpg_gvalue_get_enum(GTK_TYPE_ORIENTATION, php_orientation, (gint *)&orientation) == FAILURE) {
		return;
	}

    gtk_plot_bar_construct(GTK_PLOT_BAR(PHPG_GOBJECT(this_ptr)), orientation);

}


static PHP_METHOD(GtkPlotBar, set_width)
{
	double width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &width))
		return;

    gtk_plot_bar_set_width(GTK_PLOT_BAR(PHPG_GOBJECT(this_ptr)), width);

}


static PHP_METHOD(GtkPlotBar, get_width)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_bar_get_width(GTK_PLOT_BAR(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotbar_gtk_plot_bar_new, 0)
    ZEND_ARG_INFO(0, orientation)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotbar_construct, 0)
    ZEND_ARG_INFO(0, orientation)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotbar_set_width, 0)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static function_entry gtkplotbar_methods[] = {
	PHP_ME(GtkPlotBar, __construct,          arginfo_gtk_gtkplotbar_gtk_plot_bar_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotBar, construct,            arginfo_gtk_gtkplotbar_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotBar, get_width,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotBar, set_width,            arginfo_gtk_gtkplotbar_set_width, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotFlux, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotFlux);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotFlux);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotFlux, set_arrow)
{
	long arrow_length, arrow_width;
	GtkPlotSymbolStyle style;
	zval *php_style = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiV", &arrow_length, &arrow_width, &php_style))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_SYMBOL_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    gtk_plot_flux_set_arrow(GTK_PLOT_FLUX(PHPG_GOBJECT(this_ptr)), (gint)arrow_length, (gint)arrow_width, style);

}


static PHP_METHOD(GtkPlotFlux, center)
{
	zend_bool center;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &center))
		return;

    gtk_plot_flux_center(GTK_PLOT_FLUX(PHPG_GOBJECT(this_ptr)), (gboolean)center);

}


static PHP_METHOD(GtkPlotFlux, is_centered)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_flux_is_centered(GTK_PLOT_FLUX(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotflux_set_arrow, 0)
    ZEND_ARG_INFO(0, arrow_length)
    ZEND_ARG_INFO(0, arrow_width)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotSymbolStyle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotflux_center, 0)
    ZEND_ARG_INFO(0, center)
ZEND_END_ARG_INFO();

static function_entry gtkplotflux_methods[] = {
	PHP_ME(GtkPlotFlux, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotFlux, center,               arginfo_gtk_gtkplotflux_center, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotFlux, is_centered,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotFlux, set_arrow,            arginfo_gtk_gtkplotflux_set_arrow, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotPC, init)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_pc_init(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotPC, leave)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_pc_leave(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotPC, set_viewport)
{
	double w, h;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &w, &h))
		return;

    gtk_plot_pc_set_viewport(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), w, h);

}


static PHP_METHOD(GtkPlotPC, gsave)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_pc_gsave(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotPC, grestore)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_pc_grestore(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotPC, clip)
{
	GdkRectangle area = { 0, 0, 0, 0 };
	zval *php_area;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_area))
		return;

    if (phpg_rectangle_from_zval(php_area, (GdkRectangle*)&area TSRMLS_CC) == FAILURE) {
        php_error(E_WARNING, "%s::%s() expects area argument to be either a 4-element array or a GdkRectangle object", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }
    gtk_plot_pc_clip(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), &area);

}


static PHP_METHOD(GtkPlotPC, clip_mask)
{
	double x, y;
	zval *mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ddO", &x, &y, &mask, gdkpixmap_ce))
		return;

    gtk_plot_pc_clip_mask(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), x, y, GDK_PIXMAP(PHPG_GOBJECT(mask)));

}


static PHP_METHOD(GtkPlotPC, set_color)
{
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_pc_set_color(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), color);

}


static PHP_METHOD(GtkPlotPC, set_lineattr)
{
	double line_width;
	GdkLineStyle line_style;
	zval *php_line_style = NULL, *php_cap_style = NULL, *php_join_style = NULL;
	GdkCapStyle cap_style;
	GdkJoinStyle join_style;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dVVV", &line_width, &php_line_style, &php_cap_style, &php_join_style))
		return;

	if (php_line_style && phpg_gvalue_get_enum(GDK_TYPE_LINE_STYLE, php_line_style, (gint *)&line_style) == FAILURE) {
		return;
	}

	if (php_cap_style && phpg_gvalue_get_enum(GDK_TYPE_CAP_STYLE, php_cap_style, (gint *)&cap_style) == FAILURE) {
		return;
	}

	if (php_join_style && phpg_gvalue_get_enum(GDK_TYPE_JOIN_STYLE, php_join_style, (gint *)&join_style) == FAILURE) {
		return;
	}

    gtk_plot_pc_set_lineattr(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), (float)line_width, line_style, cap_style, join_style);

}


static PHP_METHOD(GtkPlotPC, draw_point)
{
	double x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &x, &y))
		return;

    gtk_plot_pc_draw_point(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), x, y);

}


static PHP_METHOD(GtkPlotPC, draw_line)
{
	double x1, y1, x2, y2;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dddd", &x1, &y1, &x2, &y2))
		return;

    gtk_plot_pc_draw_line(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), x1, y1, x2, y2);

}


static PHP_METHOD(GtkPlotPC, draw_rectangle)
{
	zend_bool filled;
	double x, y, width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "bdddd", &filled, &x, &y, &width, &height))
		return;

    gtk_plot_pc_draw_rectangle(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), (gboolean)filled, x, y, width, height);

}


static PHP_METHOD(GtkPlotPC, draw_ellipse)
{
	zend_bool filled;
	double x, y, width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "bdddd", &filled, &x, &y, &width, &height))
		return;

    gtk_plot_pc_draw_ellipse(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), (gboolean)filled, x, y, width, height);

}


static PHP_METHOD(GtkPlotPC, draw_circle)
{
	long filled;
	double x, y, size;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iddd", &filled, &x, &y, &size))
		return;

    gtk_plot_pc_draw_circle(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), (gint)filled, x, y, size);

}


static PHP_METHOD(GtkPlotPC, draw_string)
{
	long x, y, angle, border, border_space, border_width, shadow_width, height;
	GdkColor *fg = NULL, *bg = NULL;
	zval *php_fg, *php_bg, *php_just = NULL;
	zend_bool transparent, free_font = FALSE, free_text = FALSE;
	char *font, *text;
	GtkJustification just;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiiOObiiiiuiVu", &x, &y, &angle, &php_fg, gboxed_ce, &php_bg, gboxed_ce, &transparent, &border, &border_space, &border_width, &shadow_width, &font, &free_font, &height, &php_just, &text, &free_text))
		return;

    if (phpg_gboxed_check(php_fg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        fg = (GdkColor *) PHPG_GBOXED(php_fg);
    } else {
        php_error(E_WARNING, "%s::%s() expects fg argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_bg, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        bg = (GdkColor *) PHPG_GBOXED(php_bg);
    } else {
        php_error(E_WARNING, "%s::%s() expects bg argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

	if (php_just && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_just, (gint *)&just) == FAILURE) {
		return;
	}

    gtk_plot_pc_draw_string(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), (gint)x, (gint)y, (gint)angle, fg, bg, (gboolean)transparent, (gint)border, (gint)border_space, (gint)border_width, (gint)shadow_width, font, (gint)height, just, text);
	if (free_font) g_free(font);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkPlotPC, draw_pixmap)
{
	zval *pixmap, *mask;
	long xsrc, ysrc, xdest, ydest, width, height;
	double scale_x, scale_y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OOiiiiiidd", &pixmap, gdkpixmap_ce, &mask, gdkpixmap_ce, &xsrc, &ysrc, &xdest, &ydest, &width, &height, &scale_x, &scale_y))
		return;

    gtk_plot_pc_draw_pixmap(GTK_PLOT_PC(PHPG_GOBJECT(this_ptr)), GDK_PIXMAP(PHPG_GOBJECT(pixmap)), GDK_PIXMAP(PHPG_GOBJECT(mask)), (gint)xsrc, (gint)ysrc, (gint)xdest, (gint)ydest, (gint)width, (gint)height, scale_x, scale_y);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_set_viewport, 0)
    ZEND_ARG_INFO(0, w)
    ZEND_ARG_INFO(0, h)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_clip, 0)
    ZEND_ARG_OBJ_INFO(0, area, GdkRectangle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_clip_mask, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_set_color, 0)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_set_lineattr, 0)
    ZEND_ARG_INFO(0, line_width)
    ZEND_ARG_INFO(0, line_style)
    ZEND_ARG_INFO(0, cap_style)
    ZEND_ARG_INFO(0, join_style)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_point, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_line, 0)
    ZEND_ARG_INFO(0, x1)
    ZEND_ARG_INFO(0, y1)
    ZEND_ARG_INFO(0, x2)
    ZEND_ARG_INFO(0, y2)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_rectangle, 0)
    ZEND_ARG_INFO(0, filled)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_ellipse, 0)
    ZEND_ARG_INFO(0, filled)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_circle, 0)
    ZEND_ARG_INFO(0, filled)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, size)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_string, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, angle)
    ZEND_ARG_OBJ_INFO(0, fg, GdkColor, 1)
    ZEND_ARG_OBJ_INFO(0, bg, GdkColor, 1)
    ZEND_ARG_INFO(0, transparent)
    ZEND_ARG_INFO(0, border)
    ZEND_ARG_INFO(0, border_space)
    ZEND_ARG_INFO(0, border_width)
    ZEND_ARG_INFO(0, shadow_width)
    ZEND_ARG_INFO(0, font)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, just)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpc_draw_pixmap, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, mask)
    ZEND_ARG_INFO(0, xsrc)
    ZEND_ARG_INFO(0, ysrc)
    ZEND_ARG_INFO(0, xdest)
    ZEND_ARG_INFO(0, ydest)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, scale_x)
    ZEND_ARG_INFO(0, scale_y)
ZEND_END_ARG_INFO();

static function_entry gtkplotpc_methods[] = {
	PHP_ME(GtkPlotPC, clip,                 arginfo_gtk_gtkplotpc_clip, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, clip_mask,            arginfo_gtk_gtkplotpc_clip_mask, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_circle,          arginfo_gtk_gtkplotpc_draw_circle, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_ellipse,         arginfo_gtk_gtkplotpc_draw_ellipse, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_line,            arginfo_gtk_gtkplotpc_draw_line, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_pixmap,          arginfo_gtk_gtkplotpc_draw_pixmap, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_point,           arginfo_gtk_gtkplotpc_draw_point, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_rectangle,       arginfo_gtk_gtkplotpc_draw_rectangle, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, draw_string,          arginfo_gtk_gtkplotpc_draw_string, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, grestore,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, gsave,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, init,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, leave,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, set_color,            arginfo_gtk_gtkplotpc_set_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, set_lineattr,         arginfo_gtk_gtkplotpc_set_lineattr, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPC, set_viewport,         arginfo_gtk_gtkplotpc_set_viewport, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotGdk, __construct)
{
	zval *widget;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &widget, gtkwidget_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotGdk);
	}

	wrapped_obj = (GObject *) gtk_plot_gdk_new(GTK_WIDGET(PHPG_GOBJECT(widget)));

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotGdk);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotGdk, construct)
{
	zval *widget;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &widget, gtkwidget_ce))
		return;

    gtk_plot_gdk_construct(GTK_PLOT_GDK(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)));

}


static PHP_METHOD(GtkPlotGdk, set_drawable)
{
	zval *drawable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce))
		return;

    gtk_plot_gdk_set_drawable(GTK_PLOT_GDK(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotgdk_gtk_plot_gdk_new, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotgdk_construct, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotgdk_set_drawable, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplotgdk_methods[] = {
	PHP_ME(GtkPlotGdk, __construct,          arginfo_gtk_gtkplotgdk_gtk_plot_gdk_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotGdk, construct,            arginfo_gtk_gtkplotgdk_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotGdk, set_drawable,         arginfo_gtk_gtkplotgdk_set_drawable, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotPS, __construct)
{
	char *psname;
	zend_bool free_psname = FALSE;
	long orientation, epsflag, page_size;
	double scalex, scaley;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiidd", &psname, &free_psname, &orientation, &epsflag, &page_size, &scalex, &scaley)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPS);
	}

	wrapped_obj = (GObject *) gtk_plot_ps_new(psname, (gint)orientation, (gint)epsflag, (gint)page_size, scalex, scaley);
	if (free_psname) g_free(psname);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPS);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotPS, construct)
{
	char *psname;
	zend_bool free_psname = FALSE;
	long orientation, epsflag, page_size;
	double scalex, scaley;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiidd", &psname, &free_psname, &orientation, &epsflag, &page_size, &scalex, &scaley))
		return;

    gtk_plot_ps_construct(GTK_PLOT_PS(PHPG_GOBJECT(this_ptr)), psname, (gint)orientation, (gint)epsflag, (gint)page_size, scalex, scaley);
	if (free_psname) g_free(psname);

}


static PHP_METHOD(GtkPlotPS, construct_with_size)
{
	char *psname;
	zend_bool free_psname = FALSE;
	long orientation, epsflag, units;
	double width, height, scalex, scaley;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiiidddd", &psname, &free_psname, &orientation, &epsflag, &units, &width, &height, &scalex, &scaley))
		return;

    gtk_plot_ps_construct_with_size(GTK_PLOT_PS(PHPG_GOBJECT(this_ptr)), psname, (gint)orientation, (gint)epsflag, (gint)units, width, height, scalex, scaley);
	if (free_psname) g_free(psname);

}


static PHP_METHOD(GtkPlotPS, set_size)
{
	long units;
	double width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "idd", &units, &width, &height))
		return;

    gtk_plot_ps_set_size(GTK_PLOT_PS(PHPG_GOBJECT(this_ptr)), (gint)units, width, height);

}


static PHP_METHOD(GtkPlotPS, set_scale)
{
	double scalex, scaley;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "dd", &scalex, &scaley))
		return;

    gtk_plot_ps_set_scale(GTK_PLOT_PS(PHPG_GOBJECT(this_ptr)), scalex, scaley);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotps_gtk_plot_ps_new, 0)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, orientation)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_INFO(0, page_size)
    ZEND_ARG_INFO(0, scalex)
    ZEND_ARG_INFO(0, scaley)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotps_construct, 0)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, orientation)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_INFO(0, page_size)
    ZEND_ARG_INFO(0, scalex)
    ZEND_ARG_INFO(0, scaley)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotps_construct_with_size, 0)
    ZEND_ARG_INFO(0, psname)
    ZEND_ARG_INFO(0, orientation)
    ZEND_ARG_INFO(0, epsflag)
    ZEND_ARG_INFO(0, units)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
    ZEND_ARG_INFO(0, scalex)
    ZEND_ARG_INFO(0, scaley)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotps_set_size, 0)
    ZEND_ARG_INFO(0, units)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotps_set_scale, 0)
    ZEND_ARG_INFO(0, scalex)
    ZEND_ARG_INFO(0, scaley)
ZEND_END_ARG_INFO();

static function_entry gtkplotps_methods[] = {
	PHP_ME(GtkPlotPS, __construct,          arginfo_gtk_gtkplotps_gtk_plot_ps_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPS, construct,            arginfo_gtk_gtkplotps_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPS, construct_with_size,  arginfo_gtk_gtkplotps_construct_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPS, set_scale,            arginfo_gtk_gtkplotps_set_scale, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPS, set_size,             arginfo_gtk_gtkplotps_set_size, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotPixmap, __construct)
{
	zval *pixmap, *php_mask = NULL;
	GdkPixmap *mask = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O|N", &pixmap, gdkpixmap_ce, &php_mask, gdkpixmap_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPixmap);
	}
    if (php_mask) {
        if (Z_TYPE_P(php_mask) == IS_NULL)
            mask = NULL;
        else
            mask = GDK_PIXMAP(PHPG_GOBJECT(php_mask));
    }

	wrapped_obj = (GObject *) gtk_plot_pixmap_new(GDK_PIXMAP(PHPG_GOBJECT(pixmap)), mask);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPixmap);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotPixmap, construct)
{
	zval *pixmap, *mask;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &pixmap, gdkpixmap_ce, &mask, gdkpixmap_ce))
		return;

    gtk_plot_pixmap_construct(GTK_PLOT_PIXMAP(PHPG_GOBJECT(this_ptr)), GDK_PIXMAP(PHPG_GOBJECT(pixmap)), GDK_PIXMAP(PHPG_GOBJECT(mask)));

}


static PHP_METHOD(GtkPlotPixmap, get_pixmap)
{
	GdkPixmap* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_pixmap_get_pixmap(GTK_PLOT_PIXMAP(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkPlotPixmap, get_mask)
{
	GdkBitmap* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_pixmap_get_mask(GTK_PLOT_PIXMAP(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotpixmap_gtk_plot_pixmap_new, 0, 0, 1)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpixmap_construct, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, mask)
ZEND_END_ARG_INFO();

static function_entry gtkplotpixmap_methods[] = {
	PHP_ME(GtkPlotPixmap, __construct,          arginfo_gtk_gtkplotpixmap_gtk_plot_pixmap_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPixmap, construct,            arginfo_gtk_gtkplotpixmap_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPixmap, get_mask,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPixmap, get_pixmap,           NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotPolar, __construct)
{
	GdkDrawable *drawable = NULL;
	zval *php_drawable = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|N", &php_drawable, gdkdrawable_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPolar);
	}
    if (php_drawable) {
        if (Z_TYPE_P(php_drawable) == IS_NULL)
            drawable = NULL;
        else
            drawable = GDK_DRAWABLE(PHPG_GOBJECT(php_drawable));
    }

	wrapped_obj = (GObject *) gtk_plot_polar_new(drawable);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotPolar);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotPolar, construct)
{
	zval *drawable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &drawable, gdkdrawable_ce))
		return;

    gtk_plot_polar_construct(GTK_PLOT_POLAR(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)));

}


static PHP_METHOD(GtkPlotPolar, construct_with_size)
{
	zval *drawable;
	double width, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Odd", &drawable, gdkdrawable_ce, &width, &height))
		return;

    gtk_plot_polar_construct_with_size(GTK_PLOT_POLAR(PHPG_GOBJECT(this_ptr)), GDK_DRAWABLE(PHPG_GOBJECT(drawable)), width, height);

}


static PHP_METHOD(GtkPlotPolar, rotate)
{
	double angle;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &angle))
		return;

    gtk_plot_polar_rotate(GTK_PLOT_POLAR(PHPG_GOBJECT(this_ptr)), angle);

}


static PHP_METHOD(GtkPlotPolar, get_angle)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_polar_get_angle(GTK_PLOT_POLAR(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtkplotpolar_gtk_plot_polar_new, 0, 0, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpolar_construct, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpolar_construct_with_size, 0)
    ZEND_ARG_OBJ_INFO(0, drawable, GdkDrawable, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotpolar_rotate, 0)
    ZEND_ARG_INFO(0, angle)
ZEND_END_ARG_INFO();

static function_entry gtkplotpolar_methods[] = {
	PHP_ME(GtkPlotPolar, __construct,          arginfo_gtk_gtkplotpolar_gtk_plot_polar_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPolar, construct,            arginfo_gtk_gtkplotpolar_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPolar, construct_with_size,  arginfo_gtk_gtkplotpolar_construct_with_size, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPolar, get_angle,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotPolar, rotate,               arginfo_gtk_gtkplotpolar_rotate, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotSurface, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotSurface);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotSurface);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotSurface, set_color)
{
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_surface_set_color(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), color);

}


static PHP_METHOD(GtkPlotSurface, set_shadow)
{
	GdkColor *color = NULL;
	zval *php_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_surface_set_shadow(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), color);

}


static PHP_METHOD(GtkPlotSurface, set_grid_foreground)
{
	GdkColor *foreground = NULL;
	zval *php_foreground;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_foreground, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_foreground, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        foreground = (GdkColor *) PHPG_GBOXED(php_foreground);
    } else {
        php_error(E_WARNING, "%s::%s() expects foreground argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_surface_set_grid_foreground(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), foreground);

}


static PHP_METHOD(GtkPlotSurface, set_grid_background)
{
	GdkColor *background = NULL;
	zval *php_background;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_background, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_background, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        background = (GdkColor *) PHPG_GBOXED(php_background);
    } else {
        php_error(E_WARNING, "%s::%s() expects background argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_surface_set_grid_background(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), background);

}


static PHP_METHOD(GtkPlotSurface, set_grid_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_surface_set_grid_visible(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotSurface, get_grid_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_grid_visible(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotSurface, set_mesh_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_surface_set_mesh_visible(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotSurface, get_mesh_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_mesh_visible(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotSurface, set_light)
{
	double x, y, z;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ddd", &x, &y, &z))
		return;

    gtk_plot_surface_set_light(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), x, y, z);

}


static PHP_METHOD(GtkPlotSurface, set_ambient)
{
	double ambient;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &ambient))
		return;

    gtk_plot_surface_set_ambient(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), ambient);

}


static PHP_METHOD(GtkPlotSurface, use_height_gradient)
{
	zend_bool use_gradient;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &use_gradient))
		return;

    gtk_plot_surface_use_height_gradient(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)use_gradient);

}


static PHP_METHOD(GtkPlotSurface, use_amplitud)
{
	zend_bool use_amplitud;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &use_amplitud))
		return;

    gtk_plot_surface_use_amplitud(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)use_amplitud);

}


static PHP_METHOD(GtkPlotSurface, set_transparent)
{
	zend_bool transparent;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &transparent))
		return;

    gtk_plot_surface_set_transparent(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)transparent);

}


static PHP_METHOD(GtkPlotSurface, set_nx)
{
	long nx;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &nx))
		return;

    gtk_plot_surface_set_nx(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gint)nx);

}


static PHP_METHOD(GtkPlotSurface, set_ny)
{
	long ny;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &ny))
		return;

    gtk_plot_surface_set_ny(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), (gint)ny);

}


static PHP_METHOD(GtkPlotSurface, get_nx)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_nx(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotSurface, get_ny)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_ny(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotSurface, set_xstep)
{
	double xstep;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &xstep))
		return;

    gtk_plot_surface_set_xstep(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), xstep);

}


static PHP_METHOD(GtkPlotSurface, set_ystep)
{
	double ystep;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &ystep))
		return;

    gtk_plot_surface_set_ystep(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)), ystep);

}


static PHP_METHOD(GtkPlotSurface, get_xstep)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_xstep(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotSurface, get_ystep)
{
	double php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_surface_get_ystep(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_DOUBLE(php_retval);
}


static PHP_METHOD(GtkPlotSurface, build_mesh)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_surface_build_mesh(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkPlotSurface, recalc_nodes)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_plot_surface_recalc_nodes(GTK_PLOT_SURFACE(PHPG_GOBJECT(this_ptr)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_color, 0)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_shadow, 0)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_grid_foreground, 0)
    ZEND_ARG_OBJ_INFO(0, foreground, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_grid_background, 0)
    ZEND_ARG_OBJ_INFO(0, background, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_grid_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_mesh_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_light, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
    ZEND_ARG_INFO(0, z)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_ambient, 0)
    ZEND_ARG_INFO(0, ambient)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_use_height_gradient, 0)
    ZEND_ARG_INFO(0, use_gradient)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_use_amplitud, 0)
    ZEND_ARG_INFO(0, use_amplitud)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_transparent, 0)
    ZEND_ARG_INFO(0, transparent)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_nx, 0)
    ZEND_ARG_INFO(0, nx)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_ny, 0)
    ZEND_ARG_INFO(0, ny)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_xstep, 0)
    ZEND_ARG_INFO(0, xstep)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotsurface_set_ystep, 0)
    ZEND_ARG_INFO(0, ystep)
ZEND_END_ARG_INFO();

static function_entry gtkplotsurface_methods[] = {
	PHP_ME(GtkPlotSurface, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, build_mesh,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_grid_visible,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_mesh_visible,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_nx,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_ny,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_xstep,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, get_ystep,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, recalc_nodes,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_ambient,          arginfo_gtk_gtkplotsurface_set_ambient, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_color,            arginfo_gtk_gtkplotsurface_set_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_grid_background,  arginfo_gtk_gtkplotsurface_set_grid_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_grid_foreground,  arginfo_gtk_gtkplotsurface_set_grid_foreground, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_grid_visible,     arginfo_gtk_gtkplotsurface_set_grid_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_light,            arginfo_gtk_gtkplotsurface_set_light, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_mesh_visible,     arginfo_gtk_gtkplotsurface_set_mesh_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_nx,               arginfo_gtk_gtkplotsurface_set_nx, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_ny,               arginfo_gtk_gtkplotsurface_set_ny, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_shadow,           arginfo_gtk_gtkplotsurface_set_shadow, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_transparent,      arginfo_gtk_gtkplotsurface_set_transparent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_xstep,            arginfo_gtk_gtkplotsurface_set_xstep, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, set_ystep,            arginfo_gtk_gtkplotsurface_set_ystep, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, use_amplitud,         arginfo_gtk_gtkplotsurface_use_amplitud, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotSurface, use_height_gradient,  arginfo_gtk_gtkplotsurface_use_height_gradient, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkPlotCSurface, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCSurface);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkPlotCSurface);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkPlotCSurface, set_lines_visible)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_plot_csurface_set_lines_visible(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkPlotCSurface, get_lines_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_csurface_get_lines_visible(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkPlotCSurface, set_projection)
{
	GtkPlotProjection proj;
	zval *php_proj = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_proj))
		return;

	if (php_proj && phpg_gvalue_get_enum(GTK_TYPE_PLOT_PROJECTION, php_proj, (gint *)&proj) == FAILURE) {
		return;
	}

    gtk_plot_csurface_set_projection(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)), proj);

}


static PHP_METHOD(GtkPlotCSurface, projection)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_plot_csurface_projection(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkPlotCSurface, set_levels_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_csurface_set_levels_attributes(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static PHP_METHOD(GtkPlotCSurface, set_sublevels_attributes)
{
	GtkPlotLineStyle style;
	zval *php_style = NULL, *php_color;
	double width;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "VdO", &php_style, &width, &php_color, gboxed_ce))
		return;

	if (php_style && phpg_gvalue_get_enum(GTK_TYPE_PLOT_LINE_STYLE, php_style, (gint *)&style) == FAILURE) {
		return;
	}

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_plot_csurface_set_sublevels_attributes(GTK_PLOT_CSURFACE(PHPG_GOBJECT(this_ptr)), style, (float)width, color);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcsurface_set_lines_visible, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcsurface_set_projection, 0)
    ZEND_ARG_OBJ_INFO(0, proj, GtkPlotProjection, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcsurface_set_levels_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkplotcsurface_set_sublevels_attributes, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkPlotLineStyle, 1)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static function_entry gtkplotcsurface_methods[] = {
	PHP_ME(GtkPlotCSurface, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, get_lines_visible,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, projection,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, set_levels_attributes, arginfo_gtk_gtkplotcsurface_set_levels_attributes, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, set_lines_visible,    arginfo_gtk_gtkplotcsurface_set_lines_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, set_projection,       arginfo_gtk_gtkplotcsurface_set_projection, ZEND_ACC_PUBLIC)
	PHP_ME(GtkPlotCSurface, set_sublevels_attributes, arginfo_gtk_gtkplotcsurface_set_sublevels_attributes, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSheet, __construct)
{
	long rows, columns;
	char *title;
	zend_bool free_title = FALSE;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &rows, &columns, &title, &free_title)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}

	wrapped_obj = (GObject *) gtk_sheet_new((guint)rows, (guint)columns, title);
	if (free_title) g_free(title);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkSheet, new_browser)
{
	long rows, columns;
	char *title;
	zend_bool free_title = FALSE;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &rows, &columns, &title, &free_title)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}

	wrapped_obj = (GObject *) gtk_sheet_new_browser((guint)rows, (guint)columns, title);
	if (free_title) g_free(title);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}
    phpg_gobject_new(&return_value, wrapped_obj TSRMLS_CC);
    g_object_unref(wrapped_obj); /* phpg_gobject_new() increments reference count */
}


static PHP_METHOD(GtkSheet, new_with_custom_entry)
{
	long rows, columns, entry_type;
	char *title;
	zend_bool free_title = FALSE;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiui", &rows, &columns, &title, &free_title, &entry_type)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}

	wrapped_obj = (GObject *) gtk_sheet_new_with_custom_entry((guint)rows, (guint)columns, title, (GtkType)entry_type);
	if (free_title) g_free(title);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheet);
	}
    phpg_gobject_new(&return_value, wrapped_obj TSRMLS_CC);
    g_object_unref(wrapped_obj); /* phpg_gobject_new() increments reference count */
}


static PHP_METHOD(GtkSheet, construct)
{
	long rows, columns;
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &rows, &columns, &title, &free_title))
		return;

    gtk_sheet_construct(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)rows, (guint)columns, title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, construct_browser)
{
	long rows, columns;
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &rows, &columns, &title, &free_title))
		return;

    gtk_sheet_construct_browser(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)rows, (guint)columns, title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, construct_with_custom_entry)
{
	long rows, columns, entry_type;
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiui", &rows, &columns, &title, &free_title, &entry_type))
		return;

    gtk_sheet_construct_with_custom_entry(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)rows, (guint)columns, title, (GtkType)entry_type);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, set_hadjustment)
{
	zval *adjustment;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &adjustment, gtkadjustment_ce))
		return;

    gtk_sheet_set_hadjustment(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_ADJUSTMENT(PHPG_GOBJECT(adjustment)));

}


static PHP_METHOD(GtkSheet, set_vadjustment)
{
	zval *adjustment;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &adjustment, gtkadjustment_ce))
		return;

    gtk_sheet_set_vadjustment(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_ADJUSTMENT(PHPG_GOBJECT(adjustment)));

}


static PHP_METHOD(GtkSheet, change_entry)
{
	long entry_type;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &entry_type))
		return;

    gtk_sheet_change_entry(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (GtkType)entry_type);

}


static PHP_METHOD(GtkSheet, get_entry)
{
	GtkWidget* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_entry(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSheet, get_entry_widget)
{
	GtkWidget* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_entry_widget(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSheet, get_state)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_state(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSheet, get_columns_count)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_columns_count(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSheet, get_rows_count)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_rows_count(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSheet, get_visible_range)
{
	GtkSheetRange *range = NULL;
	zval *php_range;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_range, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_get_visible_range(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range);

}


static PHP_METHOD(GtkSheet, set_selection_mode)
{
	long mode;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &mode))
		return;

    gtk_sheet_set_selection_mode(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)mode);

}


static PHP_METHOD(GtkSheet, set_autoresize)
{
	zend_bool autoresize;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &autoresize))
		return;

    gtk_sheet_set_autoresize(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)autoresize);

}


static PHP_METHOD(GtkSheet, autoresize)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_autoresize(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_autoscroll)
{
	zend_bool autoscroll;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &autoscroll))
		return;

    gtk_sheet_set_autoscroll(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)autoscroll);

}


static PHP_METHOD(GtkSheet, autoscroll)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_autoscroll(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_clip_text)
{
	zend_bool clip_text;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &clip_text))
		return;

    gtk_sheet_set_clip_text(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)clip_text);

}


static PHP_METHOD(GtkSheet, clip_text)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_clip_text(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_justify_entry)
{
	zend_bool justify;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &justify))
		return;

    gtk_sheet_set_justify_entry(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)justify);

}


static PHP_METHOD(GtkSheet, justify_entry)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_justify_entry(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_locked)
{
	zend_bool lock;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &lock))
		return;

    gtk_sheet_set_locked(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)lock);

}


static PHP_METHOD(GtkSheet, locked)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_locked(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_title)
{
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &title, &free_title))
		return;

    gtk_sheet_set_title(GTK_SHEET(PHPG_GOBJECT(this_ptr)), title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, freeze)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_freeze(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, thaw)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_thaw(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, set_background)
{
	GdkColor *bg_color = NULL;
	zval *php_bg_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_bg_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_bg_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        bg_color = (GdkColor *) PHPG_GBOXED(php_bg_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects bg_color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_set_background(GTK_SHEET(PHPG_GOBJECT(this_ptr)), bg_color);

}


static PHP_METHOD(GtkSheet, set_grid)
{
	GdkColor *grid_color = NULL;
	zval *php_grid_color;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_grid_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_grid_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        grid_color = (GdkColor *) PHPG_GBOXED(php_grid_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects grid_color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_set_grid(GTK_SHEET(PHPG_GOBJECT(this_ptr)), grid_color);

}


static PHP_METHOD(GtkSheet, show_grid)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_sheet_show_grid(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkSheet, grid_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_grid_visible(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_column_title)
{
	long column;
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iu", &column, &title, &free_title))
		return;

    gtk_sheet_set_column_title(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, get_column_title)
{
	long column;
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &column))
		return;

    php_retval = gtk_sheet_get_column_title(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSheet, set_row_title)
{
	long row;
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iu", &row, &title, &free_title))
		return;

    gtk_sheet_set_row_title(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkSheet, get_row_title)
{
	long row;
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &row))
		return;

    php_retval = gtk_sheet_get_row_title(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSheet, row_button_add_label)
{
	long row;
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iu", &row, &label, &free_label))
		return;

    gtk_sheet_row_button_add_label(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, label);
	if (free_label) g_free(label);

}


static PHP_METHOD(GtkSheet, column_button_add_label)
{
	long column;
	char *label;
	zend_bool free_label = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iu", &column, &label, &free_label))
		return;

    gtk_sheet_column_button_add_label(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, label);
	if (free_label) g_free(label);

}


static PHP_METHOD(GtkSheet, row_button_get_label)
{
	long row;
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &row))
		return;

    php_retval = gtk_sheet_row_button_get_label(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSheet, column_button_get_label)
{
	long column;
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &column))
		return;

    php_retval = gtk_sheet_column_button_get_label(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSheet, row_button_justify)
{
	long row;
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iV", &row, &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_sheet_row_button_justify(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, justification);

}


static PHP_METHOD(GtkSheet, column_button_justify)
{
	long column;
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iV", &column, &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_sheet_column_button_justify(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, justification);

}


static PHP_METHOD(GtkSheet, moveto)
{
	long row, column;
	double row_align, col_align;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iidd", &row, &column, &row_align, &col_align))
		return;

    gtk_sheet_moveto(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)column, (float)row_align, (float)col_align);

}


static PHP_METHOD(GtkSheet, set_row_titles_width)
{
	long width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &width))
		return;

    gtk_sheet_set_row_titles_width(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)width);

}


static PHP_METHOD(GtkSheet, set_column_titles_height)
{
	long height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &height))
		return;

    gtk_sheet_set_column_titles_height(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)height);

}


static PHP_METHOD(GtkSheet, show_column_titles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_show_column_titles(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, show_row_titles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_show_row_titles(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, hide_column_titles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_hide_column_titles(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, hide_row_titles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_hide_row_titles(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, column_titles_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_column_titles_visible(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, row_titles_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_row_titles_visible(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, column_set_sensitivity)
{
	long column;
	zend_bool sensitive;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &column, &sensitive))
		return;

    gtk_sheet_column_set_sensitivity(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, (gboolean)sensitive);

}


static PHP_METHOD(GtkSheet, columns_set_sensitivity)
{
	zend_bool sensitive;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &sensitive))
		return;

    gtk_sheet_columns_set_sensitivity(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)sensitive);

}


static PHP_METHOD(GtkSheet, columns_set_resizable)
{
	zend_bool resizable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &resizable))
		return;

    gtk_sheet_columns_set_resizable(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)resizable);

}


static PHP_METHOD(GtkSheet, columns_resizable)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_columns_resizable(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, row_set_sensitivity)
{
	long row;
	zend_bool sensitive;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &row, &sensitive))
		return;

    gtk_sheet_row_set_sensitivity(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gboolean)sensitive);

}


static PHP_METHOD(GtkSheet, rows_set_sensitivity)
{
	zend_bool sensitive;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &sensitive))
		return;

    gtk_sheet_rows_set_sensitivity(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)sensitive);

}


static PHP_METHOD(GtkSheet, rows_set_resizable)
{
	zend_bool resizable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &resizable))
		return;

    gtk_sheet_rows_set_resizable(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)resizable);

}


static PHP_METHOD(GtkSheet, rows_resizable)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_rows_resizable(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, column_set_visibility)
{
	long column;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &column, &visible))
		return;

    gtk_sheet_column_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, (gboolean)visible);

}


static PHP_METHOD(GtkSheet, column_label_set_visibility)
{
	long column;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &column, &visible))
		return;

    gtk_sheet_column_label_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, (gboolean)visible);

}


static PHP_METHOD(GtkSheet, columns_labels_set_visibility)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_sheet_columns_labels_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkSheet, row_set_visibility)
{
	long row;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &row, &visible))
		return;

    gtk_sheet_row_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gboolean)visible);

}


static PHP_METHOD(GtkSheet, row_label_set_visibility)
{
	long row;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ib", &row, &visible))
		return;

    gtk_sheet_row_label_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gboolean)visible);

}


static PHP_METHOD(GtkSheet, rows_labels_set_visibility)
{
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &visible))
		return;

    gtk_sheet_rows_labels_set_visibility(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gboolean)visible);

}


static PHP_METHOD(GtkSheet, select_row)
{
	long row;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &row))
		return;

    gtk_sheet_select_row(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row);

}


static PHP_METHOD(GtkSheet, select_column)
{
	long column;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &column))
		return;

    gtk_sheet_select_column(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column);

}


static PHP_METHOD(GtkSheet, clip_range)
{
	GtkSheetRange *range = NULL;
	zval *php_range;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_range, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_clip_range(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range);

}


static PHP_METHOD(GtkSheet, unclip_range)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_unclip_range(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, in_clip)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_in_clip(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, get_vadjustment)
{
	GtkAdjustment* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_vadjustment(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSheet, get_hadjustment)
{
	GtkAdjustment* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_sheet_get_hadjustment(GTK_SHEET(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSheet, select_range)
{
	GtkSheetRange *range = NULL;
	zval *php_range;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_range, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_select_range(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range);

}


static PHP_METHOD(GtkSheet, unselect_range)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_sheet_unselect_range(GTK_SHEET(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSheet, set_active_cell)
{
	long row, column;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &column))
		return;

    php_retval = gtk_sheet_set_active_cell(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)column);
	RETVAL_BOOL(php_retval);
}

#line 190 "ext/extra/gtkextra.overrides"
static PHP_METHOD(GtkSheet, get_active_cell)
{
    gint row, column;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
        return;

    gtk_sheet_get_active_cell(GTK_SHEET(PHPG_GOBJECT(this_ptr)), &row, &column);

    array_init(return_value);
    add_index_long(return_value,0,(long)row);
    add_index_long(return_value,1,(long)column);
}

#line 12116 "ext/extra/gen_gtkextra.c"



static PHP_METHOD(GtkSheet, set_cell)
{
	long row, col;
	GtkJustification justification;
	zval *php_justification = NULL;
	char *text;
	zend_bool free_text = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiVu", &row, &col, &php_justification, &text, &free_text))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_sheet_set_cell(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col, justification, text);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkSheet, set_cell_text)
{
	long row, col;
	char *text;
	zend_bool free_text = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiu", &row, &col, &text, &free_text))
		return;

    gtk_sheet_set_cell_text(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col, text);
	if (free_text) g_free(text);

}


static PHP_METHOD(GtkSheet, cell_get_text)
{
	long row, col;
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    php_retval = gtk_sheet_cell_get_text(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSheet, cell_clear)
{
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    gtk_sheet_cell_clear(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);

}


static PHP_METHOD(GtkSheet, cell_delete)
{
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    gtk_sheet_cell_delete(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);

}


static PHP_METHOD(GtkSheet, range_clear)
{
	GtkSheetRange *range = NULL;
	zval *php_range;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_range, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_clear(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range);

}


static PHP_METHOD(GtkSheet, range_delete)
{
	GtkSheetRange *range = NULL;
	zval *php_range;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_range, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_delete(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range);

}


static PHP_METHOD(GtkSheet, cell_get_state)
{
	long row, col, php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    php_retval = gtk_sheet_cell_get_state(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSheet, remove_link)
{
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    gtk_sheet_remove_link(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);

}


static PHP_METHOD(GtkSheet, get_cell_area)
{
	long row, column;
	GdkRectangle area = { 0, 0, 0, 0 };
	zval *php_area;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iiV", &row, &column, &php_area))
		return;

    if (phpg_rectangle_from_zval(php_area, (GdkRectangle*)&area TSRMLS_CC) == FAILURE) {
        php_error(E_WARNING, "%s::%s() expects area argument to be either a 4-element array or a GdkRectangle object", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }
    php_retval = gtk_sheet_get_cell_area(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)column, &area);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSheet, set_column_width)
{
	long column, width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &column, &width))
		return;

    gtk_sheet_set_column_width(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, (guint)width);

}


static PHP_METHOD(GtkSheet, set_row_height)
{
	long row, height;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &height))
		return;

    gtk_sheet_set_row_height(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)row, (guint)height);

}


static PHP_METHOD(GtkSheet, add_column)
{
	long ncols;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &ncols))
		return;

    gtk_sheet_add_column(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)ncols);

}


static PHP_METHOD(GtkSheet, add_row)
{
	long nrows;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &nrows))
		return;

    gtk_sheet_add_row(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)nrows);

}


static PHP_METHOD(GtkSheet, insert_rows)
{
	long row, nrows;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &nrows))
		return;

    gtk_sheet_insert_rows(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)row, (guint)nrows);

}


static PHP_METHOD(GtkSheet, insert_columns)
{
	long col, ncols;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &col, &ncols))
		return;

    gtk_sheet_insert_columns(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)col, (guint)ncols);

}


static PHP_METHOD(GtkSheet, delete_rows)
{
	long row, nrows;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &nrows))
		return;

    gtk_sheet_delete_rows(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)row, (guint)nrows);

}


static PHP_METHOD(GtkSheet, delete_columns)
{
	long col, ncols;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &col, &ncols))
		return;

    gtk_sheet_delete_columns(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (guint)col, (guint)ncols);

}


static PHP_METHOD(GtkSheet, range_set_background)
{
	GtkSheetRange *range = NULL;
	zval *php_range, *php_color;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_range, gboxed_ce, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_background(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, color);

}


static PHP_METHOD(GtkSheet, range_set_foreground)
{
	GtkSheetRange *range = NULL;
	zval *php_range, *php_color;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_range, gboxed_ce, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_foreground(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, color);

}


static PHP_METHOD(GtkSheet, range_set_justification)
{
	GtkSheetRange *range = NULL;
	zval *php_range, *php_justification = NULL;
	GtkJustification justification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OV", &php_range, gboxed_ce, &php_justification))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_sheet_range_set_justification(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, justification);

}


static PHP_METHOD(GtkSheet, column_set_justification)
{
	long column;
	GtkJustification justification;
	zval *php_justification = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "iV", &column, &php_justification))
		return;

	if (php_justification && phpg_gvalue_get_enum(GTK_TYPE_JUSTIFICATION, php_justification, (gint *)&justification) == FAILURE) {
		return;
	}

    gtk_sheet_column_set_justification(GTK_SHEET(PHPG_GOBJECT(this_ptr)), (gint)column, justification);

}


static PHP_METHOD(GtkSheet, range_set_editable)
{
	GtkSheetRange *range = NULL;
	zval *php_range;
	long editable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oi", &php_range, gboxed_ce, &editable))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_editable(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, (gint)editable);

}


static PHP_METHOD(GtkSheet, range_set_visible)
{
	GtkSheetRange *range = NULL;
	zval *php_range;
	zend_bool visible;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Ob", &php_range, gboxed_ce, &visible))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_visible(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, (gboolean)visible);

}


static PHP_METHOD(GtkSheet, range_set_border)
{
	GtkSheetRange *range = NULL;
	zval *php_range;
	long mask, width, line_style = GDK_LINE_SOLID;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Nii|i", &php_range, gboxed_ce, &mask, &width, &line_style))
		return;

    if (Z_TYPE_P(php_range) != IS_NULL) {
        if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
            range = (GtkSheetRange *) PHPG_GBOXED(php_range);
        } else {
            php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    gtk_sheet_range_set_border(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, (gint)mask, (guint)width, (gint)line_style);

}


static PHP_METHOD(GtkSheet, range_set_border_color)
{
	GtkSheetRange *range = NULL;
	zval *php_range, *php_color;
	GdkColor *color = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_range, gboxed_ce, &php_color, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_color, GDK_TYPE_COLOR, FALSE TSRMLS_CC)) {
        color = (GdkColor *) PHPG_GBOXED(php_color);
    } else {
        php_error(E_WARNING, "%s::%s() expects color argument to be a valid GdkColor object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_border_color(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, color);

}


static PHP_METHOD(GtkSheet, range_set_font)
{
	GtkSheetRange *range = NULL;
	zval *php_range, *php_font;
	PangoFontDescription *font = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_range, gboxed_ce, &php_font, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_range, GTK_TYPE_SHEET_RANGE, FALSE TSRMLS_CC)) {
        range = (GtkSheetRange *) PHPG_GBOXED(php_range);
    } else {
        php_error(E_WARNING, "%s::%s() expects range argument to be a valid GtkSheetRange object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    if (phpg_gboxed_check(php_font, PANGO_TYPE_FONT_DESCRIPTION, FALSE TSRMLS_CC)) {
        font = (PangoFontDescription *) PHPG_GBOXED(php_font);
    } else {
        php_error(E_WARNING, "%s::%s() expects font argument to be a valid PangoFontDescription object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_sheet_range_set_font(GTK_SHEET(PHPG_GOBJECT(this_ptr)), range, font);

}


static PHP_METHOD(GtkSheet, attach_floating)
{
	zval *widget;
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oii", &widget, gtkwidget_ce, &row, &col))
		return;

    gtk_sheet_attach_floating(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)), (gint)row, (gint)col);

}


static PHP_METHOD(GtkSheet, attach_default)
{
	zval *widget;
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oii", &widget, gtkwidget_ce, &row, &col))
		return;

    gtk_sheet_attach_default(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)), (gint)row, (gint)col);

}


static PHP_METHOD(GtkSheet, attach)
{
	zval *widget;
	long row, col, xoptions, yoptions, xpadding, ypadding;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oiiiiii", &widget, gtkwidget_ce, &row, &col, &xoptions, &yoptions, &xpadding, &ypadding))
		return;

    gtk_sheet_attach(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)), (gint)row, (gint)col, (gint)xoptions, (gint)yoptions, (gint)xpadding, (gint)ypadding);

}


static PHP_METHOD(GtkSheet, move_child)
{
	zval *widget;
	long x, y;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oii", &widget, gtkwidget_ce, &x, &y))
		return;

    gtk_sheet_move_child(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)), (gint)x, (gint)y);

}


static PHP_METHOD(GtkSheet, button_attach)
{
	zval *widget;
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Oii", &widget, gtkwidget_ce, &row, &col))
		return;

    gtk_sheet_button_attach(GTK_SHEET(PHPG_GOBJECT(this_ptr)), GTK_WIDGET(PHPG_GOBJECT(widget)), (gint)row, (gint)col);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_gtk_sheet_new, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_gtk_sheet_new_browser, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_gtk_sheet_new_with_custom_entry, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
    ZEND_ARG_INFO(0, entry_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_construct, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_construct_browser, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_construct_with_custom_entry, 0)
    ZEND_ARG_INFO(0, rows)
    ZEND_ARG_INFO(0, columns)
    ZEND_ARG_INFO(0, title)
    ZEND_ARG_INFO(0, entry_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_hadjustment, 0)
    ZEND_ARG_OBJ_INFO(0, adjustment, GtkAdjustment, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_vadjustment, 0)
    ZEND_ARG_OBJ_INFO(0, adjustment, GtkAdjustment, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_change_entry, 0)
    ZEND_ARG_INFO(0, entry_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_get_visible_range, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_selection_mode, 0)
    ZEND_ARG_INFO(0, mode)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_autoresize, 0)
    ZEND_ARG_INFO(0, autoresize)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_autoscroll, 0)
    ZEND_ARG_INFO(0, autoscroll)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_clip_text, 0)
    ZEND_ARG_INFO(0, clip_text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_justify_entry, 0)
    ZEND_ARG_INFO(0, justify)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_locked, 0)
    ZEND_ARG_INFO(0, lock)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_title, 0)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_background, 0)
    ZEND_ARG_OBJ_INFO(0, bg_color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_grid, 0)
    ZEND_ARG_OBJ_INFO(0, grid_color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_show_grid, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_column_title, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_get_column_title, 0)
    ZEND_ARG_INFO(0, column)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_row_title, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_get_row_title, 0)
    ZEND_ARG_INFO(0, row)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_button_add_label, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_button_add_label, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, label)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_button_get_label, 0)
    ZEND_ARG_INFO(0, row)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_button_get_label, 0)
    ZEND_ARG_INFO(0, column)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_button_justify, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_button_justify, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_moveto, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, row_align)
    ZEND_ARG_INFO(0, col_align)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_row_titles_width, 0)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_column_titles_height, 0)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_set_sensitivity, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, sensitive)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_columns_set_sensitivity, 0)
    ZEND_ARG_INFO(0, sensitive)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_columns_set_resizable, 0)
    ZEND_ARG_INFO(0, resizable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_set_sensitivity, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, sensitive)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_rows_set_sensitivity, 0)
    ZEND_ARG_INFO(0, sensitive)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_rows_set_resizable, 0)
    ZEND_ARG_INFO(0, resizable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_set_visibility, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_label_set_visibility, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_columns_labels_set_visibility, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_set_visibility, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_row_label_set_visibility, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_rows_labels_set_visibility, 0)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_select_row, 0)
    ZEND_ARG_INFO(0, row)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_select_column, 0)
    ZEND_ARG_INFO(0, column)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_clip_range, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_select_range, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_active_cell, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, column)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_cell, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
    ZEND_ARG_INFO(0, justification)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_cell_text, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
    ZEND_ARG_INFO(0, text)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_cell_get_text, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_cell_clear, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_cell_delete, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_clear, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_delete, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_cell_get_state, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_remove_link, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_get_cell_area, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_OBJ_INFO(0, area, GdkRectangle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_column_width, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_set_row_height, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_add_column, 0)
    ZEND_ARG_INFO(0, ncols)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_add_row, 0)
    ZEND_ARG_INFO(0, nrows)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_insert_rows, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, nrows)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_insert_columns, 0)
    ZEND_ARG_INFO(0, col)
    ZEND_ARG_INFO(0, ncols)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_delete_rows, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, nrows)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_delete_columns, 0)
    ZEND_ARG_INFO(0, col)
    ZEND_ARG_INFO(0, ncols)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_background, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_foreground, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_justification, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_column_set_justification, 0)
    ZEND_ARG_INFO(0, column)
    ZEND_ARG_INFO(0, justification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_editable, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_INFO(0, editable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_visible, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_INFO(0, visible)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtksheet_range_set_border, 0, 0, 3)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_INFO(0, mask)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, line_style)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_border_color, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_OBJ_INFO(0, color, GdkColor, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_range_set_font, 0)
    ZEND_ARG_OBJ_INFO(0, range, GtkSheetRange, 1)
    ZEND_ARG_OBJ_INFO(0, font, PangoFontDescription, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_attach_floating, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_attach_default, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_attach, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
    ZEND_ARG_INFO(0, xoptions)
    ZEND_ARG_INFO(0, yoptions)
    ZEND_ARG_INFO(0, xpadding)
    ZEND_ARG_INFO(0, ypadding)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_move_child, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksheet_button_attach, 0)
    ZEND_ARG_OBJ_INFO(0, widget, GtkWidget, 1)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static function_entry gtksheet_methods[] = {
	PHP_ME(GtkSheet, __construct,          arginfo_gtk_gtksheet_gtk_sheet_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, new_browser,          arginfo_gtk_gtksheet_gtk_sheet_new_browser, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkSheet, new_with_custom_entry, arginfo_gtk_gtksheet_gtk_sheet_new_with_custom_entry, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkSheet, add_column,           arginfo_gtk_gtksheet_add_column, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, add_row,              arginfo_gtk_gtksheet_add_row, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, attach,               arginfo_gtk_gtksheet_attach, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, attach_default,       arginfo_gtk_gtksheet_attach_default, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, attach_floating,      arginfo_gtk_gtksheet_attach_floating, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, autoresize,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, autoscroll,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, button_attach,        arginfo_gtk_gtksheet_button_attach, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, cell_clear,           arginfo_gtk_gtksheet_cell_clear, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, cell_delete,          arginfo_gtk_gtksheet_cell_delete, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, cell_get_state,       arginfo_gtk_gtksheet_cell_get_state, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, cell_get_text,        arginfo_gtk_gtksheet_cell_get_text, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, change_entry,         arginfo_gtk_gtksheet_change_entry, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, clip_range,           arginfo_gtk_gtksheet_clip_range, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, clip_text,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_button_add_label, arginfo_gtk_gtksheet_column_button_add_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_button_get_label, arginfo_gtk_gtksheet_column_button_get_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_button_justify, arginfo_gtk_gtksheet_column_button_justify, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_label_set_visibility, arginfo_gtk_gtksheet_column_label_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_set_justification, arginfo_gtk_gtksheet_column_set_justification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_set_sensitivity, arginfo_gtk_gtksheet_column_set_sensitivity, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_set_visibility, arginfo_gtk_gtksheet_column_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, column_titles_visible, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, columns_labels_set_visibility, arginfo_gtk_gtksheet_columns_labels_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, columns_resizable,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, columns_set_resizable, arginfo_gtk_gtksheet_columns_set_resizable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, columns_set_sensitivity, arginfo_gtk_gtksheet_columns_set_sensitivity, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, construct,            arginfo_gtk_gtksheet_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, construct_browser,    arginfo_gtk_gtksheet_construct_browser, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, construct_with_custom_entry, arginfo_gtk_gtksheet_construct_with_custom_entry, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, delete_columns,       arginfo_gtk_gtksheet_delete_columns, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, delete_rows,          arginfo_gtk_gtksheet_delete_rows, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, freeze,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_active_cell,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_cell_area,        arginfo_gtk_gtksheet_get_cell_area, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_column_title,     arginfo_gtk_gtksheet_get_column_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_columns_count,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_entry,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_entry_widget,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_hadjustment,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_row_title,        arginfo_gtk_gtksheet_get_row_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_rows_count,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_state,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_vadjustment,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, get_visible_range,    arginfo_gtk_gtksheet_get_visible_range, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, grid_visible,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, hide_column_titles,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, hide_row_titles,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, in_clip,              NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, insert_columns,       arginfo_gtk_gtksheet_insert_columns, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, insert_rows,          arginfo_gtk_gtksheet_insert_rows, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, justify_entry,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, locked,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, move_child,           arginfo_gtk_gtksheet_move_child, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, moveto,               arginfo_gtk_gtksheet_moveto, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_clear,          arginfo_gtk_gtksheet_range_clear, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_delete,         arginfo_gtk_gtksheet_range_delete, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_background, arginfo_gtk_gtksheet_range_set_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_border,     arginfo_gtk_gtksheet_range_set_border, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_border_color, arginfo_gtk_gtksheet_range_set_border_color, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_editable,   arginfo_gtk_gtksheet_range_set_editable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_font,       arginfo_gtk_gtksheet_range_set_font, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_foreground, arginfo_gtk_gtksheet_range_set_foreground, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_justification, arginfo_gtk_gtksheet_range_set_justification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, range_set_visible,    arginfo_gtk_gtksheet_range_set_visible, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, remove_link,          arginfo_gtk_gtksheet_remove_link, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_button_add_label, arginfo_gtk_gtksheet_row_button_add_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_button_get_label, arginfo_gtk_gtksheet_row_button_get_label, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_button_justify,   arginfo_gtk_gtksheet_row_button_justify, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_label_set_visibility, arginfo_gtk_gtksheet_row_label_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_set_sensitivity,  arginfo_gtk_gtksheet_row_set_sensitivity, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_set_visibility,   arginfo_gtk_gtksheet_row_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, row_titles_visible,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, rows_labels_set_visibility, arginfo_gtk_gtksheet_rows_labels_set_visibility, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, rows_resizable,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, rows_set_resizable,   arginfo_gtk_gtksheet_rows_set_resizable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, rows_set_sensitivity, arginfo_gtk_gtksheet_rows_set_sensitivity, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, select_column,        arginfo_gtk_gtksheet_select_column, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, select_range,         arginfo_gtk_gtksheet_select_range, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, select_row,           arginfo_gtk_gtksheet_select_row, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_active_cell,      arginfo_gtk_gtksheet_set_active_cell, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_autoresize,       arginfo_gtk_gtksheet_set_autoresize, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_autoscroll,       arginfo_gtk_gtksheet_set_autoscroll, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_background,       arginfo_gtk_gtksheet_set_background, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_cell,             arginfo_gtk_gtksheet_set_cell, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_cell_text,        arginfo_gtk_gtksheet_set_cell_text, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_clip_text,        arginfo_gtk_gtksheet_set_clip_text, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_column_title,     arginfo_gtk_gtksheet_set_column_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_column_titles_height, arginfo_gtk_gtksheet_set_column_titles_height, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_column_width,     arginfo_gtk_gtksheet_set_column_width, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_grid,             arginfo_gtk_gtksheet_set_grid, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_hadjustment,      arginfo_gtk_gtksheet_set_hadjustment, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_justify_entry,    arginfo_gtk_gtksheet_set_justify_entry, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_locked,           arginfo_gtk_gtksheet_set_locked, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_row_height,       arginfo_gtk_gtksheet_set_row_height, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_row_title,        arginfo_gtk_gtksheet_set_row_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_row_titles_width, arginfo_gtk_gtksheet_set_row_titles_width, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_selection_mode,   arginfo_gtk_gtksheet_set_selection_mode, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_title,            arginfo_gtk_gtksheet_set_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, set_vadjustment,      arginfo_gtk_gtksheet_set_vadjustment, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, show_column_titles,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, show_grid,            arginfo_gtk_gtksheet_show_grid, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, show_row_titles,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, thaw,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, unclip_range,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSheet, unselect_range,       NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkToggleCombo, __construct)
{
	long nrows, ncols;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &nrows, &ncols)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkToggleCombo);
	}

	wrapped_obj = (GObject *) gtk_toggle_combo_new((gint)nrows, (gint)ncols);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkToggleCombo);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkToggleCombo, construct)
{
	long nrows, ncols;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &nrows, &ncols))
		return;

    gtk_toggle_combo_construct(GTK_TOGGLE_COMBO(PHPG_GOBJECT(this_ptr)), (gint)nrows, (gint)ncols);

}


static PHP_METHOD(GtkToggleCombo, get_nrows)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_toggle_combo_get_nrows(GTK_TOGGLE_COMBO(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkToggleCombo, get_ncols)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_toggle_combo_get_ncols(GTK_TOGGLE_COMBO(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkToggleCombo, select)
{
	long row, col;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &row, &col))
		return;

    gtk_toggle_combo_select(GTK_TOGGLE_COMBO(PHPG_GOBJECT(this_ptr)), (gint)row, (gint)col);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtktogglecombo_gtk_toggle_combo_new, 0)
    ZEND_ARG_INFO(0, nrows)
    ZEND_ARG_INFO(0, ncols)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtktogglecombo_construct, 0)
    ZEND_ARG_INFO(0, nrows)
    ZEND_ARG_INFO(0, ncols)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtktogglecombo_select, 0)
    ZEND_ARG_INFO(0, row)
    ZEND_ARG_INFO(0, col)
ZEND_END_ARG_INFO();

static function_entry gtktogglecombo_methods[] = {
	PHP_ME(GtkToggleCombo, __construct,          arginfo_gtk_gtktogglecombo_gtk_toggle_combo_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkToggleCombo, construct,            arginfo_gtk_gtktogglecombo_construct, ZEND_ACC_PUBLIC)
	PHP_ME(GtkToggleCombo, get_ncols,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkToggleCombo, get_nrows,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkToggleCombo, select,               arginfo_gtk_gtktogglecombo_select, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

PHPG_PROP_READER(GtkIconListItem, x)
{
	long php_retval;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->x;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, y)
{
	long php_retval;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->y;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, state)
{
	long php_retval;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->state;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, entry_label)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->entry_label;
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, label)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->label;
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, pixmap)
{
	GtkWidget* php_retval;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->pixmap;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


PHPG_PROP_READER(GtkIconListItem, entry)
{
	GtkWidget* php_retval;

    php_retval = ((GtkIconListItem *)((phpg_gboxed_t *)object)->boxed)->entry;
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
    return SUCCESS;
}


static prop_info_t gtkiconlistitem_prop_info[] = {
	{ "x", PHPG_PROP_READ_FN(GtkIconListItem, x), NULL },
	{ "y", PHPG_PROP_READ_FN(GtkIconListItem, y), NULL },
	{ "state", PHPG_PROP_READ_FN(GtkIconListItem, state), NULL },
	{ "entry_label", PHPG_PROP_READ_FN(GtkIconListItem, entry_label), NULL },
	{ "label", PHPG_PROP_READ_FN(GtkIconListItem, label), NULL },
	{ "pixmap", PHPG_PROP_READ_FN(GtkIconListItem, pixmap), NULL },
	{ "entry", PHPG_PROP_READ_FN(GtkIconListItem, entry), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkIconListItem, get_entry)
{
	GtkWidget* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_entry((GtkIconListItem *)PHPG_GBOXED(this_ptr));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkIconListItem, get_pixmap)
{
	GtkWidget* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_icon_list_get_pixmap((GtkIconListItem *)PHPG_GBOXED(this_ptr));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkIconListItem, set_pixmap)
{
	zval *pixmap, *bitmap;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &pixmap, gdkpixmap_ce, &bitmap, gdkpixmap_ce))
		return;

    gtk_icon_list_set_pixmap((GtkIconListItem *)PHPG_GBOXED(this_ptr), GDK_PIXMAP(PHPG_GOBJECT(pixmap)), GDK_PIXMAP(PHPG_GOBJECT(bitmap)));

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkiconlistitem_set_pixmap, 0)
    ZEND_ARG_OBJ_INFO(0, pixmap, GdkPixmap, 1)
    ZEND_ARG_INFO(0, bitmap)
ZEND_END_ARG_INFO();

static function_entry gtkiconlistitem_methods[] = {
#if ZEND_EXTENSION_API_NO > 220051025
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL, 0)
#else
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL)
#endif
	PHP_ME(GtkIconListItem, get_entry,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconListItem, get_pixmap,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkIconListItem, set_pixmap,           arginfo_gtk_gtkiconlistitem_set_pixmap, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSheetRange, __construct)
{
	long row0 = 0, col0 = 0, rowi = 0, coli = 0;

    phpg_gboxed_t *pobj = NULL;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|iiii", &row0, &col0, &rowi, &coli)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheetRange);
	}

    pobj = zend_object_store_get_object(this_ptr TSRMLS_CC);
    pobj->gtype = GTK_TYPE_SHEET_RANGE;
    pobj->boxed = gtk_sheet_range_new((gint)row0, (gint)col0, (gint)rowi, (gint)coli);

	if (!pobj->boxed) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSheetRange);
	}
    pobj->free_on_destroy = TRUE;
}


PHPG_PROP_READER(GtkSheetRange, row0)
{
	long php_retval;

    php_retval = ((GtkSheetRange *)((phpg_gboxed_t *)object)->boxed)->row0;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSheetRange, col0)
{
	long php_retval;

    php_retval = ((GtkSheetRange *)((phpg_gboxed_t *)object)->boxed)->col0;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSheetRange, rowi)
{
	long php_retval;

    php_retval = ((GtkSheetRange *)((phpg_gboxed_t *)object)->boxed)->rowi;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSheetRange, coli)
{
	long php_retval;

    php_retval = ((GtkSheetRange *)((phpg_gboxed_t *)object)->boxed)->coli;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


static prop_info_t gtksheetrange_prop_info[] = {
	{ "row0", PHPG_PROP_READ_FN(GtkSheetRange, row0), NULL },
	{ "col0", PHPG_PROP_READ_FN(GtkSheetRange, col0), NULL },
	{ "rowi", PHPG_PROP_READ_FN(GtkSheetRange, rowi), NULL },
	{ "coli", PHPG_PROP_READ_FN(GtkSheetRange, coli), NULL },
	{ NULL, NULL, NULL },
};


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtksheetrange_gtk_sheet_range_new, 0, 0, 0)
    ZEND_ARG_INFO(0, row0)
    ZEND_ARG_INFO(0, col0)
    ZEND_ARG_INFO(0, rowi)
    ZEND_ARG_INFO(0, coli)
ZEND_END_ARG_INFO();

static function_entry gtksheetrange_methods[] = {
	PHP_ME(GtkSheetRange, __construct,          arginfo_gtk_gtksheetrange_gtk_sheet_range_new, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

PHPG_PROP_READER(GtkPlotDTnode, x)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->x;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, y)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->y;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, z)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->z;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, px)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->px;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, py)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->py;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, pz)
{
	double php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->pz;
	RETVAL_DOUBLE(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, id)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->id;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, a)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->a;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, b)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->b;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, c)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->c;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, d)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->d;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkPlotDTnode, boundary_marker)
{
	long php_retval;

    php_retval = ((GtkPlotDTnode *)((phpg_gboxed_t *)object)->boxed)->boundary_marker;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


static prop_info_t gtkplotdtnode_prop_info[] = {
	{ "x", PHPG_PROP_READ_FN(GtkPlotDTnode, x), NULL },
	{ "y", PHPG_PROP_READ_FN(GtkPlotDTnode, y), NULL },
	{ "z", PHPG_PROP_READ_FN(GtkPlotDTnode, z), NULL },
	{ "px", PHPG_PROP_READ_FN(GtkPlotDTnode, px), NULL },
	{ "py", PHPG_PROP_READ_FN(GtkPlotDTnode, py), NULL },
	{ "pz", PHPG_PROP_READ_FN(GtkPlotDTnode, pz), NULL },
	{ "id", PHPG_PROP_READ_FN(GtkPlotDTnode, id), NULL },
	{ "a", PHPG_PROP_READ_FN(GtkPlotDTnode, a), NULL },
	{ "b", PHPG_PROP_READ_FN(GtkPlotDTnode, b), NULL },
	{ "c", PHPG_PROP_READ_FN(GtkPlotDTnode, c), NULL },
	{ "d", PHPG_PROP_READ_FN(GtkPlotDTnode, d), NULL },
	{ "boundary_marker", PHPG_PROP_READ_FN(GtkPlotDTnode, boundary_marker), NULL },
	{ NULL, NULL, NULL },
};


static function_entry gtkplotdtnode_methods[] = {
#if ZEND_EXTENSION_API_NO > 220051025
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL, 0)
#else
	PHP_ME_MAPPING(__construct, no_direct_constructor, NULL)
#endif
	{ NULL, NULL, NULL }
};

void phpg_gtkextra_register_classes(void)
{
	TSRMLS_FETCH();

	gtkextra_ce = phpg_register_class("GtkExtra", gtkextra_methods, NULL, 0, NULL, NULL, 0 TSRMLS_CC);

	gtkcharselection_ce = phpg_register_class("GtkCharSelection", gtkcharselection_methods, gtkwindow_ce, 0, gtkcharselection_prop_info, NULL, GTK_TYPE_CHAR_SELECTION TSRMLS_CC);

	gtkcheckitem_ce = phpg_register_class("GtkCheckItem", gtkcheckitem_methods, gtktogglebutton_ce, 0, NULL, NULL, GTK_TYPE_CHECK_ITEM TSRMLS_CC);

	gtkcombobutton_ce = phpg_register_class("GtkComboButton", NULL, gtkhbox_ce, 0, gtkcombobutton_prop_info, NULL, GTK_TYPE_COMBO_BUTTON TSRMLS_CC);

	gtkcolorcombo_ce = phpg_register_class("GtkColorCombo", gtkcolorcombo_methods, gtkcombobutton_ce, 0, NULL, NULL, GTK_TYPE_COLOR_COMBO TSRMLS_CC);

	gtkbordercombo_ce = phpg_register_class("GtkBorderCombo", gtkbordercombo_methods, gtkcombobutton_ce, 0, gtkbordercombo_prop_info, NULL, GTK_TYPE_BORDER_COMBO TSRMLS_CC);

	gtkdirtree_ce = phpg_register_class("GtkDirTree", gtkdirtree_methods, gtkctree_ce, 0, gtkdirtree_prop_info, NULL, GTK_TYPE_DIR_TREE TSRMLS_CC);

	gtkfontcombo_ce = phpg_register_class("GtkFontCombo", gtkfontcombo_methods, gtktoolbar_ce, 0, gtkfontcombo_prop_info, NULL, GTK_TYPE_FONT_COMBO TSRMLS_CC);

	gtkiconfilesel_ce = phpg_register_class("GtkIconFileSelection", NULL, gtkwindow_ce, 0, gtkiconfilesel_prop_info, NULL, GTK_TYPE_ICON_FILE_SEL TSRMLS_CC);

	gtkiconlist_ce = phpg_register_class("GtkIconList", gtkiconlist_methods, gtkfixed_ce, 0, gtkiconlist_prop_info, NULL, GTK_TYPE_ICON_LIST TSRMLS_CC);

	gtkfilelist_ce = phpg_register_class("GtkFileList", gtkfilelist_methods, gtkiconlist_ce, 0, NULL, NULL, GTK_TYPE_FILE_LIST TSRMLS_CC);

	gtkitementry_ce = phpg_register_class("GtkItemEntry", gtkitementry_methods, gtkentry_ce, 0, NULL, NULL, GTK_TYPE_ITEM_ENTRY TSRMLS_CC);

	gtkplotcanvas_ce = phpg_register_class("GtkPlotCanvas", gtkplotcanvas_methods, gtkfixed_ce, 0, gtkplotcanvas_prop_info, NULL, GTK_TYPE_PLOT_CANVAS TSRMLS_CC);

	gtkplot_ce = phpg_register_class("GtkPlot", gtkplot_methods, gtkwidget_ce, 0, NULL, NULL, GTK_TYPE_PLOT TSRMLS_CC);

	gtkplotarray_ce = phpg_register_class("GtkPlotArray", gtkplotarray_methods, gobject_ce, 0, NULL, NULL, GTK_TYPE_PLOT_ARRAY TSRMLS_CC);

	gtkplotarraylist_ce = phpg_register_class("GtkPlotArrayList", gtkplotarraylist_methods, gobject_ce, 0, NULL, NULL, GTK_TYPE_PLOT_ARRAY_LIST TSRMLS_CC);

	gtkplotaxis_ce = phpg_register_class("GtkPlotAxis", gtkplotaxis_methods, gtkobject_ce, 0, gtkplotaxis_prop_info, NULL, GTK_TYPE_PLOT_AXIS TSRMLS_CC);

	gtkplotcanvaschild_ce = phpg_register_class("GtkPlotCanvasChild", gtkplotcanvaschild_methods, gtkobject_ce, 0, gtkplotcanvaschild_prop_info, NULL, GTK_TYPE_PLOT_CANVAS_CHILD TSRMLS_CC);

	gtkplotcanvasellipse_ce = phpg_register_class("GtkPlotCanvasEllipse", gtkplotcanvasellipse_methods, gtkplotcanvaschild_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANVAS_ELLIPSE TSRMLS_CC);

	gtkplotcanvasline_ce = phpg_register_class("GtkPlotCanvasLine", gtkplotcanvasline_methods, gtkplotcanvaschild_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANVAS_LINE TSRMLS_CC);

	gtkplotcanvaspixmap_ce = phpg_register_class("GtkPlotCanvasPixmap", gtkplotcanvaspixmap_methods, gtkplotcanvaschild_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANVAS_PIXMAP TSRMLS_CC);

	gtkplotcanvasplot_ce = phpg_register_class("GtkPlotCanvasPlot", gtkplotcanvasplot_methods, gtkplotcanvaschild_ce, 0, gtkplotcanvasplot_prop_info, NULL, GTK_TYPE_PLOT_CANVAS_PLOT TSRMLS_CC);

	gtkplotcanvasrectangle_ce = phpg_register_class("GtkPlotCanvasRectangle", gtkplotcanvasrectangle_methods, gtkplotcanvaschild_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANVAS_RECTANGLE TSRMLS_CC);

	gtkplotcanvastext_ce = phpg_register_class("GtkPlotCanvasText", gtkplotcanvastext_methods, gtkplotcanvaschild_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANVAS_TEXT TSRMLS_CC);

	gtkplot3d_ce = phpg_register_class("GtkPlot3D", gtkplot3d_methods, gtkplot_ce, 0, NULL, NULL, GTK_TYPE_PLOT3_D TSRMLS_CC);

	gtkplotdt_ce = phpg_register_class("GtkPlotDT", gtkplotdt_methods, gtkobject_ce, 0, NULL, NULL, GTK_TYPE_PLOT_DT TSRMLS_CC);

	gtkplotdata_ce = phpg_register_class("GtkPlotData", gtkplotdata_methods, gtkwidget_ce, 0, NULL, NULL, GTK_TYPE_PLOT_DATA TSRMLS_CC);

	gtkplotcandle_ce = phpg_register_class("GtkPlotCandle", gtkplotcandle_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CANDLE TSRMLS_CC);

	gtkplotbubble_ce = phpg_register_class("GtkPlotBubble", NULL, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_BUBBLE TSRMLS_CC);

	gtkplotbox_ce = phpg_register_class("GtkPlotBox", gtkplotbox_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_BOX TSRMLS_CC);

	gtkplotbar_ce = phpg_register_class("GtkPlotBar", gtkplotbar_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_BAR TSRMLS_CC);

	gtkplotflux_ce = phpg_register_class("GtkPlotFlux", gtkplotflux_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_FLUX TSRMLS_CC);

	gtkplotpc_ce = phpg_register_class("GtkPlotPC", gtkplotpc_methods, gtkobject_ce, 0, NULL, NULL, GTK_TYPE_PLOT_PC TSRMLS_CC);

	gtkplotgdk_ce = phpg_register_class("GtkPlotGdk", gtkplotgdk_methods, gtkplotpc_ce, 0, NULL, NULL, GTK_TYPE_PLOT_GDK TSRMLS_CC);

	gtkplotps_ce = phpg_register_class("GtkPlotPS", gtkplotps_methods, gtkplotpc_ce, 0, NULL, NULL, GTK_TYPE_PLOT_PS TSRMLS_CC);

	gtkplotpixmap_ce = phpg_register_class("GtkPlotPixmap", gtkplotpixmap_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_PIXMAP TSRMLS_CC);

	gtkplotpolar_ce = phpg_register_class("GtkPlotPolar", gtkplotpolar_methods, gtkplot_ce, 0, NULL, NULL, GTK_TYPE_PLOT_POLAR TSRMLS_CC);

	gtkplotsurface_ce = phpg_register_class("GtkPlotSurface", gtkplotsurface_methods, gtkplotdata_ce, 0, NULL, NULL, GTK_TYPE_PLOT_SURFACE TSRMLS_CC);

	gtkplotcsurface_ce = phpg_register_class("GtkPlotCSurface", gtkplotcsurface_methods, gtkplotsurface_ce, 0, NULL, NULL, GTK_TYPE_PLOT_CSURFACE TSRMLS_CC);

	gtksheet_ce = phpg_register_class("GtkSheet", gtksheet_methods, gtkcontainer_ce, 0, NULL, NULL, GTK_TYPE_SHEET TSRMLS_CC);

	gtktogglecombo_ce = phpg_register_class("GtkToggleCombo", gtktogglecombo_methods, gtkcombobutton_ce, 0, NULL, NULL, GTK_TYPE_TOGGLE_COMBO TSRMLS_CC);

    gtkiconlistitem_ce = phpg_register_boxed("GtkIconListItem", gtkiconlistitem_methods, gtkiconlistitem_prop_info, NULL, GTK_TYPE_ICON_LIST_ITEM TSRMLS_CC);

    gtksheetrange_ce = phpg_register_boxed("GtkSheetRange", gtksheetrange_methods, gtksheetrange_prop_info, NULL, GTK_TYPE_SHEET_RANGE TSRMLS_CC);

    gtkplotdtnode_ce = phpg_register_boxed("GtkPlotDTnode", gtkplotdtnode_methods, gtkplotdtnode_prop_info, NULL, GTK_TYPE_PLOT_DT_NODE TSRMLS_CC);
}

void phpg_gtkextra_register_constants(const char *strip_prefix)
{
    TSRMLS_FETCH();
	phpg_register_enum(GTK_TYPE_ICON_LIST_MODE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_PLANE, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_SIDE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_BAR_UNITS, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CANVAS_ACTION, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_CANVAS_FLAG, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CANVAS_SELECTION, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CANVAS_SELECTION_MODE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CANVAS_POS, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_CANVAS_ARROW, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CANVAS_PLOT_POS, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_PROJECTION, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_SCALE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_SYMBOL_TYPE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_SYMBOL_STYLE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_BORDER_STYLE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_LINE_STYLE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_CONNECTOR, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_LABEL_POS, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_ERROR, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_ORIENTATION, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_AXIS_POS, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_LABEL_STYLE, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_TICKS_POS, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_PAGE_SIZE, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_PAGE_ORIENTATION, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_PLOT_UNITS, strip_prefix, gtkextra_ce);
	phpg_register_flags(GTK_TYPE_PLOT_ARROW, strip_prefix, gtkextra_ce);
	phpg_register_enum(GTK_TYPE_SHEET_ATTR_TYPE, strip_prefix, gtkextra_ce);


    /* register gtype constants for all classes */

	phpg_register_int_constant(gtkcharselection_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_CHAR_SELECTION);
	phpg_register_int_constant(gtkcheckitem_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_CHECK_ITEM);
	phpg_register_int_constant(gtkcombobutton_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_COMBO_BUTTON);
	phpg_register_int_constant(gtkcolorcombo_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_COLOR_COMBO);
	phpg_register_int_constant(gtkbordercombo_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_BORDER_COMBO);
	phpg_register_int_constant(gtkdirtree_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_DIR_TREE);
	phpg_register_int_constant(gtkfontcombo_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_FONT_COMBO);
	phpg_register_int_constant(gtkiconfilesel_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_ICON_FILE_SEL);
	phpg_register_int_constant(gtkiconlist_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_ICON_LIST);
	phpg_register_int_constant(gtkfilelist_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_FILE_LIST);
	phpg_register_int_constant(gtkitementry_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_ITEM_ENTRY);
	phpg_register_int_constant(gtkplotcanvas_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS);
	phpg_register_int_constant(gtkplot_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT);
	phpg_register_int_constant(gtkplotarray_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_ARRAY);
	phpg_register_int_constant(gtkplotarraylist_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_ARRAY_LIST);
	phpg_register_int_constant(gtkplotaxis_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_AXIS);
	phpg_register_int_constant(gtkplotcanvaschild_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_CHILD);
	phpg_register_int_constant(gtkplotcanvasellipse_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_ELLIPSE);
	phpg_register_int_constant(gtkplotcanvasline_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_LINE);
	phpg_register_int_constant(gtkplotcanvaspixmap_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_PIXMAP);
	phpg_register_int_constant(gtkplotcanvasplot_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_PLOT);
	phpg_register_int_constant(gtkplotcanvasrectangle_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_RECTANGLE);
	phpg_register_int_constant(gtkplotcanvastext_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANVAS_TEXT);
	phpg_register_int_constant(gtkplot3d_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT3_D);
	phpg_register_int_constant(gtkplotdt_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_DT);
	phpg_register_int_constant(gtkplotdata_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_DATA);
	phpg_register_int_constant(gtkplotcandle_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CANDLE);
	phpg_register_int_constant(gtkplotbubble_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_BUBBLE);
	phpg_register_int_constant(gtkplotbox_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_BOX);
	phpg_register_int_constant(gtkplotbar_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_BAR);
	phpg_register_int_constant(gtkplotflux_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_FLUX);
	phpg_register_int_constant(gtkplotpc_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_PC);
	phpg_register_int_constant(gtkplotgdk_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_GDK);
	phpg_register_int_constant(gtkplotps_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_PS);
	phpg_register_int_constant(gtkplotpixmap_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_PIXMAP);
	phpg_register_int_constant(gtkplotpolar_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_POLAR);
	phpg_register_int_constant(gtkplotsurface_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_SURFACE);
	phpg_register_int_constant(gtkplotcsurface_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_CSURFACE);
	phpg_register_int_constant(gtksheet_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SHEET);
	phpg_register_int_constant(gtktogglecombo_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_TOGGLE_COMBO);
	phpg_register_int_constant(gtkiconlistitem_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_ICON_LIST_ITEM);
	phpg_register_int_constant(gtksheetrange_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SHEET_RANGE);
	phpg_register_int_constant(gtkplotdtnode_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_PLOT_DT_NODE);

}

#endif /* HAVE_PHP_GTK */
