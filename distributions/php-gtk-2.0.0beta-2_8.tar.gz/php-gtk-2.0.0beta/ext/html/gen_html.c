#include "php_gtk.h"

#if HAVE_PHP_GTK
#include <gtkhtml/gtkhtml.h>
#include <gtkhtml/gtkhtml-embedded.h>
#include <gtkhtml/gtkhtml-search.h>
#include "ext/gtk+/php_gtk+.h"
#include "php_gtk_api.h"

PHP_GTK_EXPORT_CE(gtkhtml_ce);
PHP_GTK_EXPORT_CE(gtkhtmlembedded_ce);
PHP_GTK_EXPORT_CE(gtkhtml_ce);

static PHP_METHOD(GtkHTML, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkHTML);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkHTML);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkHTML, get_top_html)
{
	GtkHTML* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_top_html(GTK_HTML(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkHTML, enable_debug)
{
	zend_bool debug;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &debug))
		return;

    gtk_html_enable_debug(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)debug);

}


static PHP_METHOD(GtkHTML, allow_selection)
{
	zend_bool allow;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &allow))
		return;

    gtk_html_allow_selection(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)allow);

}


static PHP_METHOD(GtkHTML, select_word)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_select_word(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, select_line)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_select_line(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, select_paragraph)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_select_paragraph(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, select_paragraph_extended)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_select_paragraph_extended(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, select_all)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_select_all(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, request_paste)
{
	GdkAtom selection;
	zval *php_selection = NULL;
	long type, time, php_retval;
	zend_bool as_cite;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "Viib", &php_selection, &type, &time, &as_cite))
		return;

    selection = phpg_gdkatom_from_zval(php_selection TSRMLS_CC);
    if (selection == NULL) {
        php_error(E_WARNING, "%s::%s() expects selection argument to be a valid GdkAtom object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_html_request_paste(GTK_HTML(PHPG_GOBJECT(this_ptr)), selection, (gint)type, (gint32)time, (gboolean)as_cite);
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkHTML, flush)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_flush(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, stop)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_stop(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}

#line 15 "ext/html/html.overrides"
static PHP_METHOD(GtkHTML, load_from_string)
{
    char *text;

    NOT_STATIC_METHOD();

    if(!php_gtk_parse_args(ZEND_NUM_ARGS(), "s", &text)) {
        return;
    }

    gtk_html_load_from_string(GTK_HTML(PHPG_GOBJECT(this_ptr)), text, strlen(text));
}
#line 201 "ext/html/gen_html.c"



static PHP_METHOD(GtkHTML, set_editable)
{
	zend_bool editable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &editable))
		return;

    gtk_html_set_editable(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)editable);

}


static PHP_METHOD(GtkHTML, get_editable)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_editable(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_inline_spelling)
{
	zend_bool inline_spell;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &inline_spell))
		return;

    gtk_html_set_inline_spelling(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)inline_spell);

}


static PHP_METHOD(GtkHTML, get_inline_spelling)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_inline_spelling(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_magic_links)
{
	zend_bool magic_links;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &magic_links))
		return;

    gtk_html_set_magic_links(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)magic_links);

}


static PHP_METHOD(GtkHTML, get_magic_links)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_magic_links(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_magic_smileys)
{
	zend_bool magic_smileys;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &magic_smileys))
		return;

    gtk_html_set_magic_smileys(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)magic_smileys);

}


static PHP_METHOD(GtkHTML, get_magic_smileys)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_magic_smileys(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_caret_mode)
{
	zend_bool caret_mode;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &caret_mode))
		return;

    gtk_html_set_caret_mode(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)caret_mode);

}


static PHP_METHOD(GtkHTML, get_caret_mode)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_caret_mode(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_animate)
{
	zend_bool animate;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &animate))
		return;

    gtk_html_set_animate(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)animate);

}


static PHP_METHOD(GtkHTML, get_animate)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_animate(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_title)
{
	char *title;
	zend_bool free_title = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &title, &free_title))
		return;

    gtk_html_set_title(GTK_HTML(PHPG_GOBJECT(this_ptr)), title);
	if (free_title) g_free(title);

}


static PHP_METHOD(GtkHTML, jump_to_anchor)
{
	char *anchor;
	zend_bool free_anchor = FALSE;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &anchor, &free_anchor))
		return;

    php_retval = gtk_html_jump_to_anchor(GTK_HTML(PHPG_GOBJECT(this_ptr)), anchor);
	if (free_anchor) g_free(anchor);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, indent_push_level)
{
	HTMLListType level_type;
	zval *php_level_type = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "V", &php_level_type))
		return;

	if (php_level_type && phpg_gvalue_get_enum(G_TYPE_NONE, php_level_type, (gint *)&level_type) == FAILURE) {
		return;
	}

    gtk_html_indent_push_level(GTK_HTML(PHPG_GOBJECT(this_ptr)), level_type);

}


static PHP_METHOD(GtkHTML, indent_pop_level)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_indent_pop_level(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, get_paragraph_indentation)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_paragraph_indentation(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkHTML, cut)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_cut(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, copy)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_copy(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, paste)
{
	zend_bool as_cite;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &as_cite))
		return;

    gtk_html_paste(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)as_cite);

}


static PHP_METHOD(GtkHTML, undo)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_undo(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, redo)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_redo(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, insert_html)
{
	char *html_src;
	zend_bool free_html_src = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &html_src, &free_html_src))
		return;

    gtk_html_insert_html(GTK_HTML(PHPG_GOBJECT(this_ptr)), html_src);
	if (free_html_src) g_free(html_src);

}


static PHP_METHOD(GtkHTML, insert_gtk_html)
{
	zval *to_be_destroyed;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &to_be_destroyed, gtkhtml_ce))
		return;

    gtk_html_insert_gtk_html(GTK_HTML(PHPG_GOBJECT(this_ptr)), GTK_HTML(PHPG_GOBJECT(to_be_destroyed)));

}


static PHP_METHOD(GtkHTML, append_html)
{
	char *html_src;
	zend_bool free_html_src = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &html_src, &free_html_src))
		return;

    gtk_html_append_html(GTK_HTML(PHPG_GOBJECT(this_ptr)), html_src);
	if (free_html_src) g_free(html_src);

}


static PHP_METHOD(GtkHTML, command)
{
	char *command_name;
	zend_bool free_command_name = FALSE;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &command_name, &free_command_name))
		return;

    php_retval = gtk_html_command(GTK_HTML(PHPG_GOBJECT(this_ptr)), command_name);
	if (free_command_name) g_free(command_name);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, edit_make_cursor_visible)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_edit_make_cursor_visible(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_magnification)
{
	double magnification;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "d", &magnification))
		return;

    gtk_html_set_magnification(GTK_HTML(PHPG_GOBJECT(this_ptr)), magnification);

}


static PHP_METHOD(GtkHTML, zoom_in)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_zoom_in(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, zoom_out)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_zoom_out(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, zoom_reset)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_zoom_reset(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, update_styles)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_update_styles(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, set_allow_frameset)
{
	zend_bool allow;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &allow))
		return;

    gtk_html_set_allow_frameset(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)allow);

}


static PHP_METHOD(GtkHTML, get_allow_frameset)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_allow_frameset(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, set_base)
{
	char *url;
	zend_bool free_url = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    gtk_html_set_base(GTK_HTML(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);

}


static PHP_METHOD(GtkHTML, get_url_base_relative)
{
	char *url;
	zend_bool free_url = FALSE, free_result;
	gchar *php_retval, *cp_ret;
	gsize cp_len;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    php_retval = gtk_html_get_url_base_relative(GTK_HTML(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkHTML, images_ref)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_images_ref(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, images_unref)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_images_unref(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, image_ref)
{
	char *url;
	zend_bool free_url = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    gtk_html_image_ref(GTK_HTML(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);

}


static PHP_METHOD(GtkHTML, image_unref)
{
	char *url;
	zend_bool free_url = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    gtk_html_image_unref(GTK_HTML(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);

}


static PHP_METHOD(GtkHTML, image_preload)
{
	char *url;
	zend_bool free_url = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    gtk_html_image_preload(GTK_HTML(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);

}


static PHP_METHOD(GtkHTML, set_blocking)
{
	zend_bool block;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &block))
		return;

    gtk_html_set_blocking(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)block);

}


static PHP_METHOD(GtkHTML, set_images_blocking)
{
	zend_bool block;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &block))
		return;

    gtk_html_set_images_blocking(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)block);

}


static PHP_METHOD(GtkHTML, has_undo)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_has_undo(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, drop_undo)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_drop_undo(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, get_url_at)
{
	long x, y;
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ii", &x, &y))
		return;

    php_retval = gtk_html_get_url_at(GTK_HTML(PHPG_GOBJECT(this_ptr)), (int)x, (int)y);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkHTML, get_cursor_url)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_get_cursor_url(GTK_HTML(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkHTML, set_default_content_type)
{
	char *content_type;
	zend_bool free_content_type = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &content_type, &free_content_type))
		return;

    gtk_html_set_default_content_type(GTK_HTML(PHPG_GOBJECT(this_ptr)), content_type);
	if (free_content_type) g_free(content_type);

}


static PHP_METHOD(GtkHTML, load_empty)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_load_empty(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, drag_dest_set)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_html_drag_dest_set(GTK_HTML(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkHTML, engine_search)
{
	char *text;
	zend_bool free_text = FALSE, case_sensitive, forward, regular;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ubbb", &text, &free_text, &case_sensitive, &forward, &regular))
		return;

    php_retval = gtk_html_engine_search(GTK_HTML(PHPG_GOBJECT(this_ptr)), text, (gboolean)case_sensitive, (gboolean)forward, (gboolean)regular);
	if (free_text) g_free(text);
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, engine_search_set_forward)
{
	zend_bool forward;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &forward))
		return;

    gtk_html_engine_search_set_forward(GTK_HTML(PHPG_GOBJECT(this_ptr)), (gboolean)forward);

}


static PHP_METHOD(GtkHTML, engine_search_next)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_html_engine_search_next(GTK_HTML(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkHTML, engine_search_incremental)
{
	char *text;
	zend_bool free_text = FALSE, forward;
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ub", &text, &free_text, &forward))
		return;

    php_retval = gtk_html_engine_search_incremental(GTK_HTML(PHPG_GOBJECT(this_ptr)), text, (gboolean)forward);
	if (free_text) g_free(text);
	RETVAL_BOOL(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_enable_debug, 0)
    ZEND_ARG_INFO(0, debug)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_allow_selection, 0)
    ZEND_ARG_INFO(0, allow)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_request_paste, 0)
    ZEND_ARG_INFO(0, selection)
    ZEND_ARG_INFO(0, type)
    ZEND_ARG_INFO(0, time)
    ZEND_ARG_INFO(0, as_cite)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_editable, 0)
    ZEND_ARG_INFO(0, editable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_inline_spelling, 0)
    ZEND_ARG_INFO(0, inline_spell)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_magic_links, 0)
    ZEND_ARG_INFO(0, magic_links)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_magic_smileys, 0)
    ZEND_ARG_INFO(0, magic_smileys)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_caret_mode, 0)
    ZEND_ARG_INFO(0, caret_mode)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_animate, 0)
    ZEND_ARG_INFO(0, animate)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_title, 0)
    ZEND_ARG_INFO(0, title)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_jump_to_anchor, 0)
    ZEND_ARG_INFO(0, anchor)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_indent_push_level, 0)
    ZEND_ARG_OBJ_INFO(0, level_type, HTMLListType, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_paste, 0)
    ZEND_ARG_INFO(0, as_cite)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_insert_html, 0)
    ZEND_ARG_INFO(0, html_src)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_insert_gtk_html, 0)
    ZEND_ARG_OBJ_INFO(0, to_be_destroyed, GtkHTML, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_append_html, 0)
    ZEND_ARG_INFO(0, html_src)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_command, 0)
    ZEND_ARG_INFO(0, command_name)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_magnification, 0)
    ZEND_ARG_INFO(0, magnification)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_allow_frameset, 0)
    ZEND_ARG_INFO(0, allow)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_base, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_get_url_base_relative, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_image_ref, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_image_unref, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_image_preload, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_blocking, 0)
    ZEND_ARG_INFO(0, block)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_images_blocking, 0)
    ZEND_ARG_INFO(0, block)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_get_url_at, 0)
    ZEND_ARG_INFO(0, x)
    ZEND_ARG_INFO(0, y)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_set_default_content_type, 0)
    ZEND_ARG_INFO(0, content_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_engine_search, 0)
    ZEND_ARG_INFO(0, text)
    ZEND_ARG_INFO(0, case_sensitive)
    ZEND_ARG_INFO(0, forward)
    ZEND_ARG_INFO(0, regular)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_engine_search_set_forward, 0)
    ZEND_ARG_INFO(0, forward)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtml_engine_search_incremental, 0)
    ZEND_ARG_INFO(0, text)
    ZEND_ARG_INFO(0, forward)
ZEND_END_ARG_INFO();

static function_entry gtkhtml_methods[] = {
	PHP_ME(GtkHTML, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, allow_selection,      arginfo_gtk_gtkhtml_allow_selection, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, append_html,          arginfo_gtk_gtkhtml_append_html, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, command,              arginfo_gtk_gtkhtml_command, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, copy,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, cut,                  NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, drag_dest_set,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, drop_undo,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, edit_make_cursor_visible, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, enable_debug,         arginfo_gtk_gtkhtml_enable_debug, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, engine_search,        arginfo_gtk_gtkhtml_engine_search, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, engine_search_incremental, arginfo_gtk_gtkhtml_engine_search_incremental, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, engine_search_next,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, engine_search_set_forward, arginfo_gtk_gtkhtml_engine_search_set_forward, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, flush,                NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_allow_frameset,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_animate,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_caret_mode,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_cursor_url,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_editable,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_inline_spelling,  NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_magic_links,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_magic_smileys,    NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_paragraph_indentation, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_top_html,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_url_at,           arginfo_gtk_gtkhtml_get_url_at, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, get_url_base_relative, arginfo_gtk_gtkhtml_get_url_base_relative, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, has_undo,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, image_preload,        arginfo_gtk_gtkhtml_image_preload, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, image_ref,            arginfo_gtk_gtkhtml_image_ref, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, image_unref,          arginfo_gtk_gtkhtml_image_unref, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, images_ref,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, images_unref,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, indent_pop_level,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, indent_push_level,    arginfo_gtk_gtkhtml_indent_push_level, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, insert_gtk_html,      arginfo_gtk_gtkhtml_insert_gtk_html, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, insert_html,          arginfo_gtk_gtkhtml_insert_html, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, jump_to_anchor,       arginfo_gtk_gtkhtml_jump_to_anchor, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, load_empty,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, load_from_string,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, paste,                arginfo_gtk_gtkhtml_paste, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, redo,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, request_paste,        arginfo_gtk_gtkhtml_request_paste, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, select_all,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, select_line,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, select_paragraph,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, select_paragraph_extended, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, select_word,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_allow_frameset,   arginfo_gtk_gtkhtml_set_allow_frameset, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_animate,          arginfo_gtk_gtkhtml_set_animate, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_base,             arginfo_gtk_gtkhtml_set_base, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_blocking,         arginfo_gtk_gtkhtml_set_blocking, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_caret_mode,       arginfo_gtk_gtkhtml_set_caret_mode, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_default_content_type, arginfo_gtk_gtkhtml_set_default_content_type, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_editable,         arginfo_gtk_gtkhtml_set_editable, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_images_blocking,  arginfo_gtk_gtkhtml_set_images_blocking, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_inline_spelling,  arginfo_gtk_gtkhtml_set_inline_spelling, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_magic_links,      arginfo_gtk_gtkhtml_set_magic_links, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_magic_smileys,    arginfo_gtk_gtkhtml_set_magic_smileys, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_magnification,    arginfo_gtk_gtkhtml_set_magnification, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, set_title,            arginfo_gtk_gtkhtml_set_title, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, stop,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, undo,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, update_styles,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, zoom_in,              NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, zoom_out,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTML, zoom_reset,           NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkHTMLEmbedded, __construct)
{
	char *classid, *name, *type, *data;
	zend_bool free_classid = FALSE, free_name = FALSE, free_type = FALSE, free_data = FALSE;
	long width, height;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uuuuii", &classid, &free_classid, &name, &free_name, &type, &free_type, &data, &free_data, &width, &height)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkHTMLEmbedded);
	}

	wrapped_obj = (GObject *) gtk_html_embedded_new(classid, name, type, data, (int)width, (int)height);
	if (free_classid) g_free(classid);
	if (free_name) g_free(name);
	if (free_type) g_free(type);
	if (free_data) g_free(data);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkHTMLEmbedded);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkHTMLEmbedded, set_parameter)
{
	char *param, *value;
	zend_bool free_param = FALSE, free_value = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uu", &param, &free_param, &value, &free_value))
		return;

    gtk_html_embedded_set_parameter(GTK_HTML_EMBEDDED(PHPG_GOBJECT(this_ptr)), param, value);
	if (free_param) g_free(param);
	if (free_value) g_free(value);

}


static PHP_METHOD(GtkHTMLEmbedded, get_parameter)
{
	char *param;
	zend_bool free_param = FALSE, free_result;
	gchar *php_retval, *cp_ret;
	gsize cp_len;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &param, &free_param))
		return;

    php_retval = gtk_html_embedded_get_parameter(GTK_HTML_EMBEDDED(PHPG_GOBJECT(this_ptr)), param);
	if (free_param) g_free(param);
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkHTMLEmbedded, set_descent)
{
	long descent;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &descent))
		return;

    gtk_html_embedded_set_descent(GTK_HTML_EMBEDDED(PHPG_GOBJECT(this_ptr)), (int)descent);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtmlembedded_gtk_html_embedded_new, 0)
    ZEND_ARG_INFO(0, classid)
    ZEND_ARG_INFO(0, name)
    ZEND_ARG_INFO(0, type)
    ZEND_ARG_INFO(0, data)
    ZEND_ARG_INFO(0, width)
    ZEND_ARG_INFO(0, height)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtmlembedded_set_parameter, 0)
    ZEND_ARG_INFO(0, param)
    ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtmlembedded_get_parameter, 0)
    ZEND_ARG_INFO(0, param)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkhtmlembedded_set_descent, 0)
    ZEND_ARG_INFO(0, descent)
ZEND_END_ARG_INFO();

static function_entry gtkhtmlembedded_methods[] = {
	PHP_ME(GtkHTMLEmbedded, __construct,          arginfo_gtk_gtkhtmlembedded_gtk_html_embedded_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTMLEmbedded, get_parameter,        arginfo_gtk_gtkhtmlembedded_get_parameter, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTMLEmbedded, set_descent,          arginfo_gtk_gtkhtmlembedded_set_descent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkHTMLEmbedded, set_parameter,        arginfo_gtk_gtkhtmlembedded_set_parameter, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

void phpg_gtkhtml_register_classes(void)
{
	TSRMLS_FETCH();

	gtkhtml_ce = phpg_register_class("GtkHTML", NULL, NULL, 0, NULL, NULL, 0 TSRMLS_CC);

	gtkhtml_ce = phpg_register_class("GtkHTML", gtkhtml_methods, gtklayout_ce, 0, NULL, NULL, GTK_TYPE_HTML TSRMLS_CC);

	gtkhtmlembedded_ce = phpg_register_class("GtkHTMLEmbedded", gtkhtmlembedded_methods, gtkbin_ce, 0, NULL, NULL, GTK_TYPE_HTML_EMBEDDED TSRMLS_CC);
}

void phpg_gtkhtml_register_constants(const char *strip_prefix)
{
    TSRMLS_FETCH();


    /* register gtype constants for all classes */

	phpg_register_int_constant(gtkhtml_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_HTML);
	phpg_register_int_constant(gtkhtmlembedded_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_HTML_EMBEDDED);

}

#endif /* HAVE_PHP_GTK */
