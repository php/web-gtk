extern PHP_GTK_EXPORT_CE(gtkhtml_ce);
extern PHP_GTK_EXPORT_CE(gtkhtmlembedded_ce);
extern PHP_GTK_EXPORT_CE(gtkhtml_ce);
