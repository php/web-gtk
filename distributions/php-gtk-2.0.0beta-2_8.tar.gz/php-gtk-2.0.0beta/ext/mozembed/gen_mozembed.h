extern PHP_GTK_EXPORT_CE(gtkmozembed_ce);
extern PHP_GTK_EXPORT_CE(gtkmozembed_ce);
