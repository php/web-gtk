#include "php_gtk.h"

#if HAVE_PHP_GTK
#include <gtkmozembed.h>
#include "ext/gtk+/php_gtk+.h"
#include "php_gtk_api.h"

PHP_GTK_EXPORT_CE(gtkmozembed_ce);
PHP_GTK_EXPORT_CE(gtkmozembed_ce);

static PHP_METHOD(GtkMozEmbed, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkMozEmbed);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkMozEmbed);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkMozEmbed, load_url)
{
	char *url;
	zend_bool free_url = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &url, &free_url))
		return;

    gtk_moz_embed_load_url(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), url);
	if (free_url) g_free(url);

}


static PHP_METHOD(GtkMozEmbed, stop_load)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_moz_embed_stop_load(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkMozEmbed, can_go_back)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_can_go_back(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkMozEmbed, can_go_forward)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_can_go_forward(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkMozEmbed, go_back)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_moz_embed_go_back(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkMozEmbed, go_forward)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_moz_embed_go_forward(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkMozEmbed, render_data)
{
	char *data, *base_uri, *mime_type;
	zend_bool free_data = FALSE, free_base_uri = FALSE, free_mime_type = FALSE;
	long len;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uiuu", &data, &free_data, &len, &base_uri, &free_base_uri, &mime_type, &free_mime_type))
		return;

    gtk_moz_embed_render_data(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), data, (guint32)len, base_uri, mime_type);
	if (free_data) g_free(data);
	if (free_base_uri) g_free(base_uri);
	if (free_mime_type) g_free(mime_type);

}


static PHP_METHOD(GtkMozEmbed, open_stream)
{
	char *base_uri, *mime_type;
	zend_bool free_base_uri = FALSE, free_mime_type = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uu", &base_uri, &free_base_uri, &mime_type, &free_mime_type))
		return;

    gtk_moz_embed_open_stream(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), base_uri, mime_type);
	if (free_base_uri) g_free(base_uri);
	if (free_mime_type) g_free(mime_type);

}


static PHP_METHOD(GtkMozEmbed, append_data)
{
	char *data;
	zend_bool free_data = FALSE;
	long len;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "ui", &data, &free_data, &len))
		return;

    gtk_moz_embed_append_data(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), data, (guint32)len);
	if (free_data) g_free(data);

}


static PHP_METHOD(GtkMozEmbed, close_stream)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_moz_embed_close_stream(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkMozEmbed, get_link_message)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_get_link_message(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkMozEmbed, get_js_status)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_get_js_status(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkMozEmbed, get_title)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_get_title(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkMozEmbed, get_location)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_get_location(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkMozEmbed, reload)
{
	long flags;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &flags))
		return;

    gtk_moz_embed_reload(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), (gint32)flags);

}


static PHP_METHOD(GtkMozEmbed, set_chrome_mask)
{
	long flags;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &flags))
		return;

    gtk_moz_embed_set_chrome_mask(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)), (guint32)flags);

}


static PHP_METHOD(GtkMozEmbed, get_chrome_mask)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_moz_embed_get_chrome_mask(GTK_MOZ_EMBED(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_load_url, 0)
    ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_render_data, 0)
    ZEND_ARG_INFO(0, data)
    ZEND_ARG_INFO(0, len)
    ZEND_ARG_INFO(0, base_uri)
    ZEND_ARG_INFO(0, mime_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_open_stream, 0)
    ZEND_ARG_INFO(0, base_uri)
    ZEND_ARG_INFO(0, mime_type)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_append_data, 0)
    ZEND_ARG_INFO(0, data)
    ZEND_ARG_INFO(0, len)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_reload, 0)
    ZEND_ARG_INFO(0, flags)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtkmozembed_set_chrome_mask, 0)
    ZEND_ARG_INFO(0, flags)
ZEND_END_ARG_INFO();

static function_entry gtkmozembed_methods[] = {
	PHP_ME(GtkMozEmbed, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, append_data,          arginfo_gtk_gtkmozembed_append_data, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, can_go_back,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, can_go_forward,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, close_stream,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, get_chrome_mask,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, get_js_status,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, get_link_message,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, get_location,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, get_title,            NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, go_back,              NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, go_forward,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, load_url,             arginfo_gtk_gtkmozembed_load_url, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, open_stream,          arginfo_gtk_gtkmozembed_open_stream, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, reload,               arginfo_gtk_gtkmozembed_reload, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, render_data,          arginfo_gtk_gtkmozembed_render_data, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, set_chrome_mask,      arginfo_gtk_gtkmozembed_set_chrome_mask, ZEND_ACC_PUBLIC)
	PHP_ME(GtkMozEmbed, stop_load,            NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

void phpg_gtkmozembed_register_classes(void)
{
	TSRMLS_FETCH();

	gtkmozembed_ce = phpg_register_class("GtkMozembed", NULL, NULL, 0, NULL, NULL, 0 TSRMLS_CC);

	gtkmozembed_ce = phpg_register_class("GtkMozEmbed", gtkmozembed_methods, gtkbin_ce, 0, NULL, NULL, GTK_TYPE_MOZ_EMBED TSRMLS_CC);
}

void phpg_gtkmozembed_register_constants(const char *strip_prefix)
{
    TSRMLS_FETCH();


    /* register gtype constants for all classes */

	phpg_register_int_constant(gtkmozembed_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_MOZ_EMBED);

}

#endif /* HAVE_PHP_GTK */
