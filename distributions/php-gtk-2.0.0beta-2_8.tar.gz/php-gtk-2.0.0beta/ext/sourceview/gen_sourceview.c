#include "php_gtk.h"

#if HAVE_PHP_GTK
#include <gtksourceview/gtksourceview.h>
#include <gtksourceview/gtksourcebuffer.h>
#include <gtksourceview/gtksourceiter.h>
#include <gtksourceview/gtksourcelanguage.h>
#include <gtksourceview/gtksourcelanguagesmanager.h>
#include <gtksourceview/gtksourcemarker.h>
#include <gtksourceview/gtksourcestylescheme.h>
#include <gtksourceview/gtksourcetag.h>
#include <gtksourceview/gtksourcetagstyle.h>
#include <gtksourceview/gtksourcetagtable.h>
#include <gtksourceview/gtksourceview-typebuiltins.h>
#include "ext/gtk+/php_gtk+.h"
#include "php_gtk_api.h"

PHP_GTK_EXPORT_CE(gtksourcestylescheme_ce);
PHP_GTK_EXPORT_CE(gtksourcebuffer_ce);
PHP_GTK_EXPORT_CE(gtksourcelanguage_ce);
PHP_GTK_EXPORT_CE(gtksourcelanguagesmanager_ce);
PHP_GTK_EXPORT_CE(gtksourcetagtable_ce);
PHP_GTK_EXPORT_CE(gtksourceview_ce);
PHP_GTK_EXPORT_CE(gtksourcemarker_ce);
PHP_GTK_EXPORT_CE(gtksourcetagstyle_ce);
PHP_GTK_EXPORT_CE(gtksourceview_ce);
#line 253 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceStyleScheme, get_style_names)
{
    GSList *schemes;
    gchar *fn = NULL;
    gchar *cp = NULL;
    gsize cp_len = 0;
    zend_bool free_cp = FALSE;
    zend_bool convert = 1;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|b", &convert)) {
        return;
    }

    array_init(return_value);
    for (schemes = gtk_source_style_scheme_get_style_names(GTK_SOURCE_STYLE_SCHEME(PHPG_GOBJECT(this_ptr))); schemes; schemes = schemes->next) {
        if (convert) {
            fn = g_filename_to_utf8((char *) schemes->data, strlen((char *) schemes->data), NULL, NULL, NULL);
            cp = phpg_from_utf8(fn, strlen(fn), &cp_len, &free_cp TSRMLS_CC);
            if (cp) {
                add_next_index_string(return_value, (char *)cp, 1);
            } else {
                php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            }
            if (free_cp)
                g_free(cp);
        } else {
            add_next_index_string(return_value, (char *) schemes->data, 1);
        }
        g_free(schemes->data);
    }
    g_slist_free(schemes);
}

#line 64 "ext/sourceview/gen_sourceview.c"


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtksourcestylescheme_get_style_names, 0, 0, 0)
    ZEND_ARG_INFO(0, convert)
ZEND_END_ARG_INFO();


static function_entry gtksourcestylescheme_methods[] = {
	ZEND_FENTRY(get_style_names, ZEND_MN(GtkSourceStyleScheme_get_style_names),      arginfo_gtk_gtksourcestylescheme_get_style_names, ZEND_ACC_PUBLIC|ZEND_ACC_ABSTRACT)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceBuffer, __construct)
{
	GtkSourceTagTable *table = NULL;
	zval *php_table = NULL;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|N", &php_table, gtksourcetagtable_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceBuffer);
	}
    if (php_table) {
        if (Z_TYPE_P(php_table) == IS_NULL)
            table = NULL;
        else
            table = GTK_SOURCE_TAG_TABLE(PHPG_GOBJECT(php_table));
    }

	wrapped_obj = (GObject *) gtk_source_buffer_new(table);

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceBuffer);
	}

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, new_with_language)
{
	zval *language;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &language, gtksourcelanguage_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceBuffer);
	}

	wrapped_obj = (GObject *) gtk_source_buffer_new_with_language(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(language)));

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceBuffer);
	}
    phpg_gobject_new(&return_value, wrapped_obj TSRMLS_CC);
    g_object_unref(wrapped_obj); /* phpg_gobject_new() increments reference count */
}


static PHP_METHOD(GtkSourceBuffer, get_check_brackets)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_check_brackets(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceBuffer, set_check_brackets)
{
	zend_bool check_brackets;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &check_brackets))
		return;

    gtk_source_buffer_set_check_brackets(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), (gboolean)check_brackets);

}


static PHP_METHOD(GtkSourceBuffer, set_bracket_match_style)
{
	GtkSourceTagStyle *style = NULL;
	zval *php_style;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_style, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_style, GTK_TYPE_SOURCE_TAG_STYLE, FALSE TSRMLS_CC)) {
        style = (GtkSourceTagStyle *) PHPG_GBOXED(php_style);
    } else {
        php_error(E_WARNING, "%s::%s() expects style argument to be a valid GtkSourceTagStyle object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_source_buffer_set_bracket_match_style(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), style);

}


static PHP_METHOD(GtkSourceBuffer, get_highlight)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_highlight(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceBuffer, set_highlight)
{
	zend_bool highlight;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &highlight))
		return;

    gtk_source_buffer_set_highlight(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), (gboolean)highlight);

}


static PHP_METHOD(GtkSourceBuffer, get_max_undo_levels)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_max_undo_levels(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSourceBuffer, set_max_undo_levels)
{
	long max_undo_levels;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &max_undo_levels))
		return;

    gtk_source_buffer_set_max_undo_levels(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), (gint)max_undo_levels);

}


static PHP_METHOD(GtkSourceBuffer, get_language)
{
	GtkSourceLanguage* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_language(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, set_language)
{
	GtkSourceLanguage *language = NULL;
	zval *php_language;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "N", &php_language, gtksourcelanguage_ce))
		return;
    if (Z_TYPE_P(php_language) != IS_NULL)
        language = GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(php_language));

    gtk_source_buffer_set_language(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), language);

}

#line 27 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceBuffer, get_escape_char)
{
    gunichar ichar;
    gint len;
    gchar *ret = safe_emalloc(6, sizeof(gchar *), 0);
    gchar *cp_ret;
    gsize cp_len;
    zend_bool free_result = FALSE;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
        return;

    ichar = gtk_source_buffer_get_escape_char(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));

    if (ichar) {
        len = g_unichar_to_utf8(ichar, ret);
        cp_ret = phpg_from_utf8(ret, len, &cp_len, &free_result TSRMLS_CC);

        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }

        if (free_result)
            g_free(cp_ret);
        else
            RETVAL_STRINGL((char *)ichar, len, 1);
    } else {
        RETVAL_NULL();
    }

    efree(ret);
}

#line 298 "ext/sourceview/gen_sourceview.c"


#line 73 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceBuffer, set_escape_char)
{
    char *getchar;
    gunichar setchar;
    zend_bool free_char = FALSE;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &getchar, &free_char))
        return;

    setchar = g_utf8_get_char((const gchar*)getchar);
    gtk_source_buffer_set_escape_char(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), setchar);

    if (free_char)
        efree(getchar);
}

#line 320 "ext/sourceview/gen_sourceview.c"



static PHP_METHOD(GtkSourceBuffer, can_undo)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_can_undo(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceBuffer, can_redo)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_can_redo(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceBuffer, undo)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_buffer_undo(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSourceBuffer, redo)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_buffer_redo(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSourceBuffer, begin_not_undoable_action)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_buffer_begin_not_undoable_action(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSourceBuffer, end_not_undoable_action)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_buffer_end_not_undoable_action(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));

}


static PHP_METHOD(GtkSourceBuffer, create_marker)
{
	char *name, *type;
	zend_bool free_name = FALSE, free_type = FALSE;
	GtkTextIter *where = NULL;
	zval *php_where;
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uuN", &name, &free_name, &type, &free_type, &php_where, gboxed_ce))
		return;

    if (Z_TYPE_P(php_where) != IS_NULL) {
        if (phpg_gboxed_check(php_where, GTK_TYPE_TEXT_ITER, FALSE TSRMLS_CC)) {
            where = (GtkTextIter *) PHPG_GBOXED(php_where);
        } else {
            php_error(E_WARNING, "%s::%s() expects where argument to be a valid GtkTextIter object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    php_retval = gtk_source_buffer_create_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), name, type, where);
	if (free_name) g_free(name);
	if (free_type) g_free(type);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, move_marker)
{
	zval *marker, *php_where;
	GtkTextIter *where = NULL;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &marker, gtksourcemarker_ce, &php_where, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_where, GTK_TYPE_TEXT_ITER, FALSE TSRMLS_CC)) {
        where = (GtkTextIter *) PHPG_GBOXED(php_where);
    } else {
        php_error(E_WARNING, "%s::%s() expects where argument to be a valid GtkTextIter object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_source_buffer_move_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), GTK_SOURCE_MARKER(PHPG_GOBJECT(marker)), where);

}


static PHP_METHOD(GtkSourceBuffer, delete_marker)
{
	zval *marker;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &marker, gtksourcemarker_ce))
		return;

    gtk_source_buffer_delete_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), GTK_SOURCE_MARKER(PHPG_GOBJECT(marker)));

}


static PHP_METHOD(GtkSourceBuffer, get_marker)
{
	char *name;
	zend_bool free_name = FALSE;
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &name, &free_name))
		return;

    php_retval = gtk_source_buffer_get_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), name);
	if (free_name) g_free(name);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, get_first_marker)
{
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_first_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, get_last_marker)
{
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_buffer_get_last_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, get_iter_at_marker)
{
	GtkTextIter *iter = NULL;
	zval *php_iter, *marker;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "OO", &php_iter, gboxed_ce, &marker, gtksourcemarker_ce))
		return;

    if (phpg_gboxed_check(php_iter, GTK_TYPE_TEXT_ITER, FALSE TSRMLS_CC)) {
        iter = (GtkTextIter *) PHPG_GBOXED(php_iter);
    } else {
        php_error(E_WARNING, "%s::%s() expects iter argument to be a valid GtkTextIter object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    gtk_source_buffer_get_iter_at_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), iter, GTK_SOURCE_MARKER(PHPG_GOBJECT(marker)));

}


static PHP_METHOD(GtkSourceBuffer, get_next_marker)
{
	GtkTextIter *iter = NULL;
	zval *php_iter;
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_iter, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_iter, GTK_TYPE_TEXT_ITER, FALSE TSRMLS_CC)) {
        iter = (GtkTextIter *) PHPG_GBOXED(php_iter);
    } else {
        php_error(E_WARNING, "%s::%s() expects iter argument to be a valid GtkTextIter object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_source_buffer_get_next_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), iter);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceBuffer, get_prev_marker)
{
	GtkTextIter *iter = NULL;
	zval *php_iter;
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &php_iter, gboxed_ce))
		return;

    if (phpg_gboxed_check(php_iter, GTK_TYPE_TEXT_ITER, FALSE TSRMLS_CC)) {
        iter = (GtkTextIter *) PHPG_GBOXED(php_iter);
    } else {
        php_error(E_WARNING, "%s::%s() expects iter argument to be a valid GtkTextIter object",
                  get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        return;
    }

    php_retval = gtk_source_buffer_get_prev_marker(GTK_SOURCE_BUFFER(PHPG_GOBJECT(this_ptr)), iter);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtksourcebuffer_gtk_source_buffer_new, 0, 0, 0)
    ZEND_ARG_OBJ_INFO(0, table, GtkSourceTagTable, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_gtk_source_buffer_new_with_language, 0)
    ZEND_ARG_OBJ_INFO(0, language, GtkSourceLanguage, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_check_brackets, 0)
    ZEND_ARG_INFO(0, check_brackets)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_bracket_match_style, 0)
    ZEND_ARG_OBJ_INFO(0, style, GtkSourceTagStyle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_highlight, 0)
    ZEND_ARG_INFO(0, highlight)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_max_undo_levels, 0)
    ZEND_ARG_INFO(0, max_undo_levels)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_language, 0)
    ZEND_ARG_OBJ_INFO(0, language, GtkSourceLanguage, 1)
ZEND_END_ARG_INFO();
static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_set_escape_char, 0)
    ZEND_ARG_INFO(0, char)
ZEND_END_ARG_INFO();


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_create_marker, 0)
    ZEND_ARG_INFO(0, name)
    ZEND_ARG_INFO(0, type)
    ZEND_ARG_OBJ_INFO(0, where, GtkTextIter, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_move_marker, 0)
    ZEND_ARG_OBJ_INFO(0, marker, GtkSourceMarker, 1)
    ZEND_ARG_OBJ_INFO(0, where, GtkTextIter, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_delete_marker, 0)
    ZEND_ARG_OBJ_INFO(0, marker, GtkSourceMarker, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_get_marker, 0)
    ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_get_iter_at_marker, 0)
    ZEND_ARG_OBJ_INFO(0, iter, GtkTextIter, 1)
    ZEND_ARG_OBJ_INFO(0, marker, GtkSourceMarker, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_get_next_marker, 0)
    ZEND_ARG_OBJ_INFO(0, iter, GtkTextIter, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcebuffer_get_prev_marker, 0)
    ZEND_ARG_OBJ_INFO(0, iter, GtkTextIter, 1)
ZEND_END_ARG_INFO();

static function_entry gtksourcebuffer_methods[] = {
	PHP_ME(GtkSourceBuffer, __construct,          arginfo_gtk_gtksourcebuffer_gtk_source_buffer_new, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, new_with_language,    arginfo_gtk_gtksourcebuffer_gtk_source_buffer_new_with_language, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkSourceBuffer, begin_not_undoable_action, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, can_redo,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, can_undo,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, create_marker,        arginfo_gtk_gtksourcebuffer_create_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, delete_marker,        arginfo_gtk_gtksourcebuffer_delete_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, end_not_undoable_action, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_check_brackets,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_escape_char,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_first_marker,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_highlight,        NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_iter_at_marker,   arginfo_gtk_gtksourcebuffer_get_iter_at_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_language,         NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_last_marker,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_marker,           arginfo_gtk_gtksourcebuffer_get_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_max_undo_levels,  NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_next_marker,      arginfo_gtk_gtksourcebuffer_get_next_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, get_prev_marker,      arginfo_gtk_gtksourcebuffer_get_prev_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, move_marker,          arginfo_gtk_gtksourcebuffer_move_marker, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, redo,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_bracket_match_style, arginfo_gtk_gtksourcebuffer_set_bracket_match_style, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_check_brackets,   arginfo_gtk_gtksourcebuffer_set_check_brackets, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_escape_char,      arginfo_gtk_gtksourcebuffer_set_escape_char, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_highlight,        arginfo_gtk_gtksourcebuffer_set_highlight, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_language,         arginfo_gtk_gtksourcebuffer_set_language, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, set_max_undo_levels,  arginfo_gtk_gtksourcebuffer_set_max_undo_levels, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceBuffer, undo,                 NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceLanguage, get_id)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_language_get_id(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkSourceLanguage, get_name)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_language_get_name(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkSourceLanguage, get_section)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_language_get_section(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}

#line 222 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceLanguage, get_tags)
{
    GSList *tags;
    zval *item;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        return;
    }

    array_init(return_value);
    for (tags = gtk_source_language_get_tags(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr))); tags; tags = tags->next) {
        MAKE_STD_ZVAL(item);
        phpg_gobject_new(&item, G_OBJECT(tags->data) TSRMLS_CC);
        add_next_index_zval(return_value, item);
    }
}

#line 797 "ext/sourceview/gen_sourceview.c"


#line 162 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceLanguage, get_escape_char)
{
    gunichar ichar;
    gint len;
    gchar *ret = safe_emalloc(6, sizeof(gchar *), 0);
    gchar *cp_ret;
    gsize cp_len;
    zend_bool free_result = FALSE;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
        return;

    ichar = gtk_source_language_get_escape_char(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)));

    if (ichar) {
        len = g_unichar_to_utf8(ichar, ret);
        cp_ret = phpg_from_utf8(ret, len, &cp_len, &free_result TSRMLS_CC);

        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }

        if (free_result)
            g_free(cp_ret);
        else
            RETVAL_STRINGL((char *)ichar, len, 1);
    } else {
        RETVAL_NULL();
    }

    efree(ret);
}

#line 838 "ext/sourceview/gen_sourceview.c"


#line 201 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceLanguage, get_mime_types)
{
    GSList *list;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        return;
    }

    array_init(return_value);
    for (list = gtk_source_language_get_mime_types(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr))); list; list = list->next) {
        add_next_index_string(return_value, (char *)list->data, 1);
        g_free(list->data);
    }

    g_slist_free(list);
}

#line 861 "ext/sourceview/gen_sourceview.c"



static PHP_METHOD(GtkSourceLanguage, get_style_scheme)
{
	GtkSourceStyleScheme* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_language_get_style_scheme(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceLanguage, set_style_scheme)
{
	zval *scheme;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &scheme, gtksourcestylescheme_ce))
		return;

    gtk_source_language_set_style_scheme(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)), GTK_SOURCE_STYLE_SCHEME(PHPG_GOBJECT(scheme)));

}


static PHP_METHOD(GtkSourceLanguage, get_tag_style)
{
	char *tag_id;
	zend_bool free_tag_id = FALSE;
	GtkSourceTagStyle *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &tag_id, &free_tag_id))
		return;

    php_retval = gtk_source_language_get_tag_style(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)), tag_id);
	if (free_tag_id) g_free(tag_id);
	phpg_gboxed_new(&return_value, GTK_TYPE_SOURCE_TAG_STYLE, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkSourceLanguage, set_tag_style)
{
	char *tag_id;
	zend_bool free_tag_id = FALSE;
	GtkSourceTagStyle *style = NULL;
	zval *php_style;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uN", &tag_id, &free_tag_id, &php_style, gboxed_ce))
		return;

    if (Z_TYPE_P(php_style) != IS_NULL) {
        if (phpg_gboxed_check(php_style, GTK_TYPE_SOURCE_TAG_STYLE, FALSE TSRMLS_CC)) {
            style = (GtkSourceTagStyle *) PHPG_GBOXED(php_style);
        } else {
            php_error(E_WARNING, "%s::%s() expects style argument to be a valid GtkSourceTagStyle object or null", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            return;
        }
    }

    gtk_source_language_set_tag_style(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)), tag_id, style);
	if (free_tag_id) g_free(tag_id);

}


static PHP_METHOD(GtkSourceLanguage, get_tag_default_style)
{
	char *tag_id;
	zend_bool free_tag_id = FALSE;
	GtkSourceTagStyle *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &tag_id, &free_tag_id))
		return;

    php_retval = gtk_source_language_get_tag_default_style(GTK_SOURCE_LANGUAGE(PHPG_GOBJECT(this_ptr)), tag_id);
	if (free_tag_id) g_free(tag_id);
	phpg_gboxed_new(&return_value, GTK_TYPE_SOURCE_TAG_STYLE, php_retval, TRUE, TRUE TSRMLS_CC);

}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcelanguage_set_style_scheme, 0)
    ZEND_ARG_OBJ_INFO(0, scheme, GtkSourceStyleScheme, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcelanguage_get_tag_style, 0)
    ZEND_ARG_INFO(0, tag_id)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcelanguage_set_tag_style, 0)
    ZEND_ARG_INFO(0, tag_id)
    ZEND_ARG_OBJ_INFO(0, style, GtkSourceTagStyle, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcelanguage_get_tag_default_style, 0)
    ZEND_ARG_INFO(0, tag_id)
ZEND_END_ARG_INFO();

static function_entry gtksourcelanguage_methods[] = {
	PHP_ME(GtkSourceLanguage, get_escape_char,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_id,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_mime_types,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_name,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_section,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_style_scheme,     NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_tag_default_style, arginfo_gtk_gtksourcelanguage_get_tag_default_style, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_tag_style,        arginfo_gtk_gtksourcelanguage_get_tag_style, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, get_tags,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, set_style_scheme,     arginfo_gtk_gtksourcelanguage_set_style_scheme, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguage, set_tag_style,        arginfo_gtk_gtksourcelanguage_set_tag_style, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceLanguagesManager, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceLanguagesManager);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceLanguagesManager);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}

#line 96 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceLanguagesManager, get_available_languages)
{
    const GSList *list;
    zval *item;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        return;
    }

    array_init(return_value);
    for (list = gtk_source_languages_manager_get_available_languages(GTK_SOURCE_LANGUAGES_MANAGER(PHPG_GOBJECT(this_ptr))); list; list = list->next) {
        MAKE_STD_ZVAL(item);
        phpg_gobject_new(&item, G_OBJECT(list->data) TSRMLS_CC);
        add_next_index_zval(return_value, item);
    }
}

#line 1028 "ext/sourceview/gen_sourceview.c"



static PHP_METHOD(GtkSourceLanguagesManager, get_language_from_mime_type)
{
	char *mime_type;
	zend_bool free_mime_type = FALSE;
	GtkSourceLanguage* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &mime_type, &free_mime_type))
		return;

    php_retval = gtk_source_languages_manager_get_language_from_mime_type(GTK_SOURCE_LANGUAGES_MANAGER(PHPG_GOBJECT(this_ptr)), mime_type);
	if (free_mime_type) g_free(mime_type);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}

#line 124 "ext/sourceview/sourceview.overrides"
static PHP_METHOD(GtkSourceLanguagesManager, get_lang_files_dirs)
{
    const GSList *list;
    gchar *fn = NULL;
    gchar *cp = NULL;
    gsize cp_len = 0;
    zend_bool free_cp = FALSE;
    zend_bool convert = 1;

    NOT_STATIC_METHOD();

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "|b", &convert)) {
        return;
    }

    array_init(return_value);
    for (list = gtk_source_languages_manager_get_lang_files_dirs(GTK_SOURCE_LANGUAGES_MANAGER(PHPG_GOBJECT(this_ptr))); list; list = list->next) {
        if (convert) {
            fn = g_filename_to_utf8((char *) list->data, strlen((char *) list->data), NULL, NULL, NULL);
            cp = phpg_from_utf8(fn, strlen(fn), &cp_len, &free_cp TSRMLS_CC);
            if (cp) {
                add_next_index_string(return_value, (char *)cp, 1);
            } else {
                php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
            }
            if (free_cp)
                g_free(cp);
        } else {
            add_next_index_string(return_value, (char *) list->data, 1);
        }
    }
}

#line 1082 "ext/sourceview/gen_sourceview.c"



static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcelanguagesmanager_get_language_from_mime_type, 0)
    ZEND_ARG_INFO(0, mime_type)
ZEND_END_ARG_INFO();
static
ZEND_BEGIN_ARG_INFO_EX(arginfo_gtk_gtksourcelanguagesmanager_get_lang_files_dirs, 0, 0, 0)
    ZEND_ARG_INFO(0, convert)
ZEND_END_ARG_INFO();


static function_entry gtksourcelanguagesmanager_methods[] = {
	PHP_ME(GtkSourceLanguagesManager, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguagesManager, get_available_languages, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguagesManager, get_lang_files_dirs,  arginfo_gtk_gtksourcelanguagesmanager_get_lang_files_dirs, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceLanguagesManager, get_language_from_mime_type, arginfo_gtk_gtksourcelanguagesmanager_get_language_from_mime_type, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceTagTable, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceTagTable);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceTagTable);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkSourceTagTable, remove_source_tags)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_tag_table_remove_source_tags(GTK_SOURCE_TAG_TABLE(PHPG_GOBJECT(this_ptr)));

}


static function_entry gtksourcetagtable_methods[] = {
	PHP_ME(GtkSourceTagTable, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceTagTable, remove_source_tags,   NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceView, __construct)
{
    GObject *wrapped_obj;

    if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceView);
    }

    wrapped_obj = (GObject *) g_object_newv(phpg_gtype_from_zval(this_ptr), 0, NULL);
    if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceView);
    }

    phpg_gobject_set_wrapper(this_ptr, wrapped_obj TSRMLS_CC);
}


static PHP_METHOD(GtkSourceView, new_with_buffer)
{
	zval *buffer;
	GObject *wrapped_obj;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "O", &buffer, gtksourcebuffer_ce)) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceView);
	}

	wrapped_obj = (GObject *) gtk_source_view_new_with_buffer(GTK_SOURCE_BUFFER(PHPG_GOBJECT(buffer)));

	if (!wrapped_obj) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceView);
	}
    phpg_gobject_new(&return_value, wrapped_obj TSRMLS_CC);
    g_object_unref(wrapped_obj); /* phpg_gobject_new() increments reference count */
}


static PHP_METHOD(GtkSourceView, set_show_line_numbers)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_source_view_set_show_line_numbers(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkSourceView, get_show_line_numbers)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_show_line_numbers(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_show_line_markers)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_source_view_set_show_line_markers(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkSourceView, get_show_line_markers)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_show_line_markers(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_tabs_width)
{
	long width;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &width))
		return;

    gtk_source_view_set_tabs_width(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (guint)width);

}


static PHP_METHOD(GtkSourceView, get_tabs_width)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_tabs_width(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSourceView, set_auto_indent)
{
	zend_bool enable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &enable))
		return;

    gtk_source_view_set_auto_indent(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)enable);

}


static PHP_METHOD(GtkSourceView, get_auto_indent)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_auto_indent(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_insert_spaces_instead_of_tabs)
{
	zend_bool enable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &enable))
		return;

    gtk_source_view_set_insert_spaces_instead_of_tabs(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)enable);

}


static PHP_METHOD(GtkSourceView, get_insert_spaces_instead_of_tabs)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_insert_spaces_instead_of_tabs(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_show_margin)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_source_view_set_show_margin(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkSourceView, get_show_margin)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_show_margin(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_highlight_current_line)
{
	zend_bool show;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &show))
		return;

    gtk_source_view_set_highlight_current_line(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)show);

}


static PHP_METHOD(GtkSourceView, get_highlight_current_line)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_highlight_current_line(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_margin)
{
	long margin;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "i", &margin))
		return;

    gtk_source_view_set_margin(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (guint)margin);

}


static PHP_METHOD(GtkSourceView, get_margin)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_margin(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSourceView, set_smart_home_end)
{
	zend_bool enable;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "b", &enable))
		return;

    gtk_source_view_set_smart_home_end(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), (gboolean)enable);

}


static PHP_METHOD(GtkSourceView, get_smart_home_end)
{
	gboolean php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_view_get_smart_home_end(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)));
	RETVAL_BOOL(php_retval);
}


static PHP_METHOD(GtkSourceView, set_marker_pixbuf)
{
	char *marker_type;
	zend_bool free_marker_type = FALSE;
	GdkPixbuf *pixbuf = NULL;
	zval *php_pixbuf;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "uN", &marker_type, &free_marker_type, &php_pixbuf, gdkpixbuf_ce))
		return;
    if (Z_TYPE_P(php_pixbuf) != IS_NULL)
        pixbuf = GDK_PIXBUF(PHPG_GOBJECT(php_pixbuf));

    gtk_source_view_set_marker_pixbuf(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), marker_type, pixbuf);
	if (free_marker_type) g_free(marker_type);

}


static PHP_METHOD(GtkSourceView, get_marker_pixbuf)
{
	char *marker_type;
	zend_bool free_marker_type = FALSE;
	GdkPixbuf* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &marker_type, &free_marker_type))
		return;

    php_retval = gtk_source_view_get_marker_pixbuf(GTK_SOURCE_VIEW(PHPG_GOBJECT(this_ptr)), marker_type);
	if (free_marker_type) g_free(marker_type);
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_gtk_source_view_new_with_buffer, 0)
    ZEND_ARG_OBJ_INFO(0, buffer, GtkSourceBuffer, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_show_line_numbers, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_show_line_markers, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_tabs_width, 0)
    ZEND_ARG_INFO(0, width)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_auto_indent, 0)
    ZEND_ARG_INFO(0, enable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_insert_spaces_instead_of_tabs, 0)
    ZEND_ARG_INFO(0, enable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_show_margin, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_highlight_current_line, 0)
    ZEND_ARG_INFO(0, show)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_margin, 0)
    ZEND_ARG_INFO(0, margin)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_smart_home_end, 0)
    ZEND_ARG_INFO(0, enable)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_set_marker_pixbuf, 0)
    ZEND_ARG_INFO(0, marker_type)
    ZEND_ARG_OBJ_INFO(0, pixbuf, GdkPixbuf, 1)
ZEND_END_ARG_INFO();

static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourceview_get_marker_pixbuf, 0)
    ZEND_ARG_INFO(0, marker_type)
ZEND_END_ARG_INFO();

static function_entry gtksourceview_methods[] = {
	PHP_ME(GtkSourceView, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, new_with_buffer,      arginfo_gtk_gtksourceview_gtk_source_view_new_with_buffer, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(GtkSourceView, get_auto_indent,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_highlight_current_line, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_insert_spaces_instead_of_tabs, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_margin,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_marker_pixbuf,    arginfo_gtk_gtksourceview_get_marker_pixbuf, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_show_line_markers, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_show_line_numbers, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_show_margin,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_smart_home_end,   NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, get_tabs_width,       NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_auto_indent,      arginfo_gtk_gtksourceview_set_auto_indent, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_highlight_current_line, arginfo_gtk_gtksourceview_set_highlight_current_line, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_insert_spaces_instead_of_tabs, arginfo_gtk_gtksourceview_set_insert_spaces_instead_of_tabs, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_margin,           arginfo_gtk_gtksourceview_set_margin, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_marker_pixbuf,    arginfo_gtk_gtksourceview_set_marker_pixbuf, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_show_line_markers, arginfo_gtk_gtksourceview_set_show_line_markers, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_show_line_numbers, arginfo_gtk_gtksourceview_set_show_line_numbers, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_show_margin,      arginfo_gtk_gtksourceview_set_show_margin, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_smart_home_end,   arginfo_gtk_gtksourceview_set_smart_home_end, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceView, set_tabs_width,       arginfo_gtk_gtksourceview_set_tabs_width, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceMarker, set_marker_type)
{
	char *type;
	zend_bool free_type = FALSE;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "u", &type, &free_type))
		return;

    gtk_source_marker_set_marker_type(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)), type);
	if (free_type) g_free(type);

}


static PHP_METHOD(GtkSourceMarker, get_marker_type)
{
	gchar *php_retval, *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_get_marker_type(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        g_free(php_retval);
        if (free_result)
            g_free(cp_ret);
    } else
        RETVAL_NULL();
}


static PHP_METHOD(GtkSourceMarker, get_line)
{
	long php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_get_line(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
	RETVAL_LONG(php_retval);
}


static PHP_METHOD(GtkSourceMarker, get_name)
{
	const gchar *php_retval;
	gchar *cp_ret;
	gsize cp_len;
	zend_bool free_result;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_get_name(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
    if (php_retval) {
        cp_ret = phpg_from_utf8(php_retval, strlen(php_retval), &cp_len, &free_result TSRMLS_CC);
        if (cp_ret) {
            RETVAL_STRINGL((char *)cp_ret, cp_len, 1);
        } else {
            php_error(E_WARNING, "%s::%s(): could not convert return value from UTF-8", get_active_class_name(NULL TSRMLS_CC), get_active_function_name(TSRMLS_C));
        }
        if (free_result)
            g_free(cp_ret);
    } else {
        RETVAL_NULL();
    }
}


static PHP_METHOD(GtkSourceMarker, get_buffer)
{
	GtkSourceBuffer* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_get_buffer(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceMarker, next)
{
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_next(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static PHP_METHOD(GtkSourceMarker, prev)
{
	GtkSourceMarker* php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_marker_prev(GTK_SOURCE_MARKER(PHPG_GOBJECT(this_ptr)));
    phpg_gobject_new(&return_value, (GObject *)php_retval TSRMLS_CC);
}


static
ZEND_BEGIN_ARG_INFO(arginfo_gtk_gtksourcemarker_set_marker_type, 0)
    ZEND_ARG_INFO(0, type)
ZEND_END_ARG_INFO();

static function_entry gtksourcemarker_methods[] = {
	PHP_ME(GtkSourceMarker, get_buffer,           NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, get_line,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, get_marker_type,      NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, get_name,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, next,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, prev,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceMarker, set_marker_type,      arginfo_gtk_gtksourcemarker_set_marker_type, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

static PHP_METHOD(GtkSourceTagStyle, __construct)
{

    phpg_gboxed_t *pobj = NULL;

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), "")) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceTagStyle);
	}

    pobj = zend_object_store_get_object(this_ptr TSRMLS_CC);
    pobj->gtype = GTK_TYPE_SOURCE_TAG_STYLE;
    pobj->boxed = gtk_source_tag_style_new();

	if (!pobj->boxed) {
        PHPG_THROW_CONSTRUCT_EXCEPTION(GtkSourceTagStyle);
	}
    pobj->free_on_destroy = TRUE;
}


PHPG_PROP_READER(GtkSourceTagStyle, is_default)
{
	gboolean php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->is_default;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, mask)
{
	long php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->mask;
	RETVAL_LONG(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, foreground)
{
	GdkColor php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->foreground;
	phpg_gboxed_new(&return_value, GDK_TYPE_COLOR, &php_retval, TRUE, TRUE TSRMLS_CC);

    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, background)
{
	GdkColor php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->background;
	phpg_gboxed_new(&return_value, GDK_TYPE_COLOR, &php_retval, TRUE, TRUE TSRMLS_CC);

    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, italic)
{
	gboolean php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->italic;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, bold)
{
	gboolean php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->bold;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, underline)
{
	gboolean php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->underline;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


PHPG_PROP_READER(GtkSourceTagStyle, strikethrough)
{
	gboolean php_retval;

    php_retval = ((GtkSourceTagStyle *)((phpg_gboxed_t *)object)->boxed)->strikethrough;
	RETVAL_BOOL(php_retval);
    return SUCCESS;
}


static prop_info_t gtksourcetagstyle_prop_info[] = {
	{ "is_default", PHPG_PROP_READ_FN(GtkSourceTagStyle, is_default), NULL },
	{ "mask", PHPG_PROP_READ_FN(GtkSourceTagStyle, mask), NULL },
	{ "foreground", PHPG_PROP_READ_FN(GtkSourceTagStyle, foreground), NULL },
	{ "background", PHPG_PROP_READ_FN(GtkSourceTagStyle, background), NULL },
	{ "italic", PHPG_PROP_READ_FN(GtkSourceTagStyle, italic), NULL },
	{ "bold", PHPG_PROP_READ_FN(GtkSourceTagStyle, bold), NULL },
	{ "underline", PHPG_PROP_READ_FN(GtkSourceTagStyle, underline), NULL },
	{ "strikethrough", PHPG_PROP_READ_FN(GtkSourceTagStyle, strikethrough), NULL },
	{ NULL, NULL, NULL },
};


static PHP_METHOD(GtkSourceTagStyle, copy)
{
	GtkSourceTagStyle *php_retval;

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    php_retval = gtk_source_tag_style_copy((GtkSourceTagStyle *)PHPG_GBOXED(this_ptr));
	phpg_gboxed_new(&return_value, GTK_TYPE_SOURCE_TAG_STYLE, php_retval, TRUE, TRUE TSRMLS_CC);

}


static PHP_METHOD(GtkSourceTagStyle, free)
{

    NOT_STATIC_METHOD();

	if (!php_gtk_parse_args(ZEND_NUM_ARGS(), ""))
		return;

    gtk_source_tag_style_free((GtkSourceTagStyle *)PHPG_GBOXED(this_ptr));

}


static function_entry gtksourcetagstyle_methods[] = {
	PHP_ME(GtkSourceTagStyle, __construct,          NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceTagStyle, copy,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(GtkSourceTagStyle, free,                 NULL, ZEND_ACC_PUBLIC)
	{ NULL, NULL, NULL }
};

void phpg_gtksourceview_register_classes(void)
{
	TSRMLS_FETCH();

	gtksourceview_ce = phpg_register_class("GtkSourceView", NULL, NULL, 0, NULL, NULL, 0 TSRMLS_CC);

	gtksourcestylescheme_ce = phpg_register_interface("GtkSourceStyleScheme", gtksourcestylescheme_methods, GTK_TYPE_SOURCE_STYLE_SCHEME TSRMLS_CC);

	gtksourcebuffer_ce = phpg_register_class("GtkSourceBuffer", gtksourcebuffer_methods, gtktextbuffer_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_BUFFER TSRMLS_CC);

	gtksourcelanguage_ce = phpg_register_class("GtkSourceLanguage", gtksourcelanguage_methods, gobject_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_LANGUAGE TSRMLS_CC);

	gtksourcelanguagesmanager_ce = phpg_register_class("GtkSourceLanguagesManager", gtksourcelanguagesmanager_methods, gobject_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_LANGUAGES_MANAGER TSRMLS_CC);

	gtksourcetagtable_ce = phpg_register_class("GtkSourceTagTable", gtksourcetagtable_methods, gtktexttagtable_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_TAG_TABLE TSRMLS_CC);

	gtksourceview_ce = phpg_register_class("GtkSourceView", gtksourceview_methods, gtktextview_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_VIEW TSRMLS_CC);

	gtksourcemarker_ce = phpg_register_class("GtkSourceMarker", gtksourcemarker_methods, gtktextmark_ce, 0, NULL, NULL, GTK_TYPE_SOURCE_MARKER TSRMLS_CC);

    gtksourcetagstyle_ce = phpg_register_boxed("GtkSourceTagStyle", gtksourcetagstyle_methods, gtksourcetagstyle_prop_info, NULL, GTK_TYPE_SOURCE_TAG_STYLE TSRMLS_CC);
}

void phpg_gtksourceview_register_constants(const char *strip_prefix)
{
    TSRMLS_FETCH();


    /* register gtype constants for all classes */

	phpg_register_int_constant(gtksourcebuffer_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_BUFFER);
	phpg_register_int_constant(gtksourcelanguage_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_LANGUAGE);
	phpg_register_int_constant(gtksourcelanguagesmanager_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_LANGUAGES_MANAGER);
	phpg_register_int_constant(gtksourcetagtable_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_TAG_TABLE);
	phpg_register_int_constant(gtksourceview_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_VIEW);
	phpg_register_int_constant(gtksourcemarker_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_MARKER);
	phpg_register_int_constant(gtksourcetagstyle_ce, "gtype", sizeof("gtype")-1, GTK_TYPE_SOURCE_TAG_STYLE);

}

#endif /* HAVE_PHP_GTK */
