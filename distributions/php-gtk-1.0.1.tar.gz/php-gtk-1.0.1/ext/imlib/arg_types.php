<?php

 
$matcher->register_boxed('GdkImlibImage', 'gdk_imlib_image');
$matcher->register_boxed('GdkImlibColorModifier', 'gdk_imlib_color_modifier');
$matcher->register_boxed('GdkImlibColor', 'gdk_imlib_color');
$matcher->register_boxed('GdkImlibBorder', 'gdk_imlib_border');
$matcher->register_boxed('GdkImlibSaveInfo', 'gdk_imlib_save_info');
$prefix = 'GdkImlib';
?>