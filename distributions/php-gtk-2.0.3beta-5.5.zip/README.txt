Welcome to PHP-GTK 2.0.3 for Windows
================================

With PHP you can write Desktop (GUI) applications using the PHP-GTK extension. 

This is a completely different approach than writing web pages, as you do not 
output any HTML, but manage Windows and objects within them. 

Important note: The versions of PHP Core and the PHP-GTK 2 extension included 
within this installer are only compatible with Windows Vista or higher. If you require a 
distribution for earlier windows versions please download the 
PHP-GTK 5.4  v. 2.0.3 installer from [The website].

Requirements
=============
This distribution of PHP-GTK 2 is provided as a single file DLL. 
You should download and install the latest PHP 5.5.0 NTS (Non Thread Safe) VC11
version of PHP from http://php.net/downloads.php.

The win32 PHP-GTK 2 extension was built against the following items:

- PHP 5.5.0 Core [Required] (PHP_Cairo.dll included as you will need this loaded in order to enable php-gtk)

- GTK+ 2.24.10 runtime environment installer [Required] (http://gtk-win.sourceforge.net/home/)

You will need to install the Visual C++ Redistributable for Visual Studio 2012, which you can find here 
(http://www.microsoft.com/en-us/download/details.aspx?id=30679).

You will need to install a compatible GTK+ runtime. It is suggested to use the 
GTK+ 2.24.10 runtime environment installer found here (http://gtk-win.sourceforge.net/home/).

Licensing:
=========

Both PHP-GTK and GTK+ are covered by the LGPL license - PHP is covered by the PHP license.

You may obtain the sources for PHP either by downloading the non-binary distribution tarball 
at http://php.net/downloads.php or via the Git repository following the instructions on the same page.

You may obtain the sources for PHP-GTK 2 from the PHP-GTK 2 Git repository 
https://github.com/php/php-gtk-src.

This distribution of PHP-GTK 2 was built against the GTK+ 2.24.10 win32 binaries from gtk.org.
The Runtime installer is not included with this release.

How to install PHP-GTK 2:
========================

Check the php.ini in a text editor and make sure the settings there are sane for 
your system. You may add further PHP-specific settings anywhere between 
[PHP] and [PHP-GTK].

Ensure you copied the 2 dll's included within this package to your PHP ext dir and 
have enabled the following in the php.ini:

extension = php-gtk2.dll
extension = php-cairo.dll

[PHP-GTK]

;;;;;;;;;;;;;;;;;;;;;;
; PHP-GTK extensions ;
;;;;;;;;;;;;;;;;;;;;;;

; Extensions written for PHP-GTK are in the format php_gtk_*.dll (Windows) or
; php_gtk_*.so (Unix), written here as a comma-separated list. The library
; files need to be in the same directory as the PHP-GTK library, along with
; any other PHP extensions you are using.

php-gtk.extensions = php_gtk_libglade2.dll

;;;;;;;;;;;;;
; Code Page ;
;;;;;;;;;;;;;

; The string variables used for titles and other text values in GTK+ are
; encoded in UTF-8 internally. A code page is needed so that PHP-GTK 'knows'
; which character set is being used, and can convert it to UTF-8 as necessary.

; If your environment uses UTF-8 already, you can set the codepage directive
; to UTF-8 to skip the conversions.

; The default codepage setting in PHP-GTK 2 is ISO-8859-1, but you can also
; use either OEM (e.g. 850) or Windows Code Pages (e.g. CP1250) here, so
; long as the encoding format you choose is capable of iconv conversion. See
; http://www.microsoft.com/globaldev/reference/cphome.mspx for a list of
; the code pages and character sets that are supported on Windows systems.

php-gtk.codepage = CP1250

The default version of PHP installed is 5.5.0 Non-thread safe and is a standard non-thread 
safe build using Visual Studio 2012 (VC11). 

The PHP Core includes many core extensions enabled by default. You should check the php.ini 
in a text editor and disable any extensions you may not need.

How to use PHP-GTK 2:
====================

PHP-GTK applications can be started from the command line (or a shortcut) with this syntax:

	demos\phpgtk2-demo.php

Using Additional Extensions:
==========================

You may use additional php extensions from php.net or PECL compiled to match this php.exe binary

For additional extensions please visit http://php.net/downloads and get the NON-THREAD SAFE (nts)
downloads of PHP 5.5.0 compiled with VC11 - the regular zip will work.

Additional PHP-GTK 2 extensions are not enabled in this release and are not known to work at this time. 

Please visit http://gtk.php.net for the latest news and support.