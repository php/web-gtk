#ifndef __GTK_ADDONS_H_
#define __GTK_ADDONS_H_


void gtk_window_set_win_position (GtkWidget *widget, gint x, gint y);

#endif
