Welcome to PHP-GTK 2.0.1 Extensions for Windows
================================

The win32 binary distribution for PHP-GTK 2 Extensions is a zip file with this structure:

php-gtk2		->	Additional runtime environment libraries necessary for extensions
php-gtk\ext		->	PHP-GTK2 extensions
php-gtk\debug        	->	debug symbols for PHP-GTK 2 extensions
php-gtk\etc
php-gtk\lib
php-gtk\share		->	Additional GTK+ 2.12.9 runtime files

Licensing:
=========

Both PHP-GTK and GTK+ are covered by the LGPL license - PHP is covered by the PHP license.

You may obtain the sources for PHP either by downloading the non-binary
distribution tarball at http://php.net/download.php or via the php.net CVS
repository following the instructions on the same page.

You may obtain the sources for PHP-GTK 2 either by downloading the non-binary
distribution tarball at http://gtk.php.net/download.php or via the php.net CVS
repository following the instructions on the same page.

You may obtain the sources for GTK+ by downloading the source distribution
tarballs from ftp://ftp.gtk.org.

This distribution of PHP-GTK 2 was built against GTK+ 2.12.9 binaries from gtk.org


How to install these extensions:
========================

Unzip the archive in a place of your choice. It will create a directory named
php-gtk2.

Place the contents of the directory where your php-gtk2 main install folder is, you can
unzip the contents of this directory over top.

Open your php-cli.ini in a text editor and look at the php-gtk.extensions
directive.  This should be a comma separated list of the dlls you want to load